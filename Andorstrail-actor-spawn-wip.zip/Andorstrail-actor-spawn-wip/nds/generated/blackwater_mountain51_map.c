#include "blackwater_mountain51_map.h"

const MapPlace blackwater_mountain51_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 10, 8, 1, 1, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 0, 4, 1, 2, "north", "", "", 0, 0, ""},
    {"restless_dead_1", MAP_PLACE_SPAWN, 2, 4, 5, 3, "restless_dead_1", "", "", 0, 0, ""},
    {"restless_dead_1_1", MAP_PLACE_SPAWN, 8, 4, 5, 3, "restless_dead_1_1", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain51_map_changes[] = {
    {10, 8, 1, 1, "blackwater_mountain31", "east"},
    {0, 4, 1, 2, "blackwater_mountain52", "south"}
};
