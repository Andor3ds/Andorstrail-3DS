#include "wild5_map.h"

const MapPlace wild5_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 8, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 4, 19, 2, 1, "south", "", "", 0, 0, ""},
    {"northeast", MAP_PLACE_MAPCHANGE, 23, 0, 3, 1, "northeast", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 15, 19, 1, 1, "south2", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 25, 1, 1, 7, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 25, 13, 1, 6, "east2", "", "", 0, 0, ""},
    {"forestsnake", MAP_PLACE_SPAWN, 6, 3, 7, 5, "forestsnake", "", "", 0, 0, ""},
    {"fox2", MAP_PLACE_SPAWN, 11, 2, 11, 9, "fox2", "", "", 0, 0, ""},
    {"forestwasp2", MAP_PLACE_SPAWN, 4, 6, 5, 9, "forestwasp2", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 9, 10, 15, 8, "forestboar2", "", "", 0, 0, ""},
    {"forestwasp2_1", MAP_PLACE_SPAWN, 23, 2, 1, 6, "forestwasp2_1", "", "", 0, 0, ""}
};
const MapChangeEvent wild5_map_changes[] = {
    {8, 0, 1, 1, "wild2", "south"},
    {4, 19, 2, 1, "wild6", "north"},
    {23, 0, 3, 1, "wild3", "south1"},
    {15, 19, 1, 1, "wild6", "north2"},
    {25, 1, 1, 7, "gapfiller2", "west1"},
    {25, 13, 1, 6, "gapfiller2", "west2"}
};
