#include "crossglen_farmhouse_basement_map.h"

const MapPlace crossglen_farmhouse_basement_places[] = {
    {"stairs_up", MAP_PLACE_MAPCHANGE, 0, 6, 1, 1, "stairs_up", "", "", 0, 0, ""},
    {"note_lodars", MAP_PLACE_SIGN, 7, 4, 1, 1, "note_lodars", "", "", 0, 0, ""},
    {"crossglen_beetle", MAP_PLACE_SPAWN, 2, 2, 7, 5, "crossglen_beetle", "", "", 0, 0, ""},
    {"oromir_basement_help", MAP_PLACE_SPAWN, 3, 2, 6, 5, "oromir_basement_help", "", "", 0, 0, ""},
    {"oromir_basement", MAP_PLACE_SPAWN, 3, 2, 6, 5, "oromir_basement", "", "", 0, 0, ""},
    {"leta_child_spawn", MAP_PLACE_SPAWN, 5, 2, 4, 1, "leta_child_spawn", "", "", 0, 0, ""}
};
const MapChangeEvent crossglen_farmhouse_basement_map_changes[] = {
    {0, 6, 1, 1, "crossglen_farmhouse", "stairs_down"}
};
