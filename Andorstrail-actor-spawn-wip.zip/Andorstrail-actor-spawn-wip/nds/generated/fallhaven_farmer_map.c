#include "fallhaven_farmer_map.h"

const MapPlace fallhaven_farmer_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 2, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"fallhaven_farmer1", MAP_PLACE_SPAWN, 3, 4, 8, 3, "fallhaven_farmer1", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_farmer_map_changes[] = {
    {2, 7, 1, 1, "fallhaven_se", "farmer"}
};
