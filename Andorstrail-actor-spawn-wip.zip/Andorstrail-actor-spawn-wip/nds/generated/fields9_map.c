#include "fields9_map.h"

const MapPlace fields9_places[] = {
    {"east1", MAP_PLACE_MAPCHANGE, 29, 1, 1, 2, "east1", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 1, 14, 28, 1, "south", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 13, 0, 17, 1, "north", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 4, 1, 10, "east2", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 11, 1, 3, "west", "", "", 0, 0, ""},
    {"fieldwasp_unique", MAP_PLACE_SPAWN, 2, 4, 26, 9, "fieldwasp_unique", "", "", 0, 0, ""},
    {"fieldwasp_2", MAP_PLACE_SPAWN, 2, 4, 26, 9, "fieldwasp_2", "", "", 0, 0, ""}
};
const MapChangeEvent fields9_map_changes[] = {
    {29, 1, 1, 2, "fields8", "west1"},
    {1, 14, 28, 1, "roadtocarntower1", "north"},
    {13, 0, 17, 1, "fields3", "south"},
    {29, 4, 1, 10, "fields8", "west2"},
    {0, 11, 1, 3, "fields10", "east"}
};
