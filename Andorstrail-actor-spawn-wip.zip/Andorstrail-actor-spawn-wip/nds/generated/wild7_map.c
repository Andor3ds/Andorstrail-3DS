#include "wild7_map.h"

const MapPlace wild7_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 11, 1, 3, "west", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 11, 0, 3, 1, "north", "", "", 0, 0, ""},
    {"sign_wild7", MAP_PLACE_SIGN, 13, 10, 1, 1, "sign_wild7", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 10, 1, 1, "east", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 10, 19, 4, 1, "south", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 7, 2, 11, 7, "forestwolf1", "", "", 0, 0, ""},
    {"forestbeetle", MAP_PLACE_SPAWN, 3, 8, 7, 10, "forestbeetle", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 7, 9, 12, 9, "forestserpent1", "", "", 0, 0, ""}
};
const MapChangeEvent wild7_map_changes[] = {
    {0, 11, 1, 3, "wild8", "east"},
    {11, 0, 3, 1, "wild6", "south"},
    {19, 10, 1, 1, "mywild18", "west"},
    {10, 19, 4, 1, "lake_shore_road_0", "north"}
};
