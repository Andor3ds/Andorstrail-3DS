#include "blackwater_mountain14_map.h"

const MapPlace blackwater_mountain14_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 2, "west", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 24, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 22, 19, 1, 1, "east", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 12, 0, 2, 1, "north2", "", "", 0, 0, ""},
    {"bwm17_questenabled_check", MAP_PLACE_SCRIPT, 12, 13, 1, 1, "bwm17_questenabled_check", "", "", 0, 0, ""},
    {"primwolf1", MAP_PLACE_SPAWN, 3, 2, 6, 12, "primwolf1", "", "", 0, 0, ""},
    {"bwm_agent_3", MAP_PLACE_SPAWN, 24, 6, 1, 1, "bwm_agent_3", "", "", 0, 0, ""},
    {"primwolf1_1", MAP_PLACE_SPAWN, 12, 13, 1, 1, "primwolf1_1", "", "", 0, 0, ""},
    {"forestboar4", MAP_PLACE_SPAWN, 11, 3, 10, 10, "forestboar4", "", "", 0, 0, ""},
    {"primwolf1_2", MAP_PLACE_SPAWN, 22, 10, 6, 8, "primwolf1_2", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain14_map_changes[] = {
    {0, 5, 1, 2, "blackwater_mountain10", "east"},
    {24, 0, 1, 1, "blackwater_mountain15", "south"},
    {22, 19, 1, 1, "blackwater_mountain40", "north"},
    {12, 0, 2, 1, "blackwater_mountain70", "south"}
};
