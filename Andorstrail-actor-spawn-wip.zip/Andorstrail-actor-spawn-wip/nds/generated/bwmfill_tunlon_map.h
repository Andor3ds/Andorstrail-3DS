#ifndef ANDOR_BWMFILL_TUNLON_MAP_H
#define ANDOR_BWMFILL_TUNLON_MAP_H
#include "map_data.h"

#define BWMFILL_TUNLON_WIDTH 16
#define BWMFILL_TUNLON_HEIGHT 8
#define BWMFILL_TUNLON_PIXEL_WIDTH (BWMFILL_TUNLON_WIDTH * 32)
#define BWMFILL_TUNLON_PIXEL_HEIGHT (BWMFILL_TUNLON_HEIGHT * 32)
#define BWMFILL_TUNLON_START_X 4
#define BWMFILL_TUNLON_START_Y 7
#define BWMFILL_TUNLON_PLACE_COUNT 3
#define BWMFILL_TUNLON_MAP_CHANGE_COUNT 2

static const unsigned char bwmfill_tunlon_walkable[BWMFILL_TUNLON_WIDTH * BWMFILL_TUNLON_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0
};

extern const MapPlace bwmfill_tunlon_places[];
extern const unsigned int bwmfill_tunlon_place_count;
extern const MapChangeEvent bwmfill_tunlon_map_changes[];
extern const unsigned int bwmfill_tunlon_map_change_count;

#endif
