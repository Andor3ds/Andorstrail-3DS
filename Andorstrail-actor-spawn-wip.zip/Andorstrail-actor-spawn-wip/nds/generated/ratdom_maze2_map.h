#ifndef ANDOR_RATDOM_MAZE2_MAP_H
#define ANDOR_RATDOM_MAZE2_MAP_H
#include "map_data.h"

#define RATDOM_MAZE2_WIDTH 8
#define RATDOM_MAZE2_HEIGHT 30
#define RATDOM_MAZE2_PIXEL_WIDTH (RATDOM_MAZE2_WIDTH * 32)
#define RATDOM_MAZE2_PIXEL_HEIGHT (RATDOM_MAZE2_HEIGHT * 32)
#define RATDOM_MAZE2_START_X 7
#define RATDOM_MAZE2_START_Y 4
#define RATDOM_MAZE2_PLACE_COUNT 14
#define RATDOM_MAZE2_MAP_CHANGE_COUNT 3

static const unsigned char ratdom_maze2_walkable[RATDOM_MAZE2_WIDTH * RATDOM_MAZE2_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 0, 0, 1, 1,
    0, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 0,
    0, 0, 1, 0, 0, 1, 1, 0,
    0, 0, 1, 0, 0, 1, 1, 0,
    0, 0, 1, 0, 0, 1, 1, 0,
    0, 0, 1, 0, 0, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace ratdom_maze2_places[];
extern const unsigned int ratdom_maze2_place_count;
extern const MapChangeEvent ratdom_maze2_map_changes[];
extern const unsigned int ratdom_maze2_map_change_count;

#endif
