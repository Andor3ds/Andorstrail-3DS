#include "ratdom_bwm1_map.h"

const MapPlace ratdom_bwm1_places[] = {
    {"cave", MAP_PLACE_MAPCHANGE, 6, 2, 1, 1, "cave", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 9, 1, 1, 5, "east1", "", "", 0, 0, ""},
    {"rest", MAP_PLACE_REST, 3, 18, 1, 1, "rest", "", "", 0, 0, ""},
    {"ratdom_bwm1_east1", MAP_PLACE_SCRIPT, 8, 3, 1, 4, "ratdom_bwm1_east1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 21, 1, 3, "west2", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 2, 29, 5, 1, "south", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 1, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 1, 1, 8, "west1", "", "", 0, 0, ""},
    {"ratdom_rat_bwm1", MAP_PLACE_SPAWN, 3, 14, 6, 7, "ratdom_rat_bwm1", "", "", 0, 0, ""},
    {"primwolf1", MAP_PLACE_SPAWN, 1, 25, 4, 3, "primwolf1", "", "", 0, 0, ""}
};
const MapChangeEvent ratdom_bwm1_map_changes[] = {
    {6, 2, 1, 1, "ratdom_maze3", "south"},
    {9, 1, 1, 5, "crossglen", "west1"},
    {0, 21, 1, 3, "bwmfill3", "east2"},
    {2, 29, 5, 1, "bwmfill6", "north"},
    {1, 0, 1, 1, "bwmfill2", "south3"},
    {0, 1, 1, 8, "bwmfill3", "east1"}
};
