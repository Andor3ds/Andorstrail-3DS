#ifndef ANDOR_CRACKSHOT_HIDEOUT1_MAP_H
#define ANDOR_CRACKSHOT_HIDEOUT1_MAP_H
#include "map_data.h"

#define CRACKSHOT_HIDEOUT1_WIDTH 27
#define CRACKSHOT_HIDEOUT1_HEIGHT 9
#define CRACKSHOT_HIDEOUT1_PIXEL_WIDTH (CRACKSHOT_HIDEOUT1_WIDTH * 32)
#define CRACKSHOT_HIDEOUT1_PIXEL_HEIGHT (CRACKSHOT_HIDEOUT1_HEIGHT * 32)
#define CRACKSHOT_HIDEOUT1_START_X 3
#define CRACKSHOT_HIDEOUT1_START_Y 2
#define CRACKSHOT_HIDEOUT1_PLACE_COUNT 11
#define CRACKSHOT_HIDEOUT1_MAP_CHANGE_COUNT 2

static const unsigned char crackshot_hideout1_walkable[CRACKSHOT_HIDEOUT1_WIDTH * CRACKSHOT_HIDEOUT1_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace crackshot_hideout1_places[];
extern const unsigned int crackshot_hideout1_place_count;
extern const MapChangeEvent crackshot_hideout1_map_changes[];
extern const unsigned int crackshot_hideout1_map_change_count;

#endif
