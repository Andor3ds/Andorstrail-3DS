#include "gapfiller3_map.h"

const MapPlace gapfiller3_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 5, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 2, 9, 2, 1, "south", "", "", 0, 0, ""},
    {"forestant", MAP_PLACE_SPAWN, 1, 2, 9, 6, "forestant", "", "", 0, 0, ""}
};
const MapChangeEvent gapfiller3_map_changes[] = {
    {5, 0, 2, 1, "wild1", "south"},
    {2, 9, 2, 1, "wild3", "north"}
};
