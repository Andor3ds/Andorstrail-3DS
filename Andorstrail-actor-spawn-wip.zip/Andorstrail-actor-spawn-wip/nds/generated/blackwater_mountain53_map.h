#ifndef ANDOR_BLACKWATER_MOUNTAIN53_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN53_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN53_WIDTH 30
#define BLACKWATER_MOUNTAIN53_HEIGHT 9
#define BLACKWATER_MOUNTAIN53_PIXEL_WIDTH (BLACKWATER_MOUNTAIN53_WIDTH * 32)
#define BLACKWATER_MOUNTAIN53_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN53_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN53_START_X 16
#define BLACKWATER_MOUNTAIN53_START_Y 8
#define BLACKWATER_MOUNTAIN53_PLACE_COUNT 7
#define BLACKWATER_MOUNTAIN53_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain53_walkable[BLACKWATER_MOUNTAIN53_WIDTH * BLACKWATER_MOUNTAIN53_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1,
    1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain53_places[];
extern const unsigned int blackwater_mountain53_place_count;
extern const MapChangeEvent blackwater_mountain53_map_changes[];
extern const unsigned int blackwater_mountain53_map_change_count;

#endif
