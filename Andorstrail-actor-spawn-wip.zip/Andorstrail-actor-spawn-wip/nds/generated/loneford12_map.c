#include "loneford12_map.h"

const MapPlace loneford12_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 1, 1, 15, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 7, 1, 1, 15, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 3, 0, 4, 1, "north", "", "", 0, 0, ""}
};
const MapChangeEvent loneford12_map_changes[] = {
    {0, 1, 1, 15, "loneford1", "east"},
    {7, 1, 1, 15, "lodar0", "west2"},
    {3, 0, 4, 1, "loneford13", "south2"}
};
