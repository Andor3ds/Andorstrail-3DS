#include "blackwater_mountain15_map.h"

const MapPlace blackwater_mountain15_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 3, 29, 1, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 14, 5, 1, 3, "east", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 14, 26, 1, 2, "east2", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 13, 24, 1, 1, "north", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 16, 1, 1, "west", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 22, 1, 3, "west2", "", "", 0, 0, ""},
    {"gornaud_2", MAP_PLACE_SPAWN, 3, 27, 1, 1, "gornaud_2", "", "", 0, 0, ""},
    {"gornaud_2_1", MAP_PLACE_SPAWN, 9, 18, 2, 2, "gornaud_2_1", "", "", 0, 0, ""},
    {"gornaud_1", MAP_PLACE_SPAWN, 1, 7, 4, 17, "gornaud_1", "", "", 0, 0, ""},
    {"gornaud_1_1", MAP_PLACE_SPAWN, 5, 3, 9, 13, "gornaud_1_1", "", "", 0, 0, ""},
    {"gornaud_2_2", MAP_PLACE_SPAWN, 3, 22, 7, 5, "gornaud_2_2", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain15_map_changes[] = {
    {3, 29, 1, 1, "blackwater_mountain14", "north"},
    {14, 5, 1, 3, "blackwater_mountain16", "west"},
    {14, 26, 1, 2, "blackwater_mountain16", "west2"},
    {13, 24, 1, 1, "blackwater_mountain17", "south"},
    {0, 16, 1, 1, "blackwater_mountain70", "east"},
    {0, 22, 1, 3, "blackwater_mountain70", "east2"}
};
