#include "woodcave0_map.h"

const MapPlace woodcave0_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 2, "west", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 18, 0, 8, 1, "north", "", "", 0, 0, ""},
    {"larva_2", MAP_PLACE_SPAWN, 2, 6, 2, 1, "larva_2", "", "", 0, 0, ""},
    {"larva_2_1", MAP_PLACE_SPAWN, 4, 5, 1, 1, "larva_2_1", "", "", 0, 0, ""},
    {"larva_2_2", MAP_PLACE_SPAWN, 5, 5, 1, 1, "larva_2_2", "", "", 0, 0, ""},
    {"larva_2_3", MAP_PLACE_SPAWN, 4, 4, 1, 1, "larva_2_3", "", "", 0, 0, ""},
    {"larva_2_4", MAP_PLACE_SPAWN, 4, 9, 3, 8, "larva_2_4", "", "", 0, 0, ""},
    {"fox1", MAP_PLACE_SPAWN, 13, 10, 7, 5, "fox1", "", "", 0, 0, ""},
    {"larva_1", MAP_PLACE_SPAWN, 16, 3, 1, 1, "larva_1", "", "", 0, 0, ""},
    {"larva_2_5", MAP_PLACE_SPAWN, 14, 5, 1, 1, "larva_2_5", "", "", 0, 0, ""},
    {"larva_2_6", MAP_PLACE_SPAWN, 9, 5, 3, 3, "larva_2_6", "", "", 0, 0, ""},
    {"fox1_1", MAP_PLACE_SPAWN, 19, 4, 8, 4, "fox1_1", "", "", 0, 0, ""},
    {"larva_2_7", MAP_PLACE_SPAWN, 8, 16, 4, 1, "larva_2_7", "", "", 0, 0, ""},
    {"larva_2_8", MAP_PLACE_SPAWN, 13, 16, 3, 1, "larva_2_8", "", "", 0, 0, ""},
    {"larva_2_9", MAP_PLACE_SPAWN, 17, 16, 3, 1, "larva_2_9", "", "", 0, 0, ""},
    {"larva_2_10", MAP_PLACE_SPAWN, 24, 16, 2, 1, "larva_2_10", "", "", 0, 0, ""},
    {"Entrance", MAP_PLACE_MAPCHANGE, 13, 9, 1, 1, "Entrance", "", "", 0, 0, ""},
    {"guild03_Hentrance_select", MAP_PLACE_SCRIPT, 13, 9, 2, 2, "guild03_Hentrance_select", "", "", 0, 0, "enter"}
};
const MapChangeEvent woodcave0_map_changes[] = {
    {0, 5, 1, 2, "wild0", "east"},
    {18, 0, 8, 1, "roadbeforecrossroads", "south"},
    {13, 9, 1, 1, "crackshot_hideout1", "Exit"}
};
