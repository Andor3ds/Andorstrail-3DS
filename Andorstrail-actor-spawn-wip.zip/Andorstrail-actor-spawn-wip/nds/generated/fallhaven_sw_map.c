#include "fallhaven_sw_map.h"

const MapPlace fallhaven_sw_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 8, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 15, 19, 2, 1, "south", "", "", 0, 0, ""},
    {"alaun", MAP_PLACE_MAPCHANGE, 24, 5, 1, 1, "alaun", "", "", 0, 0, ""},
    {"lumberjack", MAP_PLACE_MAPCHANGE, 14, 6, 1, 1, "lumberjack", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 3, 19, 2, 1, "south2", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 8, 1, 2, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 11, 1, 7, "west2", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 1, 1, 6, "east", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 10, 1, 2, "east2", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 29, 13, 1, 1, "east3", "", "", 0, 0, ""},
    {"east4", MAP_PLACE_MAPCHANGE, 29, 15, 1, 1, "east4", "", "", 0, 0, ""},
    {"andor1_5", MAP_PLACE_KEY, 13, 8, 1, 1, "fallhaven_lumberjack", "questProgress", "andor", 1, 0, ""},
    {"fallhaven_citizen3", MAP_PLACE_SPAWN, 10, 2, 18, 8, "fallhaven_citizen3", "", "", 0, 0, ""},
    {"fallhaven_lumberjack", MAP_PLACE_SPAWN, 13, 8, 1, 1, "fallhaven_lumberjack", "", "", 0, 0, ""},
    {"forestant", MAP_PLACE_SPAWN, 2, 12, 9, 6, "forestant", "", "", 0, 0, ""},
    {"forestant_1", MAP_PLACE_SPAWN, 20, 13, 8, 6, "forestant_1", "", "", 0, 0, ""},
    {"vacor", MAP_PLACE_SPAWN, 4, 4, 1, 1, "vacor", "", "", 0, 0, ""},
    {"arensia", MAP_PLACE_SPAWN, 6, 10, 3, 3, "arensia", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_sw_map_changes[] = {
    {8, 0, 1, 1, "fallhaven_nw", "south"},
    {15, 19, 2, 1, "wild10", "north"},
    {24, 5, 1, 1, "fallhaven_alaun", "entrance"},
    {14, 6, 1, 1, "fallhaven_lumberjack", "entrance"},
    {3, 19, 2, 1, "wild9", "north3"},
    {0, 8, 1, 2, "gapfiller2", "east1"},
    {0, 11, 1, 7, "gapfiller2", "east2"},
    {29, 1, 1, 6, "fallhaven_se", "west"},
    {29, 10, 1, 2, "fallhaven_se", "west2"},
    {29, 13, 1, 1, "fallhaven_se", "west3"},
    {29, 15, 1, 1, "fallhaven_se", "west4"}
};
