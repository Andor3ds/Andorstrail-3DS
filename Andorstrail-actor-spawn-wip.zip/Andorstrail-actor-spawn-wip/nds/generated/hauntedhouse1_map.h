#ifndef ANDOR_HAUNTEDHOUSE1_MAP_H
#define ANDOR_HAUNTEDHOUSE1_MAP_H
#include "map_data.h"

#define HAUNTEDHOUSE1_WIDTH 10
#define HAUNTEDHOUSE1_HEIGHT 8
#define HAUNTEDHOUSE1_PIXEL_WIDTH (HAUNTEDHOUSE1_WIDTH * 32)
#define HAUNTEDHOUSE1_PIXEL_HEIGHT (HAUNTEDHOUSE1_HEIGHT * 32)
#define HAUNTEDHOUSE1_START_X 2
#define HAUNTEDHOUSE1_START_Y 7
#define HAUNTEDHOUSE1_PLACE_COUNT 3
#define HAUNTEDHOUSE1_MAP_CHANGE_COUNT 2

static const unsigned char hauntedhouse1_walkable[HAUNTEDHOUSE1_WIDTH * HAUNTEDHOUSE1_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 0, 1, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 1, 1, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace hauntedhouse1_places[];
extern const unsigned int hauntedhouse1_place_count;
extern const MapChangeEvent hauntedhouse1_map_changes[];
extern const unsigned int hauntedhouse1_map_change_count;

#endif
