#include "crossroads_map.h"

const MapPlace crossroads_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 10, 29, 2, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 5, 1, 2, "east", "", "", 0, 0, ""},
    {"southeast", MAP_PLACE_MAPCHANGE, 29, 18, 1, 7, "southeast", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 8, 0, 3, 1, "north", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 15, 1, 3, "west", "", "", 0, 0, ""},
    {"middle", MAP_PLACE_MAPCHANGE, 19, 10, 1, 1, "middle", "", "", 0, 0, ""},
    {"change1", MAP_PLACE_MAPCHANGE, 15, 0, 14, 1, "change1", "", "", 0, 0, ""},
    {"change2", MAP_PLACE_MAPCHANGE, 29, 0, 1, 4, "change2", "", "", 0, 0, ""},
    {"northwest", MAP_PLACE_MAPCHANGE, 1, 0, 3, 1, "northwest", "", "", 0, 0, ""},
    {"sign_crossroadshouse", MAP_PLACE_SIGN, 21, 11, 1, 1, "sign_crossroadshouse", "", "", 0, 0, ""},
    {"sign_crossroads_s", MAP_PLACE_SIGN, 19, 15, 1, 1, "sign_crossroads_s", "", "", 0, 0, ""},
    {"sign_crossroads_n", MAP_PLACE_SIGN, 20, 4, 1, 1, "sign_crossroads_n", "", "", 0, 0, ""},
    {"brv_patrol_check_stop_hero", MAP_PLACE_SCRIPT, 11, 14, 15, 2, "brv_patrol_check_stop_hero", "", "", 0, 0, "enter"},
    {"achieve_road", MAP_PLACE_SCRIPT, 18, 19, 2, 1, "achieve_road", "", "", 0, 0, ""},
    {"dds_miri_spawn", MAP_PLACE_SCRIPT, 19, 11, 2, 1, "dds_miri_spawn", "", "", 0, 0, ""},
    {"burhczyd_check12", MAP_PLACE_SCRIPT, 19, 11, 2, 1, "burhczyd_check12", "", "", 0, 0, ""},
    {"fieldwasp_unique", MAP_PLACE_SPAWN, 1, 2, 8, 11, "fieldwasp_unique", "", "", 0, 0, ""},
    {"fanamor", MAP_PLACE_SPAWN, 2, 23, 1, 1, "fanamor", "", "", 0, 0, ""},
    {"benbyr", MAP_PLACE_SPAWN, 13, 11, 1, 1, "benbyr", "", "", 0, 0, ""},
    {"crossroads_guard", MAP_PLACE_SPAWN, 17, 12, 1, 1, "crossroads_guard", "", "", 0, 0, ""},
    {"crossroads_guard_1", MAP_PLACE_SPAWN, 22, 10, 1, 1, "crossroads_guard_1", "", "", 0, 0, ""},
    {"forestboar3", MAP_PLACE_SPAWN, 2, 25, 5, 3, "forestboar3", "", "", 0, 0, ""},
    {"forestboar3_1", MAP_PLACE_SPAWN, 9, 27, 1, 1, "forestboar3_1", "", "", 0, 0, ""},
    {"forestboar3_2", MAP_PLACE_SPAWN, 5, 17, 3, 2, "forestboar3_2", "", "", 0, 0, ""},
    {"fieldwasp_0", MAP_PLACE_SPAWN, 1, 2, 8, 11, "fieldwasp_0", "", "", 0, 0, ""},
    {"stop_hero", MAP_PLACE_KEY, 10, 13, 17, 4, "brv_wait_patrol", "questProgress", "brv_nondisplay", 140, 1, ""},
    {"feygard_scout", MAP_PLACE_SPAWN, 4, 23, 1, 1, "feygard_scout", "", "", 0, 0, ""},
    {"knights", MAP_PLACE_SPAWN, 10, 13, 17, 4, "knights", "", "", 0, 0, ""}
};
const MapChangeEvent crossroads_map_changes[] = {
    {10, 29, 2, 1, "wild0", "north"},
    {29, 5, 1, 2, "loneford1", "west"},
    {29, 18, 1, 7, "roadbeforecrossroads", "north"},
    {8, 0, 3, 1, "fields0", "south"},
    {0, 15, 1, 3, "roadtocarntower0", "east"},
    {19, 10, 1, 1, "houseatcrossroads0", "middle"},
    {15, 0, 14, 1, "fields0", "change1"},
    {29, 0, 1, 4, "loneford1", "change2"},
    {1, 0, 3, 1, "fields0", "southwest"}
};
