#include "fields2_map.h"

const MapPlace fields2_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 29, 1, 1, 28, "east", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 12, 1, 17, "west", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 9, 0, 21, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 0, 29, 30, 1, "south", "", "", 0, 0, ""},
    {"tinlyn_lostsheep2", MAP_PLACE_SPAWN, 2, 2, 26, 26, "tinlyn_lostsheep2", "", "", 0, 0, ""},
    {"fieldcritter_1", MAP_PLACE_SPAWN, 2, 2, 26, 26, "fieldcritter_1", "", "", 0, 0, ""},
    {"fieldcritter_3", MAP_PLACE_SPAWN, 2, 2, 26, 26, "fieldcritter_3", "", "", 0, 0, ""}
};
const MapChangeEvent fields2_map_changes[] = {
    {29, 1, 1, 28, "fields1", "west"},
    {0, 12, 1, 17, "fields3", "east"},
    {9, 0, 21, 1, "fields5", "south"},
    {0, 29, 30, 1, "fields8", "north"}
};
