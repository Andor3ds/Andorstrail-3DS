#ifndef ANDOR_HOUSEATCROSSROADS0_MAP_H
#define ANDOR_HOUSEATCROSSROADS0_MAP_H
#include "map_data.h"

#define HOUSEATCROSSROADS0_WIDTH 16
#define HOUSEATCROSSROADS0_HEIGHT 12
#define HOUSEATCROSSROADS0_PIXEL_WIDTH (HOUSEATCROSSROADS0_WIDTH * 32)
#define HOUSEATCROSSROADS0_PIXEL_HEIGHT (HOUSEATCROSSROADS0_HEIGHT * 32)
#define HOUSEATCROSSROADS0_START_X 9
#define HOUSEATCROSSROADS0_START_Y 11
#define HOUSEATCROSSROADS0_PLACE_COUNT 12
#define HOUSEATCROSSROADS0_MAP_CHANGE_COUNT 3

static const unsigned char houseatcrossroads0_walkable[HOUSEATCROSSROADS0_WIDTH * HOUSEATCROSSROADS0_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0
};

extern const MapPlace houseatcrossroads0_places[];
extern const unsigned int houseatcrossroads0_place_count;
extern const MapChangeEvent houseatcrossroads0_map_changes[];
extern const unsigned int houseatcrossroads0_map_change_count;

#endif
