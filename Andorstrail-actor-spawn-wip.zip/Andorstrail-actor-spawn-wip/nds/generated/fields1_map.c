#include "fields1_map.h"

const MapPlace fields1_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 0, 29, 12, 1, "south", "", "", 0, 0, ""},
    {"southeast", MAP_PLACE_MAPCHANGE, 29, 25, 1, 4, "southeast", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 1, 1, 28, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 1, 1, 23, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 0, 0, 30, 1, "north", "", "", 0, 0, ""},
    {"sign_fields1", MAP_PLACE_SIGN, 13, 13, 1, 1, "sign_fields1", "", "", 0, 0, ""},
    {"tinlyn_lostsheep1", MAP_PLACE_SPAWN, 2, 2, 26, 26, "tinlyn_lostsheep1", "", "", 0, 0, ""},
    {"fieldcritter_0", MAP_PLACE_SPAWN, 2, 2, 7, 17, "fieldcritter_0", "", "", 0, 0, ""},
    {"fieldcritter_1", MAP_PLACE_SPAWN, 16, 2, 12, 10, "fieldcritter_1", "", "", 0, 0, ""},
    {"fieldcritter_1_1", MAP_PLACE_SPAWN, 13, 16, 15, 13, "fieldcritter_1_1", "", "", 0, 0, ""},
    {"fieldcritter_0_1", MAP_PLACE_SPAWN, 2, 14, 4, 14, "fieldcritter_0_1", "", "", 0, 0, ""},
    {"fieldcritter_0_2", MAP_PLACE_SPAWN, 14, 8, 8, 6, "fieldcritter_0_2", "", "", 0, 0, ""}
};
const MapChangeEvent fields1_map_changes[] = {
    {0, 29, 12, 1, "fields0", "north"},
    {29, 25, 1, 4, "loneford1", "northwest"},
    {0, 1, 1, 28, "fields2", "east"},
    {29, 1, 1, 23, "fields4", "west"},
    {0, 0, 30, 1, "fields6", "south"}
};
