#include "fallhaven_athamyr_map.h"

const MapPlace fallhaven_athamyr_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 2, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"Athamyr", MAP_PLACE_SPAWN, 5, 5, 3, 2, "Athamyr", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_athamyr_map_changes[] = {
    {2, 7, 1, 1, "fallhaven_nw", "athamyr"}
};
