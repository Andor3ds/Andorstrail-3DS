#include "blackwater_mountain70_map.h"

const MapPlace blackwater_mountain70_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 2, 29, 2, 1, "south", "", "", 0, 0, ""},
    {"bwm17_vine_selector", MAP_PLACE_SCRIPT, 7, 25, 3, 1, "bwm17_vine_selector", "", "", 0, 0, "enter"},
    {"bwm17_heights_1", MAP_PLACE_SCRIPT, 1, 28, 4, 1, "bwm17_heights_1", "", "", 0, 0, "enter"},
    {"bwm17_heights2_1", MAP_PLACE_SCRIPT, 8, 15, 1, 3, "bwm17_heights2_1", "", "", 0, 0, "enter"},
    {"bwm17_heights2_1", MAP_PLACE_SCRIPT, 4, 6, 3, 1, "bwm17_heights2_1", "", "", 0, 0, "enter"},
    {"bwm17_heights_1", MAP_PLACE_SCRIPT, 5, 8, 1, 1, "bwm17_heights_1", "", "", 0, 0, "enter"},
    {"hole", MAP_PLACE_MAPCHANGE, 9, 10, 1, 1, "hole", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 9, 16, 1, 1, "east", "", "", 0, 0, ""},
    {"bwm70_sign", MAP_PLACE_SCRIPT, 4, 9, 1, 1, "bwm70_sign", "", "", 0, 0, "enter"},
    {"bwm17_heights2_1", MAP_PLACE_SCRIPT, 8, 23, 1, 3, "bwm17_heights2_1", "", "", 0, 0, "enter"},
    {"east2", MAP_PLACE_MAPCHANGE, 9, 22, 1, 3, "east2", "", "", 0, 0, ""},
    {"bwm70_corpse", MAP_PLACE_SCRIPT, 7, 16, 1, 1, "bwm70_corpse", "", "", 0, 0, "enter"},
    {"forestboar2", MAP_PLACE_SPAWN, 2, 18, 3, 8, "forestboar2", "", "", 0, 0, ""},
    {"gornaud_2", MAP_PLACE_SPAWN, 4, 2, 4, 4, "gornaud_2", "", "", 0, 0, ""},
    {"gornaud_1", MAP_PLACE_SPAWN, 6, 13, 3, 4, "gornaud_1", "", "", 0, 0, ""},
    {"forestboar1", MAP_PLACE_SPAWN, 1, 9, 3, 5, "forestboar1", "", "", 0, 0, ""},
    {"primwolf2", MAP_PLACE_SPAWN, 2, 7, 1, 2, "primwolf2", "", "", 0, 0, ""},
    {"bwm17_worker", MAP_PLACE_SPAWN, 4, 9, 1, 1, "bwm17_worker", "", "", 0, 0, ""},
    {"bwm17_hole", MAP_PLACE_KEY, 9, 10, 1, 1, "bwm17_vine2_1", "questProgress", "bwm17_vine", 2, 0, ""},
    {"bwm17_questenabled", MAP_PLACE_KEY, 5, 8, 1, 2, "bwm17_questenabled", "questProgress", "bwm17_vine", 3, 0, ""}
};
const MapChangeEvent blackwater_mountain70_map_changes[] = {
    {2, 29, 2, 1, "blackwater_mountain14", "north2"},
    {9, 10, 1, 1, "blackwater_mountain71", "up"},
    {9, 16, 1, 1, "blackwater_mountain15", "west"},
    {9, 22, 1, 3, "blackwater_mountain15", "west2"}
};
