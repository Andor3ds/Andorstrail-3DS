#include "bwmfill7_map.h"

const MapPlace bwmfill7_places[] = {
    {"north1", MAP_PLACE_MAPCHANGE, 5, 0, 1, 1, "north1", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 16, 1, 2, "west", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 7, 0, 3, 1, "north2", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 11, 19, 2, 1, "south2", "", "", 0, 0, ""},
    {"gornaud1", MAP_PLACE_SPAWN, 12, 12, 1, 1, "gornaud1", "", "", 0, 0, ""},
    {"primwolf1", MAP_PLACE_SPAWN, 3, 5, 4, 8, "primwolf1", "", "", 0, 0, ""},
    {"primwolf2", MAP_PLACE_SPAWN, 9, 7, 4, 4, "primwolf2", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill7_map_changes[] = {
    {5, 0, 1, 1, "bwmfill6", "south"},
    {0, 16, 1, 2, "blackwater_mountain30", "east2"},
    {7, 0, 3, 1, "wild2", "south2"},
    {11, 19, 2, 1, "wild6", "north3"}
};
