#ifndef ANDOR_FALLHAVEN_ALAUN_MAP_H
#define ANDOR_FALLHAVEN_ALAUN_MAP_H
#include "map_data.h"

#define FALLHAVEN_ALAUN_WIDTH 10
#define FALLHAVEN_ALAUN_HEIGHT 8
#define FALLHAVEN_ALAUN_PIXEL_WIDTH (FALLHAVEN_ALAUN_WIDTH * 32)
#define FALLHAVEN_ALAUN_PIXEL_HEIGHT (FALLHAVEN_ALAUN_HEIGHT * 32)
#define FALLHAVEN_ALAUN_START_X 6
#define FALLHAVEN_ALAUN_START_Y 7
#define FALLHAVEN_ALAUN_PLACE_COUNT 2
#define FALLHAVEN_ALAUN_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_alaun_walkable[FALLHAVEN_ALAUN_WIDTH * FALLHAVEN_ALAUN_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0
};

extern const MapPlace fallhaven_alaun_places[];
extern const unsigned int fallhaven_alaun_place_count;
extern const MapChangeEvent fallhaven_alaun_map_changes[];
extern const unsigned int fallhaven_alaun_map_change_count;

#endif
