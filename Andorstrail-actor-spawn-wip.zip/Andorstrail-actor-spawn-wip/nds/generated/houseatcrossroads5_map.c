#include "houseatcrossroads5_map.h"

const MapPlace houseatcrossroads5_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 8, 8, 1, 1, "south", "", "", 0, 0, ""},
    {"keknazar", MAP_PLACE_SPAWN, 5, 4, 1, 1, "keknazar", "", "", 0, 0, ""}
};
const MapChangeEvent houseatcrossroads5_map_changes[] = {
    {8, 8, 1, 1, "houseatcrossroads1", "north"}
};
