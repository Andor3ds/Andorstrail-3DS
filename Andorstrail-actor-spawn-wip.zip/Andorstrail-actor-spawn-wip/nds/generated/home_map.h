#ifndef ANDOR_HOME_MAP_H
#define ANDOR_HOME_MAP_H
#include "map_data.h"

#define HOME_WIDTH 12
#define HOME_HEIGHT 10
#define HOME_PIXEL_WIDTH (HOME_WIDTH * 32)
#define HOME_PIXEL_HEIGHT (HOME_HEIGHT * 32)
#define HOME_START_X 1
#define HOME_START_Y 4
#define HOME_PLACE_COUNT 14
#define HOME_MAP_CHANGE_COUNT 1

static const unsigned char home_walkable[HOME_WIDTH * HOME_HEIGHT] = {
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0
};

extern const MapPlace home_places[];
extern const unsigned int home_place_count;
extern const MapChangeEvent home_map_changes[];
extern const unsigned int home_map_change_count;

#endif
