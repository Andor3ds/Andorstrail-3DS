#ifndef ANDOR_FALLHAVEN_DERELICT_MAP_H
#define ANDOR_FALLHAVEN_DERELICT_MAP_H
#include "map_data.h"

#define FALLHAVEN_DERELICT_WIDTH 12
#define FALLHAVEN_DERELICT_HEIGHT 8
#define FALLHAVEN_DERELICT_PIXEL_WIDTH (FALLHAVEN_DERELICT_WIDTH * 32)
#define FALLHAVEN_DERELICT_PIXEL_HEIGHT (FALLHAVEN_DERELICT_HEIGHT * 32)
#define FALLHAVEN_DERELICT_START_X 7
#define FALLHAVEN_DERELICT_START_Y 7
#define FALLHAVEN_DERELICT_PLACE_COUNT 4
#define FALLHAVEN_DERELICT_MAP_CHANGE_COUNT 2

static const unsigned char fallhaven_derelict_walkable[FALLHAVEN_DERELICT_WIDTH * FALLHAVEN_DERELICT_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0
};

extern const MapPlace fallhaven_derelict_places[];
extern const unsigned int fallhaven_derelict_place_count;
extern const MapChangeEvent fallhaven_derelict_map_changes[];
extern const unsigned int fallhaven_derelict_map_change_count;

#endif
