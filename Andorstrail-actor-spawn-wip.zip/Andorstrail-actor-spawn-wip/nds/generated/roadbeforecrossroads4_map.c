#include "roadbeforecrossroads4_map.h"

const MapPlace roadbeforecrossroads4_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 7, 0, 9, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 9, 19, 7, 1, "south", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 0, 1, 2, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 16, 1, 1, "west2", "", "", 0, 0, ""},
    {"forestserpent2", MAP_PLACE_SPAWN, 3, 6, 5, 5, "forestserpent2", "", "", 0, 0, ""},
    {"forestboar3", MAP_PLACE_SPAWN, 3, 11, 6, 7, "forestboar3", "", "", 0, 0, ""},
    {"forestserpent2_1", MAP_PLACE_SPAWN, 13, 7, 5, 7, "forestserpent2_1", "", "", 0, 0, ""}
};
const MapChangeEvent roadbeforecrossroads4_map_changes[] = {
    {7, 0, 9, 1, "roadbeforecrossroads3", "south"},
    {9, 19, 7, 1, "roadbeforecrossroads5", "north"},
    {0, 0, 1, 2, "fallhaven_ne", "east1"},
    {0, 16, 1, 1, "fallhaven_ne", "east2"}
};
