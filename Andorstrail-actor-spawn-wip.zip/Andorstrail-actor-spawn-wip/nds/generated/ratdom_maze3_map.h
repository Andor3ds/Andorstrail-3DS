#ifndef ANDOR_RATDOM_MAZE3_MAP_H
#define ANDOR_RATDOM_MAZE3_MAP_H
#include "map_data.h"

#define RATDOM_MAZE3_WIDTH 10
#define RATDOM_MAZE3_HEIGHT 11
#define RATDOM_MAZE3_PIXEL_WIDTH (RATDOM_MAZE3_WIDTH * 32)
#define RATDOM_MAZE3_PIXEL_HEIGHT (RATDOM_MAZE3_HEIGHT * 32)
#define RATDOM_MAZE3_START_X 7
#define RATDOM_MAZE3_START_Y 7
#define RATDOM_MAZE3_PLACE_COUNT 7
#define RATDOM_MAZE3_MAP_CHANGE_COUNT 2

static const unsigned char ratdom_maze3_walkable[RATDOM_MAZE3_WIDTH * RATDOM_MAZE3_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace ratdom_maze3_places[];
extern const unsigned int ratdom_maze3_place_count;
extern const MapChangeEvent ratdom_maze3_map_changes[];
extern const unsigned int ratdom_maze3_map_change_count;

#endif
