#include "blackwater_mountain30_map.h"

const MapPlace blackwater_mountain30_places[] = {
    {"cave", MAP_PLACE_MAPCHANGE, 25, 8, 1, 1, "cave", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 2, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 11, 7, 1, 1, "east", "", "", 0, 0, ""},
    {"sign_blackwater30", MAP_PLACE_SIGN, 8, 18, 1, 1, "sign_blackwater30", "", "", 0, 0, ""},
    {"sign_bwm30_grave", MAP_PLACE_SIGN, 19, 6, 1, 1, "sign_bwm30_grave", "", "", 0, 0, ""},
    {"bwm30_ortholion_guards_selector", MAP_PLACE_SCRIPT, 12, 8, 1, 3, "bwm30_ortholion_guards_selector", "", "", 0, 0, "enter"},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 16, 1, 2, "east2", "", "", 0, 0, ""},
    {"bwm_agent_5", MAP_PLACE_SPAWN, 6, 10, 1, 1, "bwm_agent_5", "", "", 0, 0, ""},
    {"wyrm_1", MAP_PLACE_SPAWN, 15, 5, 7, 6, "wyrm_1", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 23, 9, 1, 2, "wyrm_2", "", "", 0, 0, ""},
    {"wyrm_3", MAP_PLACE_SPAWN, 2, 8, 2, 3, "wyrm_3", "", "", 0, 0, ""},
    {"wyrm_2_1", MAP_PLACE_SPAWN, 24, 13, 1, 1, "wyrm_2_1", "", "", 0, 0, ""},
    {"wyrm_2_2", MAP_PLACE_SPAWN, 22, 17, 1, 1, "wyrm_2_2", "", "", 0, 0, ""},
    {"wyrm_2_3", MAP_PLACE_SPAWN, 10, 16, 11, 3, "wyrm_2_3", "", "", 0, 0, ""},
    {"wyrm_2_4", MAP_PLACE_SPAWN, 5, 2, 2, 5, "wyrm_2_4", "", "", 0, 0, ""},
    {"Object", MAP_PLACE_KEY, 0, 5, 1, 2, "bwm30_ortholion_warning", "questProgress", "bwm72_beginning", 16, 1, ""}
};
const MapChangeEvent blackwater_mountain30_map_changes[] = {
    {25, 8, 1, 1, "blackwater_mountain39", "south"},
    {0, 5, 1, 2, "blackwater_mountain32", "east"},
    {11, 7, 1, 1, "blackwater_mountain31", "south"},
    {29, 16, 1, 2, "bwmfill7", "west"}
};
