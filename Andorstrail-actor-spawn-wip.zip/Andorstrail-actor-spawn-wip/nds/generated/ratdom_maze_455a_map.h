#ifndef ANDOR_RATDOM_MAZE_455A_MAP_H
#define ANDOR_RATDOM_MAZE_455A_MAP_H
#include "map_data.h"

#define RATDOM_MAZE_455A_WIDTH 11
#define RATDOM_MAZE_455A_HEIGHT 21
#define RATDOM_MAZE_455A_PIXEL_WIDTH (RATDOM_MAZE_455A_WIDTH * 32)
#define RATDOM_MAZE_455A_PIXEL_HEIGHT (RATDOM_MAZE_455A_HEIGHT * 32)
#define RATDOM_MAZE_455A_START_X 5
#define RATDOM_MAZE_455A_START_Y 0
#define RATDOM_MAZE_455A_PLACE_COUNT 12
#define RATDOM_MAZE_455A_MAP_CHANGE_COUNT 4

static const unsigned char ratdom_maze_455a_walkable[RATDOM_MAZE_455A_WIDTH * RATDOM_MAZE_455A_HEIGHT] = {
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0,
    0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace ratdom_maze_455a_places[];
extern const unsigned int ratdom_maze_455a_place_count;
extern const MapChangeEvent ratdom_maze_455a_map_changes[];
extern const unsigned int ratdom_maze_455a_map_change_count;

#endif
