#ifndef ANDOR_WILD6_HOUSE_MAP_H
#define ANDOR_WILD6_HOUSE_MAP_H
#include "map_data.h"

#define WILD6_HOUSE_WIDTH 9
#define WILD6_HOUSE_HEIGHT 7
#define WILD6_HOUSE_PIXEL_WIDTH (WILD6_HOUSE_WIDTH * 32)
#define WILD6_HOUSE_PIXEL_HEIGHT (WILD6_HOUSE_HEIGHT * 32)
#define WILD6_HOUSE_START_X 6
#define WILD6_HOUSE_START_Y 6
#define WILD6_HOUSE_PLACE_COUNT 7
#define WILD6_HOUSE_MAP_CHANGE_COUNT 2

static const unsigned char wild6_house_walkable[WILD6_HOUSE_WIDTH * WILD6_HOUSE_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0
};

extern const MapPlace wild6_house_places[];
extern const unsigned int wild6_house_place_count;
extern const MapChangeEvent wild6_house_map_changes[];
extern const unsigned int wild6_house_map_change_count;

#endif
