#include "ratdom_maze_455a_map.h"

const MapPlace ratdom_maze_455a_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 5, 0, 1, 1, "up", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 18, 1, 2, "west", "", "", 0, 0, ""},
    {"ratdom_ladder_1", MAP_PLACE_SCRIPT, 4, 17, 3, 2, "ratdom_ladder_1", "", "", 0, 0, ""},
    {"ratdom_ladder_1", MAP_PLACE_SCRIPT, 4, 1, 3, 2, "ratdom_ladder_1", "", "", 0, 0, ""},
    {"ratdom_ladder_0", MAP_PLACE_SCRIPT, 2, 15, 3, 1, "ratdom_ladder_0", "", "", 0, 0, ""},
    {"ratdom_ladder_0", MAP_PLACE_SCRIPT, 6, 15, 3, 1, "ratdom_ladder_0", "", "", 0, 0, ""},
    {"ladder_left", MAP_PLACE_MAPCHANGE, 3, 16, 1, 1, "ladder_left", "", "", 0, 0, ""},
    {"ladder_right", MAP_PLACE_MAPCHANGE, 7, 16, 1, 1, "ladder_right", "", "", 0, 0, ""},
    {"ladder_left1", MAP_PLACE_MAPCHANGE, 4, 1, 1, 14, "ladder_left1", "", "", 0, 0, ""},
    {"ladder_right1", MAP_PLACE_MAPCHANGE, 6, 1, 1, 14, "ladder_right1", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 3, 1, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"ratdom_maze_rat", MAP_PLACE_SPAWN, -2, 3, 3, 3, "ratdom_maze_rat", "", "", 0, 0, ""}
};
const MapChangeEvent ratdom_maze_455a_map_changes[] = {
    {5, 0, 1, 1, "blackwater_mountain55", "cave"},
    {0, 18, 1, 2, "ratdom_maze_455", "east"},
    {4, 1, 1, 14, "ratdom_maze_455a", "ladder_left"},
    {6, 1, 1, 14, "ratdom_maze_455a", "ladder_right"}
};
