#include "hauntedhouse3_map.h"

const MapPlace hauntedhouse3_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 22, 4, 1, 1, "north", "", "", 0, 0, ""},
    {"up", MAP_PLACE_MAPCHANGE, 0, 3, 1, 1, "up", "", "", 0, 0, ""},
    {"sign_hh3_papers", MAP_PLACE_SIGN, 23, 8, 1, 1, "sign_hh3_papers", "", "", 0, 0, ""},
    {"sign_hh3_grave", MAP_PLACE_SIGN, 12, 14, 1, 1, "sign_hh3_grave", "", "", 0, 0, ""},
    {"catacombguard3", MAP_PLACE_SPAWN, 11, 8, 1, 1, "catacombguard3", "", "", 0, 0, ""},
    {"catacombguard2", MAP_PLACE_SPAWN, 9, 11, 4, 7, "catacombguard2", "", "", 0, 0, ""},
    {"minorhaunt2", MAP_PLACE_SPAWN, 7, 8, 1, 1, "minorhaunt2", "", "", 0, 0, ""},
    {"minorhaunt2_1", MAP_PLACE_SPAWN, 1, 11, 7, 8, "minorhaunt2_1", "", "", 0, 0, ""},
    {"haunt3", MAP_PLACE_SPAWN, 11, 3, 6, 3, "haunt3", "", "", 0, 0, ""},
    {"haunt3_1", MAP_PLACE_SPAWN, 16, 8, 2, 8, "haunt3_1", "", "", 0, 0, ""},
    {"skeleton1", MAP_PLACE_SPAWN, 21, 6, 3, 11, "skeleton1", "", "", 0, 0, ""}
};
const MapChangeEvent hauntedhouse3_map_changes[] = {
    {22, 4, 1, 1, "hauntedhouse4", "south"},
    {0, 3, 1, 1, "hauntedhouse2", "down"}
};
