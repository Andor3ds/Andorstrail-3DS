#include "snakecave3_map.h"

const MapPlace snakecave3_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 10, 29, 1, 1, "south", "", "", 0, 0, ""},
    {"sign_snakecave3_grave", MAP_PLACE_SIGN, 12, 3, 1, 1, "sign_snakecave3_grave", "", "", 0, 0, ""},
    {"ewmondold_snake_master_defeted_script_10", MAP_PLACE_SCRIPT, 3, 2, 6, 6, "ewmondold_snake_master_defeted_script_10", "", "", 0, 0, "step"},
    {"cavesnake2", MAP_PLACE_SPAWN, 9, 20, 5, 7, "cavesnake2", "", "", 0, 0, ""},
    {"cavesnake2_boss", MAP_PLACE_SPAWN, 11, 13, 3, 7, "cavesnake2_boss", "", "", 0, 0, ""},
    {"cavesnake3", MAP_PLACE_SPAWN, 9, 8, 5, 4, "cavesnake3", "", "", 0, 0, ""},
    {"cavesnake3_1", MAP_PLACE_SPAWN, 5, 13, 5, 10, "cavesnake3_1", "", "", 0, 0, ""},
    {"cavesnake3_2", MAP_PLACE_SPAWN, 1, 12, 4, 14, "cavesnake3_2", "", "", 0, 0, ""},
    {"cavesnake3_boss", MAP_PLACE_SPAWN, 1, 2, 13, 4, "cavesnake3_boss", "", "", 0, 0, ""},
    {"cavesnake3_3", MAP_PLACE_SPAWN, 3, 3, 6, 6, "cavesnake3_3", "", "", 0, 0, ""},
    {"cavesnake_master_ewmondold", MAP_PLACE_SPAWN, 4, 3, 4, 3, "cavesnake_master_ewmondold", "", "", 0, 0, ""}
};
const MapChangeEvent snakecave3_map_changes[] = {
    {10, 29, 1, 1, "snakecave2", "north"}
};
