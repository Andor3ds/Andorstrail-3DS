#ifndef ANDOR_BWMFILL7_MAP_H
#define ANDOR_BWMFILL7_MAP_H
#include "map_data.h"

#define BWMFILL7_WIDTH 13
#define BWMFILL7_HEIGHT 20
#define BWMFILL7_PIXEL_WIDTH (BWMFILL7_WIDTH * 32)
#define BWMFILL7_PIXEL_HEIGHT (BWMFILL7_HEIGHT * 32)
#define BWMFILL7_START_X 7
#define BWMFILL7_START_Y 0
#define BWMFILL7_PLACE_COUNT 7
#define BWMFILL7_MAP_CHANGE_COUNT 4

static const unsigned char bwmfill7_walkable[BWMFILL7_WIDTH * BWMFILL7_HEIGHT] = {
    0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1,
    0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1
};

extern const MapPlace bwmfill7_places[];
extern const unsigned int bwmfill7_place_count;
extern const MapChangeEvent bwmfill7_map_changes[];
extern const unsigned int bwmfill7_map_change_count;

#endif
