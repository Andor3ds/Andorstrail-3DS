#include "blackwater_mountain19_map.h"

const MapPlace blackwater_mountain19_places[] = {
    {"down", MAP_PLACE_MAPCHANGE, 2, 3, 1, 1, "down", "", "", 0, 0, ""},
    {"up", MAP_PLACE_MAPCHANGE, 7, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"gornaud_3", MAP_PLACE_SPAWN, 3, 8, 3, 1, "gornaud_3", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain19_map_changes[] = {
    {2, 3, 1, 1, "blackwater_mountain18", "up"},
    {7, 2, 1, 1, "blackwater_mountain20", "down"}
};
