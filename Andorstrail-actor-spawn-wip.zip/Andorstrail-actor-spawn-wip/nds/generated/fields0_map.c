#include "fields0_map.h"

const MapPlace fields0_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 7, 14, 3, 1, "south", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 0, 0, 12, 1, "north", "", "", 0, 0, ""},
    {"change1", MAP_PLACE_MAPCHANGE, 15, 14, 14, 1, "change1", "", "", 0, 0, ""},
    {"change3", MAP_PLACE_MAPCHANGE, 29, 1, 1, 14, "change3", "", "", 0, 0, ""},
    {"southwest", MAP_PLACE_MAPCHANGE, 1, 14, 3, 1, "southwest", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 4, 1, 10, "west2", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 1, 1, 2, "west1", "", "", 0, 0, ""},
    {"fieldwasp_0", MAP_PLACE_SPAWN, 2, 5, 2, 8, "fieldwasp_0", "", "", 0, 0, ""},
    {"rolwynn", MAP_PLACE_SPAWN, 13, 1, 16, 13, "rolwynn", "", "", 0, 0, ""}
};
const MapChangeEvent fields0_map_changes[] = {
    {7, 14, 3, 1, "crossroads", "north"},
    {0, 0, 12, 1, "fields1", "south"},
    {15, 14, 14, 1, "crossroads", "change1"},
    {29, 1, 1, 14, "loneford1", "change3"},
    {1, 14, 3, 1, "crossroads", "northwest"},
    {0, 4, 1, 10, "fields8", "east2"},
    {0, 1, 1, 2, "fields8", "east1"}
};
