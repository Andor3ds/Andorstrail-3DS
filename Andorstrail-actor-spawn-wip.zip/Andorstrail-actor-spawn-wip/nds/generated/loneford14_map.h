#ifndef ANDOR_LONEFORD14_MAP_H
#define ANDOR_LONEFORD14_MAP_H
#include "map_data.h"

#define LONEFORD14_WIDTH 11
#define LONEFORD14_HEIGHT 15
#define LONEFORD14_PIXEL_WIDTH (LONEFORD14_WIDTH * 32)
#define LONEFORD14_PIXEL_HEIGHT (LONEFORD14_HEIGHT * 32)
#define LONEFORD14_START_X 0
#define LONEFORD14_START_Y 13
#define LONEFORD14_PLACE_COUNT 2
#define LONEFORD14_MAP_CHANGE_COUNT 2

static const unsigned char loneford14_walkable[LONEFORD14_WIDTH * LONEFORD14_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace loneford14_places[];
extern const unsigned int loneford14_place_count;
extern const MapChangeEvent loneford14_map_changes[];
extern const unsigned int loneford14_map_change_count;

#endif
