#include "wild8_map.h"

const MapPlace wild8_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 19, 2, 1, 3, "east", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 3, "west", "", "", 0, 0, ""},
    {"forestserpent2", MAP_PLACE_SPAWN, 5, 9, 10, 4, "forestserpent2", "", "", 0, 0, ""},
    {"fox1", MAP_PLACE_SPAWN, 10, 2, 8, 4, "fox1", "", "", 0, 0, ""},
    {"forestwasp2", MAP_PLACE_SPAWN, 2, 4, 11, 7, "forestwasp2", "", "", 0, 0, ""}
};
const MapChangeEvent wild8_map_changes[] = {
    {19, 2, 1, 3, "wild7", "west"},
    {0, 5, 1, 3, "flagstone0", "east"}
};
