#ifndef ANDOR_FALLHAVEN_POTIONS_MAP_H
#define ANDOR_FALLHAVEN_POTIONS_MAP_H
#include "map_data.h"

#define FALLHAVEN_POTIONS_WIDTH 10
#define FALLHAVEN_POTIONS_HEIGHT 8
#define FALLHAVEN_POTIONS_PIXEL_WIDTH (FALLHAVEN_POTIONS_WIDTH * 32)
#define FALLHAVEN_POTIONS_PIXEL_HEIGHT (FALLHAVEN_POTIONS_HEIGHT * 32)
#define FALLHAVEN_POTIONS_START_X 2
#define FALLHAVEN_POTIONS_START_Y 7
#define FALLHAVEN_POTIONS_PLACE_COUNT 3
#define FALLHAVEN_POTIONS_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_potions_walkable[FALLHAVEN_POTIONS_WIDTH * FALLHAVEN_POTIONS_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 1, 0, 1, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_potions_places[];
extern const unsigned int fallhaven_potions_place_count;
extern const MapChangeEvent fallhaven_potions_map_changes[];
extern const unsigned int fallhaven_potions_map_change_count;

#endif
