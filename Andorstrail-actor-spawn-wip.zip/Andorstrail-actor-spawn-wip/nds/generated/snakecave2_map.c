#include "snakecave2_map.h"

const MapPlace snakecave2_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 19, 13, 1, 1, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 2, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"cavesnake2", MAP_PLACE_SPAWN, 1, 3, 6, 5, "cavesnake2", "", "", 0, 0, ""},
    {"cavesnake2_1", MAP_PLACE_SPAWN, 7, 3, 5, 1, "cavesnake2_1", "", "", 0, 0, ""},
    {"cavesnake2_2", MAP_PLACE_SPAWN, 12, 3, 7, 4, "cavesnake2_2", "", "", 0, 0, ""},
    {"cavesnake1", MAP_PLACE_SPAWN, 13, 11, 5, 5, "cavesnake1", "", "", 0, 0, ""},
    {"cavesnake2_3", MAP_PLACE_SPAWN, 6, 9, 6, 6, "cavesnake2_3", "", "", 0, 0, ""},
    {"cavesnake2_boss", MAP_PLACE_SPAWN, 10, 6, 4, 4, "cavesnake2_boss", "", "", 0, 0, ""}
};
const MapChangeEvent snakecave2_map_changes[] = {
    {19, 13, 1, 1, "snakecave1", "west"},
    {2, 0, 1, 1, "snakecave3", "south"}
};
