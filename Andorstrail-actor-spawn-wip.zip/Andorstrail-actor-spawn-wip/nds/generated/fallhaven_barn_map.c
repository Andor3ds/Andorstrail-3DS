#include "fallhaven_barn_map.h"

const MapPlace fallhaven_barn_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 12, 9, 2, 1, "entrance", "", "", 0, 0, ""},
    {"Gaela", MAP_PLACE_SPAWN, 1, 5, 1, 1, "Gaela", "", "", 0, 0, ""},
    {"Larcal", MAP_PLACE_SPAWN, 9, 5, 3, 2, "Larcal", "", "", 0, 0, ""},
    {"Unnmir", MAP_PLACE_SPAWN, 12, 3, 1, 1, "Unnmir", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_barn_map_changes[] = {
    {12, 9, 2, 1, "fallhaven_ne", "barn"}
};
