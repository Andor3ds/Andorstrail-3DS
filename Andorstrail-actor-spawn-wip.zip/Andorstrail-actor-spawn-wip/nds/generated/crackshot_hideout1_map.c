#include "crackshot_hideout1_map.h"

const MapPlace crackshot_hideout1_places[] = {
    {"East", MAP_PLACE_MAPCHANGE, 26, 4, 1, 4, "East", "", "", 0, 0, ""},
    {"Exit", MAP_PLACE_MAPCHANGE, 3, 2, 1, 1, "Exit", "", "", 0, 0, ""},
    {"guild03_blood_1_select", MAP_PLACE_SCRIPT, 8, 7, 1, 1, "guild03_blood_1_select", "", "", 0, 0, "enter"},
    {"guild03_blood_2_select", MAP_PLACE_SCRIPT, 17, 6, 1, 1, "guild03_blood_2_select", "", "", 0, 0, "enter"},
    {"guild03_blood_3_select", MAP_PLACE_SCRIPT, 22, 3, 1, 3, "guild03_blood_3_select", "", "", 0, 0, "enter"},
    {"larva_g03_1", MAP_PLACE_SPAWN, 1, 4, 4, 4, "larva_g03_1", "", "", 0, 0, ""},
    {"larva_g03_2", MAP_PLACE_SPAWN, 8, 3, 5, 4, "larva_g03_2", "", "", 0, 0, ""},
    {"larva_g03_3", MAP_PLACE_SPAWN, 6, 7, 2, 1, "larva_g03_3", "", "", 0, 0, ""},
    {"larva_g03_4", MAP_PLACE_SPAWN, 18, 4, 4, 4, "larva_g03_4", "", "", 0, 0, ""},
    {"larva_g03_5", MAP_PLACE_SPAWN, 14, 6, 1, 1, "larva_g03_5", "", "", 0, 0, ""},
    {"unknown", MAP_PLACE_SPAWN, 14, 1, 1, 1, "unknown", "", "", 0, 0, ""}
};
const MapChangeEvent crackshot_hideout1_map_changes[] = {
    {26, 4, 1, 4, "crackshot_hideout2", "West"},
    {3, 2, 1, 1, "woodcave0", "Entrance"}
};
