#ifndef ANDOR_BLACKWATER_MOUNTAIN70_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN70_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN70_WIDTH 10
#define BLACKWATER_MOUNTAIN70_HEIGHT 30
#define BLACKWATER_MOUNTAIN70_PIXEL_WIDTH (BLACKWATER_MOUNTAIN70_WIDTH * 32)
#define BLACKWATER_MOUNTAIN70_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN70_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN70_START_X 9
#define BLACKWATER_MOUNTAIN70_START_Y 16
#define BLACKWATER_MOUNTAIN70_PLACE_COUNT 20
#define BLACKWATER_MOUNTAIN70_MAP_CHANGE_COUNT 4

static const unsigned char blackwater_mountain70_walkable[BLACKWATER_MOUNTAIN70_WIDTH * BLACKWATER_MOUNTAIN70_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 0, 0, 1,
    0, 0, 0, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 1, 1,
    0, 0, 1, 1, 1, 0, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 1, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 1,
    0, 0, 1, 1, 1, 1, 1, 0, 1, 1,
    0, 0, 1, 0, 1, 1, 1, 0, 1, 1,
    0, 1, 1, 1, 1, 1, 1, 0, 1, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 1, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 1, 1,
    0, 1, 1, 1, 1, 0, 0, 0, 1, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain70_places[];
extern const unsigned int blackwater_mountain70_place_count;
extern const MapChangeEvent blackwater_mountain70_map_changes[];
extern const unsigned int blackwater_mountain70_map_change_count;

#endif
