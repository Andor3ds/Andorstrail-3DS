#ifndef ANDOR_FLAGSTONE_FILLER_EAST_1_MAP_H
#define ANDOR_FLAGSTONE_FILLER_EAST_1_MAP_H
#include "map_data.h"

#define FLAGSTONE_FILLER_EAST_1_WIDTH 20
#define FLAGSTONE_FILLER_EAST_1_HEIGHT 18
#define FLAGSTONE_FILLER_EAST_1_PIXEL_WIDTH (FLAGSTONE_FILLER_EAST_1_WIDTH * 32)
#define FLAGSTONE_FILLER_EAST_1_PIXEL_HEIGHT (FLAGSTONE_FILLER_EAST_1_HEIGHT * 32)
#define FLAGSTONE_FILLER_EAST_1_START_X 19
#define FLAGSTONE_FILLER_EAST_1_START_Y 1
#define FLAGSTONE_FILLER_EAST_1_PLACE_COUNT 9
#define FLAGSTONE_FILLER_EAST_1_MAP_CHANGE_COUNT 3

static const unsigned char flagstone_filler_east_1_walkable[FLAGSTONE_FILLER_EAST_1_WIDTH * FLAGSTONE_FILLER_EAST_1_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1,
    0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1,
    0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0,
    1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1,
    0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1,
    0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0
};

extern const MapPlace flagstone_filler_east_1_places[];
extern const unsigned int flagstone_filler_east_1_place_count;
extern const MapChangeEvent flagstone_filler_east_1_map_changes[];
extern const unsigned int flagstone_filler_east_1_map_change_count;

#endif
