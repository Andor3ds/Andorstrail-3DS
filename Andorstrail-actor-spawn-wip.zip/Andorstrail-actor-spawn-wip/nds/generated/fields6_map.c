#include "fields6_map.h"

const MapPlace fields6_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 0, 27, 30, 1, "south", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 4, 1, 23, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 12, 1, 15, "east", "", "", 0, 0, ""},
    {"sign_fields6", MAP_PLACE_SIGN, 15, 24, 1, 1, "sign_fields6", "", "", 0, 0, ""},
    {"brv_patrol_check_stop_hero", MAP_PLACE_SCRIPT, 2, 14, 22, 12, "brv_patrol_check_stop_hero", "", "", 0, 0, "enter"},
    {"tinlyn", MAP_PLACE_SPAWN, 12, 20, 1, 1, "tinlyn", "", "", 0, 0, ""},
    {"tinlyn_sheep", MAP_PLACE_SPAWN, 6, 13, 8, 7, "tinlyn_sheep", "", "", 0, 0, ""},
    {"fieldcritter_0", MAP_PLACE_SPAWN, 2, 3, 13, 6, "fieldcritter_0", "", "", 0, 0, ""},
    {"fieldcritter_0_1", MAP_PLACE_SPAWN, 19, 22, 9, 4, "fieldcritter_0_1", "", "", 0, 0, ""},
    {"fieldcritter_0_2", MAP_PLACE_SPAWN, 16, 8, 5, 6, "fieldcritter_0_2", "", "", 0, 0, ""},
    {"knights", MAP_PLACE_SPAWN, 1, 13, 24, 14, "knights", "", "", 0, 0, ""},
    {"stop_hero", MAP_PLACE_KEY, 1, 13, 24, 14, "brv_wait_patrol", "questProgress", "brv_nondisplay", 140, 1, ""}
};
const MapChangeEvent fields6_map_changes[] = {
    {0, 27, 30, 1, "fields1", "north"},
    {0, 4, 1, 23, "fields5", "east"},
    {29, 12, 1, 15, "fields7", "west"}
};
