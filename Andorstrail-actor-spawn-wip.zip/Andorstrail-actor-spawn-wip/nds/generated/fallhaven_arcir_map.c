#include "fallhaven_arcir_map.h"

const MapPlace fallhaven_arcir_places[] = {
    {"down", MAP_PLACE_MAPCHANGE, 7, 8, 1, 1, "down", "", "", 0, 0, ""},
    {"entrance", MAP_PLACE_MAPCHANGE, 11, 9, 1, 1, "entrance", "", "", 0, 0, ""},
    {"Arcir", MAP_PLACE_SPAWN, 2, 3, 12, 4, "Arcir", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_arcir_map_changes[] = {
    {7, 8, 1, 1, "fallhaven_arcir_basement", "up"},
    {11, 9, 1, 1, "fallhaven_nw", "arcir"}
};
