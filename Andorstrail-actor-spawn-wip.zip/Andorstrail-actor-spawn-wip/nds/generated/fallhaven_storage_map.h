#ifndef ANDOR_FALLHAVEN_STORAGE_MAP_H
#define ANDOR_FALLHAVEN_STORAGE_MAP_H
#include "map_data.h"

#define FALLHAVEN_STORAGE_WIDTH 15
#define FALLHAVEN_STORAGE_HEIGHT 10
#define FALLHAVEN_STORAGE_PIXEL_WIDTH (FALLHAVEN_STORAGE_WIDTH * 32)
#define FALLHAVEN_STORAGE_PIXEL_HEIGHT (FALLHAVEN_STORAGE_HEIGHT * 32)
#define FALLHAVEN_STORAGE_START_X 11
#define FALLHAVEN_STORAGE_START_Y 9
#define FALLHAVEN_STORAGE_PLACE_COUNT 2
#define FALLHAVEN_STORAGE_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_storage_walkable[FALLHAVEN_STORAGE_WIDTH * FALLHAVEN_STORAGE_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0
};

extern const MapPlace fallhaven_storage_places[];
extern const unsigned int fallhaven_storage_place_count;
extern const MapChangeEvent fallhaven_storage_map_changes[];
extern const unsigned int fallhaven_storage_map_change_count;

#endif
