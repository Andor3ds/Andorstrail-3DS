#ifndef ANDOR_FALLHAVEN_NOCMAR_MAP_H
#define ANDOR_FALLHAVEN_NOCMAR_MAP_H
#include "map_data.h"

#define FALLHAVEN_NOCMAR_WIDTH 12
#define FALLHAVEN_NOCMAR_HEIGHT 8
#define FALLHAVEN_NOCMAR_PIXEL_WIDTH (FALLHAVEN_NOCMAR_WIDTH * 32)
#define FALLHAVEN_NOCMAR_PIXEL_HEIGHT (FALLHAVEN_NOCMAR_HEIGHT * 32)
#define FALLHAVEN_NOCMAR_START_X 7
#define FALLHAVEN_NOCMAR_START_Y 7
#define FALLHAVEN_NOCMAR_PLACE_COUNT 2
#define FALLHAVEN_NOCMAR_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_nocmar_walkable[FALLHAVEN_NOCMAR_WIDTH * FALLHAVEN_NOCMAR_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0
};

extern const MapPlace fallhaven_nocmar_places[];
extern const unsigned int fallhaven_nocmar_place_count;
extern const MapChangeEvent fallhaven_nocmar_map_changes[];
extern const unsigned int fallhaven_nocmar_map_change_count;

#endif
