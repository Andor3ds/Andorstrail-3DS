#ifndef ANDOR_BLACKWATER_MOUNTAIN18_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN18_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN18_WIDTH 15
#define BLACKWATER_MOUNTAIN18_HEIGHT 22
#define BLACKWATER_MOUNTAIN18_PIXEL_WIDTH (BLACKWATER_MOUNTAIN18_WIDTH * 32)
#define BLACKWATER_MOUNTAIN18_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN18_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN18_START_X 3
#define BLACKWATER_MOUNTAIN18_START_Y 0
#define BLACKWATER_MOUNTAIN18_PLACE_COUNT 8
#define BLACKWATER_MOUNTAIN18_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain18_walkable[BLACKWATER_MOUNTAIN18_WIDTH * BLACKWATER_MOUNTAIN18_HEIGHT] = {
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain18_places[];
extern const unsigned int blackwater_mountain18_place_count;
extern const MapChangeEvent blackwater_mountain18_map_changes[];
extern const unsigned int blackwater_mountain18_map_change_count;

#endif
