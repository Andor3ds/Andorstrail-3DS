#ifndef ANDOR_BLACKWATER_MOUNTAIN56_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN56_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN56_WIDTH 21
#define BLACKWATER_MOUNTAIN56_HEIGHT 20
#define BLACKWATER_MOUNTAIN56_PIXEL_WIDTH (BLACKWATER_MOUNTAIN56_WIDTH * 32)
#define BLACKWATER_MOUNTAIN56_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN56_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN56_START_X 20
#define BLACKWATER_MOUNTAIN56_START_Y 3
#define BLACKWATER_MOUNTAIN56_PLACE_COUNT 6
#define BLACKWATER_MOUNTAIN56_MAP_CHANGE_COUNT 3

static const unsigned char blackwater_mountain56_walkable[BLACKWATER_MOUNTAIN56_WIDTH * BLACKWATER_MOUNTAIN56_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1,
    1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0
};

extern const MapPlace blackwater_mountain56_places[];
extern const unsigned int blackwater_mountain56_place_count;
extern const MapChangeEvent blackwater_mountain56_map_changes[];
extern const unsigned int blackwater_mountain56_map_change_count;

#endif
