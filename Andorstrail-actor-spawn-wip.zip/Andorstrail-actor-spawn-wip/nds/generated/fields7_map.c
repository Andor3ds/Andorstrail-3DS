#include "fields7_map.h"

const MapPlace fields7_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 8, 1, 15, "west", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 0, 23, 20, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 26, 3, 1, 1, "east", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 26, 7, 1, 14, "east2", "", "", 0, 0, ""},
    {"fieldcritter_1", MAP_PLACE_SPAWN, 2, 10, 18, 12, "fieldcritter_1", "", "", 0, 0, ""},
    {"frog_1", MAP_PLACE_SPAWN, 7, 4, 13, 5, "frog_1", "", "", 0, 0, ""}
};
const MapChangeEvent fields7_map_changes[] = {
    {0, 8, 1, 15, "fields6", "east"},
    {0, 23, 20, 1, "fields4", "north"},
    {26, 3, 1, 1, "fields11", "west"},
    {26, 7, 1, 14, "fields11b", "west2"}
};
