#include "fallhaven_prison_map.h"

const MapPlace fallhaven_prison_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 5, 9, 1, 1, "entrance", "", "", 0, 0, ""},
    {"fallhaven_prisoner", MAP_PLACE_SPAWN, 9, 3, 5, 3, "fallhaven_prisoner", "", "", 0, 0, ""},
    {"fallhaven_guard", MAP_PLACE_SPAWN, 13, 7, 1, 1, "fallhaven_guard", "", "", 0, 0, ""},
    {"fallhaven_guard_1", MAP_PLACE_SPAWN, 1, 7, 1, 1, "fallhaven_guard_1", "", "", 0, 0, ""},
    {"fallhaven_warden", MAP_PLACE_SPAWN, 3, 4, 1, 1, "fallhaven_warden", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_prison_map_changes[] = {
    {5, 9, 1, 1, "fallhaven_nw", "prison"}
};
