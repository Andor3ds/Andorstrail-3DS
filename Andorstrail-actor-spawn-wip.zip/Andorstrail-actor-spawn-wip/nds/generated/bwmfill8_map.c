#include "bwmfill8_map.h"

const MapPlace bwmfill8_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 8, 2, 1, 13, "east", "", "", 0, 0, ""},
    {"gornaud2_2", MAP_PLACE_SPAWN, 6, 12, 2, 6, "gornaud2_2", "", "", 0, 0, ""},
    {"gornaud_boss", MAP_PLACE_SPAWN, 2, 15, 3, 6, "gornaud_boss", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill8_map_changes[] = {
    {8, 2, 1, 13, "wild6", "west"}
};
