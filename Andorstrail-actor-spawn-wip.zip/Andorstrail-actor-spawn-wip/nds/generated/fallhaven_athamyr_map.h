#ifndef ANDOR_FALLHAVEN_ATHAMYR_MAP_H
#define ANDOR_FALLHAVEN_ATHAMYR_MAP_H
#include "map_data.h"

#define FALLHAVEN_ATHAMYR_WIDTH 10
#define FALLHAVEN_ATHAMYR_HEIGHT 8
#define FALLHAVEN_ATHAMYR_PIXEL_WIDTH (FALLHAVEN_ATHAMYR_WIDTH * 32)
#define FALLHAVEN_ATHAMYR_PIXEL_HEIGHT (FALLHAVEN_ATHAMYR_HEIGHT * 32)
#define FALLHAVEN_ATHAMYR_START_X 2
#define FALLHAVEN_ATHAMYR_START_Y 7
#define FALLHAVEN_ATHAMYR_PLACE_COUNT 2
#define FALLHAVEN_ATHAMYR_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_athamyr_walkable[FALLHAVEN_ATHAMYR_WIDTH * FALLHAVEN_ATHAMYR_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_athamyr_places[];
extern const unsigned int fallhaven_athamyr_place_count;
extern const MapChangeEvent fallhaven_athamyr_map_changes[];
extern const unsigned int fallhaven_athamyr_map_change_count;

#endif
