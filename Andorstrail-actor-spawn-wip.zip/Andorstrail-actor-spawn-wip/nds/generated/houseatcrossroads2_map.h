#ifndef ANDOR_HOUSEATCROSSROADS2_MAP_H
#define ANDOR_HOUSEATCROSSROADS2_MAP_H
#include "map_data.h"

#define HOUSEATCROSSROADS2_WIDTH 6
#define HOUSEATCROSSROADS2_HEIGHT 6
#define HOUSEATCROSSROADS2_PIXEL_WIDTH (HOUSEATCROSSROADS2_WIDTH * 32)
#define HOUSEATCROSSROADS2_PIXEL_HEIGHT (HOUSEATCROSSROADS2_HEIGHT * 32)
#define HOUSEATCROSSROADS2_START_X 1
#define HOUSEATCROSSROADS2_START_Y 0
#define HOUSEATCROSSROADS2_PLACE_COUNT 3
#define HOUSEATCROSSROADS2_MAP_CHANGE_COUNT 2

static const unsigned char houseatcrossroads2_walkable[HOUSEATCROSSROADS2_WIDTH * HOUSEATCROSSROADS2_HEIGHT] = {
    0, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0,
    0, 1, 0, 1, 0, 0,
    0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0
};

extern const MapPlace houseatcrossroads2_places[];
extern const unsigned int houseatcrossroads2_place_count;
extern const MapChangeEvent houseatcrossroads2_map_changes[];
extern const unsigned int houseatcrossroads2_map_change_count;

#endif
