#include "lake_shore_road_1_map.h"

const MapPlace lake_shore_road_1_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 22, 13, 1, 2, "east", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 1, 1, 19, "west", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 2, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"outside", MAP_PLACE_MAPCHANGE, 13, 8, 1, 1, "outside", "", "", 0, 0, ""},
    {"fish_school_spawn", MAP_PLACE_SPAWN, 2, 27, 21, 3, "fish_school_spawn", "", "", 0, 0, ""},
    {"emmeline_spawn", MAP_PLACE_SPAWN, 10, 2, 1, 1, "emmeline_spawn", "", "", 0, 0, ""},
    {"small_stone_worm", MAP_PLACE_SPAWN, 18, 10, 3, 5, "small_stone_worm", "", "", 0, 0, ""},
    {"wolf_spawn", MAP_PLACE_SPAWN, 20, 4, 2, 1, "wolf_spawn", "", "", 0, 0, ""},
    {"wolf_spawn2", MAP_PLACE_SPAWN, 2, 2, 4, 12, "wolf_spawn2", "", "", 0, 0, ""},
    {"forest_serpent_spawn1", MAP_PLACE_SPAWN, 6, 14, 9, 2, "forest_serpent_spawn1", "", "", 0, 0, ""}
};
const MapChangeEvent lake_shore_road_1_map_changes[] = {
    {22, 13, 1, 2, "mywildcave", "west"},
    {0, 1, 1, 19, "lake_shore_road_0", "east"},
    {2, 0, 2, 1, "mywild18", "south"},
    {13, 8, 1, 1, "witch_house", "inside"}
};
