#ifndef ANDOR_ROADBEFORECROSSROADS4_MAP_H
#define ANDOR_ROADBEFORECROSSROADS4_MAP_H
#include "map_data.h"

#define ROADBEFORECROSSROADS4_WIDTH 20
#define ROADBEFORECROSSROADS4_HEIGHT 20
#define ROADBEFORECROSSROADS4_PIXEL_WIDTH (ROADBEFORECROSSROADS4_WIDTH * 32)
#define ROADBEFORECROSSROADS4_PIXEL_HEIGHT (ROADBEFORECROSSROADS4_HEIGHT * 32)
#define ROADBEFORECROSSROADS4_START_X 0
#define ROADBEFORECROSSROADS4_START_Y 0
#define ROADBEFORECROSSROADS4_PLACE_COUNT 7
#define ROADBEFORECROSSROADS4_MAP_CHANGE_COUNT 4

static const unsigned char roadbeforecrossroads4_walkable[ROADBEFORECROSSROADS4_WIDTH * ROADBEFORECROSSROADS4_HEIGHT] = {
    1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0,
    1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0,
    1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0
};

extern const MapPlace roadbeforecrossroads4_places[];
extern const unsigned int roadbeforecrossroads4_place_count;
extern const MapChangeEvent roadbeforecrossroads4_map_changes[];
extern const unsigned int roadbeforecrossroads4_map_change_count;

#endif
