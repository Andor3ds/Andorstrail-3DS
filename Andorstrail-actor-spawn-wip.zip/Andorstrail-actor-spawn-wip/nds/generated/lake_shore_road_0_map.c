#include "lake_shore_road_0_map.h"

const MapPlace lake_shore_road_0_places[] = {
    {"c1", MAP_PLACE_MAPCHANGE, 17, 14, 1, 1, "c1", "", "", 0, 0, ""},
    {"c2", MAP_PLACE_MAPCHANGE, 16, 17, 1, 1, "c2", "", "", 0, 0, ""},
    {"c3", MAP_PLACE_MAPCHANGE, 14, 15, 1, 1, "c3", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 3, 21, 14, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 1, 1, 19, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 10, 0, 4, 1, "north", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 16, "west", "", "", 0, 0, ""},
    {"wicked_witch_reveal_girl_selector", MAP_PLACE_SCRIPT, 1, 1, 16, 20, "wicked_witch_reveal_girl_selector", "", "", 0, 0, "always"},
    {"wolf_spawn1", MAP_PLACE_SPAWN, 2, 1, 2, 3, "wolf_spawn1", "", "", 0, 0, ""},
    {"wolf_spawn2", MAP_PLACE_SPAWN, 9, 12, 4, 5, "wolf_spawn2", "", "", 0, 0, ""},
    {"forest_serpent_spawn1", MAP_PLACE_SPAWN, 3, 11, 2, 8, "forest_serpent_spawn1", "", "", 0, 0, ""},
    {"forest_serpent_spawn2", MAP_PLACE_SPAWN, 6, 4, 8, 6, "forest_serpent_spawn2", "", "", 0, 0, ""},
    {"stn_lizard_spawn1", MAP_PLACE_SPAWN, 6, 18, 10, 2, "stn_lizard_spawn1", "", "", 0, 0, ""},
    {"witch_playing_kid", MAP_PLACE_SPAWN, 15, 15, 3, 2, "witch_playing_kid", "", "", 0, 0, ""}
};
const MapChangeEvent lake_shore_road_0_map_changes[] = {
    {17, 14, 1, 1, "lake_shore_road_0", "c2"},
    {16, 17, 1, 1, "lake_shore_road_0", "c3"},
    {14, 15, 1, 1, "lake_shore_road_0", "c1"},
    {3, 21, 14, 1, "lake_shore_road_2", "north"},
    {19, 1, 1, 19, "lake_shore_road_1", "west"},
    {10, 0, 4, 1, "wild7", "south"},
    {0, 5, 1, 16, "flagstone_filler_east_1", "east"}
};
