#include "roadbeforecrossroads5_map.h"

const MapPlace roadbeforecrossroads5_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 9, 0, 7, 1, "north", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 13, 1, 8, "east", "", "", 0, 0, ""},
    {"sign_pathway_fallhaven", MAP_PLACE_SIGN, 10, 12, 1, 1, "sign_pathway_fallhaven", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 3, "west", "", "", 0, 0, ""},
    {"achieve_road", MAP_PLACE_SCRIPT, 9, 9, 1, 6, "achieve_road", "", "", 0, 0, ""},
    {"forestboar3", MAP_PLACE_SPAWN, 4, 9, 6, 6, "forestboar3", "", "", 0, 0, ""},
    {"forestserpent2", MAP_PLACE_SPAWN, 4, 13, 6, 7, "forestserpent2", "", "", 0, 0, ""},
    {"forestserpent2_1", MAP_PLACE_SPAWN, 16, 11, 2, 3, "forestserpent2_1", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 11, 17, 2, 3, "forestboar2", "", "", 0, 0, ""}
};
const MapChangeEvent roadbeforecrossroads5_map_changes[] = {
    {9, 0, 7, 1, "roadbeforecrossroads4", "south"},
    {19, 13, 1, 8, "roadbeforecrossroads6", "west"},
    {0, 5, 1, 3, "fallhaven_ne", "east"}
};
