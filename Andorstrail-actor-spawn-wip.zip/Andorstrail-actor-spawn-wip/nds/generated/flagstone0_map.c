#include "flagstone0_map.h"

const MapPlace flagstone0_places[] = {
    {"house", MAP_PLACE_MAPCHANGE, 24, 24, 1, 1, "house", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 4, 1, 3, "east", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 8, 1, 3, "west", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 5, 29, 1, 1, "south", "", "", 0, 0, ""},
    {"stoutford_guard1", MAP_PLACE_SPAWN, 12, 11, 2, 1, "stoutford_guard1", "", "", 0, 0, ""},
    {"stn_gyra_50", MAP_PLACE_SCRIPT, 1, 10, 7, 1, "stn_gyra_50", "", "", 0, 0, ""},
    {"stn_gyra_m28_1", MAP_PLACE_SCRIPT, 1, 27, 6, 1, "stn_gyra_m28_1", "", "", 0, 0, ""},
    {"southeast", MAP_PLACE_MAPCHANGE, 29, 25, 1, 1, "southeast", "", "", 0, 0, ""},
    {"forestboar3", MAP_PLACE_SPAWN, 26, 5, 1, 1, "forestboar3", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 17, 5, 9, 4, "forestboar2", "", "", 0, 0, ""},
    {"forestbeetle", MAP_PLACE_SPAWN, 2, 14, 7, 14, "forestbeetle", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 2, 3, 6, 7, "forestwolf1", "", "", 0, 0, ""},
    {"cavesnake2_boss", MAP_PLACE_SPAWN, 19, 12, 1, 1, "cavesnake2_boss", "", "", 0, 0, ""},
    {"flagstone_sentry", MAP_PLACE_SPAWN, 12, 9, 1, 1, "flagstone_sentry", "", "", 0, 0, ""},
    {"prisoner1", MAP_PLACE_SPAWN, 24, 16, 1, 1, "prisoner1", "", "", 0, 0, ""},
    {"cavesnake2_boss_1", MAP_PLACE_SPAWN, 27, 21, 1, 1, "cavesnake2_boss_1", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 27, 24, 1, 1, "forestserpent1", "", "", 0, 0, ""},
    {"flagstone_guard", MAP_PLACE_SPAWN, 9, 4, 7, 7, "flagstone_guard", "", "", 0, 0, ""},
    {"stn_lizard", MAP_PLACE_SPAWN, 3, 3, 24, 8, "stn_lizard", "", "", 0, 0, ""},
    {"stn_gyra1", MAP_PLACE_SPAWN, 4, 28, 2, 1, "stn_gyra1", "", "", 0, 0, ""},
    {"stn_gyra2", MAP_PLACE_SPAWN, 3, 12, 2, 1, "stn_gyra2", "", "", 0, 0, ""},
    {"base_nondisplay:2", MAP_PLACE_KEY, 2, 11, 4, 1, "stn_gyra_52", "questProgress", "base_nondisplay", 2, 1, ""}
};
const MapChangeEvent flagstone0_map_changes[] = {
    {24, 24, 1, 1, "flagstone_inner", "entrance"},
    {29, 4, 1, 3, "wild8", "west"},
    {0, 8, 1, 3, "wild16", "east"},
    {5, 29, 1, 1, "waytogalmore0", "north"},
    {29, 25, 1, 1, "flagstone_filler_east_1", "west"}
};
