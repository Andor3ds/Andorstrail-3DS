#ifndef ANDOR_BLACKWATER_MOUNTAIN20_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN20_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN20_WIDTH 10
#define BLACKWATER_MOUNTAIN20_HEIGHT 20
#define BLACKWATER_MOUNTAIN20_PIXEL_WIDTH (BLACKWATER_MOUNTAIN20_WIDTH * 32)
#define BLACKWATER_MOUNTAIN20_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN20_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN20_START_X 6
#define BLACKWATER_MOUNTAIN20_START_Y 12
#define BLACKWATER_MOUNTAIN20_PLACE_COUNT 5
#define BLACKWATER_MOUNTAIN20_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain20_walkable[BLACKWATER_MOUNTAIN20_WIDTH * BLACKWATER_MOUNTAIN20_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain20_places[];
extern const unsigned int blackwater_mountain20_place_count;
extern const MapChangeEvent blackwater_mountain20_map_changes[];
extern const unsigned int blackwater_mountain20_map_change_count;

#endif
