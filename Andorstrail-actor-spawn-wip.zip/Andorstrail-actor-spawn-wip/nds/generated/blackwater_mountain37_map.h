#ifndef ANDOR_BLACKWATER_MOUNTAIN37_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN37_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN37_WIDTH 15
#define BLACKWATER_MOUNTAIN37_HEIGHT 15
#define BLACKWATER_MOUNTAIN37_PIXEL_WIDTH (BLACKWATER_MOUNTAIN37_WIDTH * 32)
#define BLACKWATER_MOUNTAIN37_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN37_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN37_START_X 3
#define BLACKWATER_MOUNTAIN37_START_Y 3
#define BLACKWATER_MOUNTAIN37_PLACE_COUNT 7
#define BLACKWATER_MOUNTAIN37_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain37_walkable[BLACKWATER_MOUNTAIN37_WIDTH * BLACKWATER_MOUNTAIN37_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain37_places[];
extern const unsigned int blackwater_mountain37_place_count;
extern const MapChangeEvent blackwater_mountain37_map_changes[];
extern const unsigned int blackwater_mountain37_map_change_count;

#endif
