#ifndef ANDOR_HOUSEATCROSSROADS3_MAP_H
#define ANDOR_HOUSEATCROSSROADS3_MAP_H
#include "map_data.h"

#define HOUSEATCROSSROADS3_WIDTH 6
#define HOUSEATCROSSROADS3_HEIGHT 6
#define HOUSEATCROSSROADS3_PIXEL_WIDTH (HOUSEATCROSSROADS3_WIDTH * 32)
#define HOUSEATCROSSROADS3_PIXEL_HEIGHT (HOUSEATCROSSROADS3_HEIGHT * 32)
#define HOUSEATCROSSROADS3_START_X 3
#define HOUSEATCROSSROADS3_START_Y 3
#define HOUSEATCROSSROADS3_PLACE_COUNT 3
#define HOUSEATCROSSROADS3_MAP_CHANGE_COUNT 2

static const unsigned char houseatcrossroads3_walkable[HOUSEATCROSSROADS3_WIDTH * HOUSEATCROSSROADS3_HEIGHT] = {
    0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0,
    0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0
};

extern const MapPlace houseatcrossroads3_places[];
extern const unsigned int houseatcrossroads3_place_count;
extern const MapChangeEvent houseatcrossroads3_map_changes[];
extern const unsigned int houseatcrossroads3_map_change_count;

#endif
