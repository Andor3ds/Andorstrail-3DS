#ifndef ANDOR_WHITE_HOUSE_MAP_H
#define ANDOR_WHITE_HOUSE_MAP_H
#include "map_data.h"

#define WHITE_HOUSE_WIDTH 8
#define WHITE_HOUSE_HEIGHT 8
#define WHITE_HOUSE_PIXEL_WIDTH (WHITE_HOUSE_WIDTH * 32)
#define WHITE_HOUSE_PIXEL_HEIGHT (WHITE_HOUSE_HEIGHT * 32)
#define WHITE_HOUSE_START_X 3
#define WHITE_HOUSE_START_Y 7
#define WHITE_HOUSE_PLACE_COUNT 6
#define WHITE_HOUSE_MAP_CHANGE_COUNT 2

static const unsigned char white_house_walkable[WHITE_HOUSE_WIDTH * WHITE_HOUSE_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 0, 0, 0, 0
};

extern const MapPlace white_house_places[];
extern const unsigned int white_house_place_count;
extern const MapChangeEvent white_house_map_changes[];
extern const unsigned int white_house_map_change_count;

#endif
