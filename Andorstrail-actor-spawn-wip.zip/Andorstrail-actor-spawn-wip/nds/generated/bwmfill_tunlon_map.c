#include "bwmfill_tunlon_map.h"

const MapPlace bwmfill_tunlon_places[] = {
    {"door1", MAP_PLACE_MAPCHANGE, 4, 7, 1, 1, "door1", "", "", 0, 0, ""},
    {"door2", MAP_PLACE_MAPCHANGE, 11, 7, 2, 1, "door2", "", "", 0, 0, ""},
    {"bwm_sheep1", MAP_PLACE_SPAWN, 9, 3, 6, 4, "bwm_sheep1", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill_tunlon_map_changes[] = {
    {4, 7, 1, 1, "bwmfill3", "house1"},
    {11, 7, 2, 1, "bwmfill3", "house2"}
};
