#include "loneford17_map.h"

const MapPlace loneford17_places[] = {
    {"inside2", MAP_PLACE_MAPCHANGE, 3, 7, 1, 1, "inside2", "", "", 0, 0, ""},
    {"taret", MAP_PLACE_SPAWN, 1, 3, 7, 3, "taret", "", "", 0, 0, ""}
};
const MapChangeEvent loneford17_map_changes[] = {
    {3, 7, 1, 1, "loneford13", "outside2"}
};
