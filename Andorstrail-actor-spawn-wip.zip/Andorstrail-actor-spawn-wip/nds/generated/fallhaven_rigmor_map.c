#include "fallhaven_rigmor_map.h"

const MapPlace fallhaven_rigmor_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 2, 9, 1, 1, "entrance", "", "", 0, 0, ""},
    {"Rigmor", MAP_PLACE_SPAWN, 2, 3, 12, 5, "Rigmor", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_rigmor_map_changes[] = {
    {2, 9, 1, 1, "fallhaven_nw", "rigmor"}
};
