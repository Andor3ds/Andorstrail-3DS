#include "blackwater_mountain16_map.h"

const MapPlace blackwater_mountain16_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 3, "west", "", "", 0, 0, ""},
    {"sign_blackwater16", MAP_PLACE_SIGN, 13, 13, 1, 1, "sign_blackwater16", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 26, 1, 2, "west2", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 11, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 4, 29, 3, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 14, 4, 1, 3, "east", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 14, 22, 1, 7, "east2", "", "", 0, 0, ""},
    {"gornaud_1", MAP_PLACE_SPAWN, 6, 21, 3, 1, "gornaud_1", "", "", 0, 0, ""},
    {"gornaud_2", MAP_PLACE_SPAWN, 1, 9, 2, 2, "gornaud_2", "", "", 0, 0, ""},
    {"gornaud_2_1", MAP_PLACE_SPAWN, 4, 6, 1, 4, "gornaud_2_1", "", "", 0, 0, ""},
    {"gornaud_2_2", MAP_PLACE_SPAWN, 1, 11, 5, 6, "gornaud_2_2", "", "", 0, 0, ""},
    {"gornaud_1_1", MAP_PLACE_SPAWN, 7, 8, 3, 6, "gornaud_1_1", "", "", 0, 0, ""},
    {"gornaud_2_3", MAP_PLACE_SPAWN, 7, 14, 3, 3, "gornaud_2_3", "", "", 0, 0, ""},
    {"gornaud_2_4", MAP_PLACE_SPAWN, 3, 1, 11, 5, "gornaud_2_4", "", "", 0, 0, ""},
    {"gornaud_1_2", MAP_PLACE_SPAWN, 10, 5, 4, 11, "gornaud_1_2", "", "", 0, 0, ""},
    {"gornaud_1_3", MAP_PLACE_SPAWN, 3, 17, 7, 4, "gornaud_1_3", "", "", 0, 0, ""},
    {"gornaud_2_5", MAP_PLACE_SPAWN, 2, 24, 5, 4, "gornaud_2_5", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain16_map_changes[] = {
    {0, 5, 1, 3, "blackwater_mountain15", "east"},
    {0, 26, 1, 2, "blackwater_mountain15", "east2"},
    {11, 0, 2, 1, "blackwater_mountain53", "south"},
    {4, 29, 3, 1, "blackwater_mountain56", "north"},
    {14, 4, 1, 3, "bwmfill2", "west"},
    {14, 22, 1, 7, "bwmfill3", "west"}
};
