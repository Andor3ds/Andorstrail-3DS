#include "fallhaven_arcir_basement_map.h"

const MapPlace fallhaven_arcir_basement_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 11, 7, 1, 1, "up", "", "", 0, 0, ""},
    {"arcir_basement_statue", MAP_PLACE_SIGN, 1, 4, 2, 1, "arcir_basement_statue", "", "", 0, 0, ""},
    {"arcir_basement_tornpage", MAP_PLACE_SIGN, 4, 7, 1, 1, "arcir_basement_tornpage", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_arcir_basement_map_changes[] = {
    {11, 7, 1, 1, "fallhaven_arcir", "down"}
};
