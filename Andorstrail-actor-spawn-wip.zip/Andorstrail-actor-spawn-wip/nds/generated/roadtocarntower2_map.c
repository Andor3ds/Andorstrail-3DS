#include "roadtocarntower2_map.h"

const MapPlace roadtocarntower2_places[] = {
    {"north1", MAP_PLACE_MAPCHANGE, 29, 1, 1, 4, "north1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 29, 6, 1, 2, "north2", "", "", 0, 0, ""},
    {"north4", MAP_PLACE_MAPCHANGE, 29, 13, 1, 4, "north4", "", "", 0, 0, ""},
    {"north3", MAP_PLACE_MAPCHANGE, 29, 10, 1, 2, "north3", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 19, 0, 10, 1, "north", "", "", 0, 0, ""},
    {"watermark_script", MAP_PLACE_SCRIPT, 15, 21, 1, 1, "watermark_script", "", "", 0, 0, ""},
    {"watermark_script2", MAP_PLACE_SCRIPT, 17, 22, 2, 1, "watermark_script2", "", "", 0, 0, ""},
    {"fieldwasp_unique", MAP_PLACE_SPAWN, 17, 2, 11, 12, "fieldwasp_unique", "", "", 0, 0, ""},
    {"rogorn", MAP_PLACE_SPAWN, 3, 19, 1, 1, "rogorn", "", "", 0, 0, ""},
    {"rogorn_henchman", MAP_PLACE_SPAWN, 2, 19, 1, 1, "rogorn_henchman", "", "", 0, 0, ""},
    {"rogorn_henchman_1", MAP_PLACE_SPAWN, 2, 18, 1, 1, "rogorn_henchman_1", "", "", 0, 0, ""},
    {"rivertroll", MAP_PLACE_SPAWN, 12, 15, 1, 1, "rivertroll", "", "", 0, 0, ""},
    {"river_mermaid", MAP_PLACE_SPAWN, 8, 17, 7, 8, "river_mermaid", "", "", 0, 0, ""},
    {"fieldwasp_2", MAP_PLACE_SPAWN, 17, 2, 11, 12, "fieldwasp_2", "", "", 0, 0, ""}
};
const MapChangeEvent roadtocarntower2_map_changes[] = {
    {29, 1, 1, 4, "roadtocarntower1", "left1"},
    {29, 6, 1, 2, "roadtocarntower1", "left2"},
    {29, 13, 1, 4, "roadtocarntower1", "left4"},
    {29, 10, 1, 2, "roadtocarntower1", "left3"},
    {19, 0, 10, 1, "fields10", "south"}
};
