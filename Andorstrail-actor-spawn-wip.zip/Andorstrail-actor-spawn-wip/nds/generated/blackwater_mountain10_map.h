#ifndef ANDOR_BLACKWATER_MOUNTAIN10_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN10_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN10_WIDTH 20
#define BLACKWATER_MOUNTAIN10_HEIGHT 20
#define BLACKWATER_MOUNTAIN10_PIXEL_WIDTH (BLACKWATER_MOUNTAIN10_WIDTH * 32)
#define BLACKWATER_MOUNTAIN10_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN10_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN10_START_X 19
#define BLACKWATER_MOUNTAIN10_START_Y 5
#define BLACKWATER_MOUNTAIN10_PLACE_COUNT 16
#define BLACKWATER_MOUNTAIN10_MAP_CHANGE_COUNT 6

static const unsigned char blackwater_mountain10_walkable[BLACKWATER_MOUNTAIN10_WIDTH * BLACKWATER_MOUNTAIN10_HEIGHT] = {
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain10_places[];
extern const unsigned int blackwater_mountain10_place_count;
extern const MapChangeEvent blackwater_mountain10_map_changes[];
extern const unsigned int blackwater_mountain10_map_change_count;

#endif
