#include "wild6_house_map.h"

const MapPlace wild6_house_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 6, 6, 1, 1, "entrance", "", "", 0, 0, ""},
    {"wild6_house_hatch_selector", MAP_PLACE_SCRIPT, 2, 4, 1, 1, "wild6_house_hatch_selector", "", "", 0, 0, "enter"},
    {"aidem_wild6house_thieves", MAP_PLACE_SPAWN, 2, 3, 1, 1, "aidem_wild6house_thieves", "", "", 0, 0, ""},
    {"aidem_wild6house_thieves", MAP_PLACE_SPAWN, 4, 3, 1, 1, "aidem_wild6house_thieves", "", "", 0, 0, ""},
    {"wild6_house_thief_spawn", MAP_PLACE_SPAWN, 2, 4, 1, 1, "wild6_house_thief_spawn", "", "", 0, 0, ""},
    {"prevent_bucket_walking", MAP_PLACE_KEY, 1, 5, 1, 1, "wild6_house_prevent_bucket_walking", "questProgress", "wanted_men", 30, 0, ""},
    {"basement", MAP_PLACE_MAPCHANGE, 1, 5, 1, 1, "basement", "", "", 0, 0, ""}
};
const MapChangeEvent wild6_house_map_changes[] = {
    {6, 6, 1, 1, "wild6", "house"},
    {1, 5, 1, 1, "wild6_house_basement", "first_floor"}
};
