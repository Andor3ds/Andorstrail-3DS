#include "bwmfill2_map.h"

const MapPlace bwmfill2_places[] = {
    {"north1", MAP_PLACE_MAPCHANGE, 34, 0, 1, 1, "north1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 37, 0, 2, 1, "north2", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 39, 1, 1, 1, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 39, 7, 1, 7, "east2", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 4, 16, 4, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 10, 16, 6, 1, "south2", "", "", 0, 0, ""},
    {"south3", MAP_PLACE_MAPCHANGE, 31, 16, 1, 1, "south3", "", "", 0, 0, ""},
    {"bwmfill2_container", MAP_PLACE_CONTAINER, 32, 3, 1, 1, "bwmfill2_container", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 4, 1, 3, "west", "", "", 0, 0, ""},
    {"gornaud1", MAP_PLACE_SPAWN, 25, 3, 9, 5, "gornaud1", "", "", 0, 0, ""},
    {"primwolf1", MAP_PLACE_SPAWN, 34, 7, 4, 10, "primwolf1", "", "", 0, 0, ""},
    {"primwolf2", MAP_PLACE_SPAWN, 20, 7, 10, 8, "primwolf2", "", "", 0, 0, ""},
    {"primwolf1_2", MAP_PLACE_SPAWN, 18, 3, 7, 9, "primwolf1_2", "", "", 0, 0, ""},
    {"primwolf2_2", MAP_PLACE_SPAWN, 10, 5, 7, 10, "primwolf2_2", "", "", 0, 0, ""},
    {"gornaud2", MAP_PLACE_SPAWN, 1, 10, 2, 6, "gornaud2", "", "", 0, 0, ""},
    {"gornaud2_2", MAP_PLACE_SPAWN, 4, 6, 5, 9, "gornaud2_2", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill2_map_changes[] = {
    {34, 0, 1, 1, "blackwater_mountain54", "south1"},
    {37, 0, 2, 1, "blackwater_mountain54", "south2"},
    {39, 1, 1, 1, "bwmfill1", "west5"},
    {39, 7, 1, 7, "bwmfill1", "west6"},
    {4, 16, 4, 1, "bwmfill3", "north1"},
    {10, 16, 6, 1, "bwmfill3", "north2"},
    {31, 16, 1, 1, "ratdom_bwm1", "north"},
    {0, 4, 1, 3, "blackwater_mountain16", "east"}
};
