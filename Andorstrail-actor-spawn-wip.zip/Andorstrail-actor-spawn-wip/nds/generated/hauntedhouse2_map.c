#include "hauntedhouse2_map.h"

const MapPlace hauntedhouse2_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 14, 5, 1, 1, "up", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 2, 7, 1, 1, "down", "", "", 0, 0, ""},
    {"minorhaunt1", MAP_PLACE_SPAWN, 9, 3, 4, 6, "minorhaunt1", "", "", 0, 0, ""},
    {"crossglen_beetle", MAP_PLACE_SPAWN, 3, 3, 8, 5, "crossglen_beetle", "", "", 0, 0, ""},
    {"minorhaunt2", MAP_PLACE_SPAWN, 1, 3, 6, 6, "minorhaunt2", "", "", 0, 0, ""}
};
const MapChangeEvent hauntedhouse2_map_changes[] = {
    {14, 5, 1, 1, "hauntedhouse1", "down"},
    {2, 7, 1, 1, "hauntedhouse3", "up"}
};
