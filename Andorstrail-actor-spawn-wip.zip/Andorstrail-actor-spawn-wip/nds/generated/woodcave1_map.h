#ifndef ANDOR_WOODCAVE1_MAP_H
#define ANDOR_WOODCAVE1_MAP_H
#include "map_data.h"

#define WOODCAVE1_WIDTH 10
#define WOODCAVE1_HEIGHT 10
#define WOODCAVE1_PIXEL_WIDTH (WOODCAVE1_WIDTH * 32)
#define WOODCAVE1_PIXEL_HEIGHT (WOODCAVE1_HEIGHT * 32)
#define WOODCAVE1_START_X 6
#define WOODCAVE1_START_Y 2
#define WOODCAVE1_PLACE_COUNT 4
#define WOODCAVE1_MAP_CHANGE_COUNT 1

static const unsigned char woodcave1_walkable[WOODCAVE1_WIDTH * WOODCAVE1_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace woodcave1_places[];
extern const unsigned int woodcave1_place_count;
extern const MapChangeEvent woodcave1_map_changes[];
extern const unsigned int woodcave1_map_change_count;

#endif
