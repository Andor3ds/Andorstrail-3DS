#include "fallhaven_nocmar_map.h"

const MapPlace fallhaven_nocmar_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 7, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"Nocmar", MAP_PLACE_SPAWN, 2, 3, 9, 3, "Nocmar", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_nocmar_map_changes[] = {
    {7, 7, 1, 1, "fallhaven_nw", "nocmar"}
};
