#include "loneford1_map.h"

const MapPlace loneford1_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 27, 1, 2, "west", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 29, 3, 1, 1, "east3", "", "", 0, 0, ""},
    {"northwest", MAP_PLACE_MAPCHANGE, 0, 0, 1, 4, "northwest", "", "", 0, 0, ""},
    {"northnorthwest", MAP_PLACE_MAPCHANGE, 1, 0, 25, 1, "northnorthwest", "", "", 0, 0, ""},
    {"change2", MAP_PLACE_MAPCHANGE, 0, 22, 1, 4, "change2", "", "", 0, 0, ""},
    {"change3", MAP_PLACE_MAPCHANGE, 0, 7, 1, 14, "change3", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 14, 1, 15, "east", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 5, 1, 6, "east2", "", "", 0, 0, ""},
    {"tinlyn_lostsheep4", MAP_PLACE_SPAWN, 2, 2, 24, 2, "tinlyn_lostsheep4", "", "", 0, 0, ""},
    {"loneford_farmer0", MAP_PLACE_SPAWN, 2, 6, 24, 20, "loneford_farmer0", "", "", 0, 0, ""},
    {"fieldcritter_2", MAP_PLACE_SPAWN, 2, 2, 24, 2, "fieldcritter_2", "", "", 0, 0, ""}
};
const MapChangeEvent loneford1_map_changes[] = {
    {0, 27, 1, 2, "crossroads", "east"},
    {29, 3, 1, 1, "loneford13", "west3"},
    {0, 0, 1, 4, "fields1", "southeast"},
    {1, 0, 25, 1, "fields4", "south"},
    {0, 22, 1, 4, "crossroads", "change2"},
    {0, 7, 1, 14, "fields0", "change3"},
    {29, 14, 1, 15, "loneford12", "west"},
    {29, 5, 1, 6, "loneford13", "west"}
};
