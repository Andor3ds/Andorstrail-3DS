#include "blackwater_mountain17_map.h"

const MapPlace blackwater_mountain17_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 3, 9, 1, 1, "south", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 16, 9, 1, 1, "south2", "", "", 0, 0, ""},
    {"gornaud_3", MAP_PLACE_SPAWN, 12, 7, 1, 1, "gornaud_3", "", "", 0, 0, ""},
    {"gornaud_2", MAP_PLACE_SPAWN, 3, 4, 4, 4, "gornaud_2", "", "", 0, 0, ""},
    {"bwm_agent_4", MAP_PLACE_SPAWN, 8, 7, 1, 1, "bwm_agent_4", "", "", 0, 0, ""},
    {"gornaud_2_1", MAP_PLACE_SPAWN, 13, 4, 4, 4, "gornaud_2_1", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain17_map_changes[] = {
    {3, 9, 1, 1, "blackwater_mountain15", "north"},
    {16, 9, 1, 1, "blackwater_mountain18", "north"}
};
