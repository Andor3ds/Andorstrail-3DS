#ifndef ANDOR_FALLHAVEN_CHURCH_MAP_H
#define ANDOR_FALLHAVEN_CHURCH_MAP_H
#include "map_data.h"

#define FALLHAVEN_CHURCH_WIDTH 20
#define FALLHAVEN_CHURCH_HEIGHT 15
#define FALLHAVEN_CHURCH_PIXEL_WIDTH (FALLHAVEN_CHURCH_WIDTH * 32)
#define FALLHAVEN_CHURCH_PIXEL_HEIGHT (FALLHAVEN_CHURCH_HEIGHT * 32)
#define FALLHAVEN_CHURCH_START_X 3
#define FALLHAVEN_CHURCH_START_Y 11
#define FALLHAVEN_CHURCH_PLACE_COUNT 7
#define FALLHAVEN_CHURCH_MAP_CHANGE_COUNT 3

static const unsigned char fallhaven_church_walkable[FALLHAVEN_CHURCH_WIDTH * FALLHAVEN_CHURCH_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_church_places[];
extern const unsigned int fallhaven_church_place_count;
extern const MapChangeEvent fallhaven_church_map_changes[];
extern const unsigned int fallhaven_church_map_change_count;

#endif
