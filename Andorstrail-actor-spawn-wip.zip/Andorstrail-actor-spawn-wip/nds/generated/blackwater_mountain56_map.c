#include "blackwater_mountain56_map.h"

const MapPlace blackwater_mountain56_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 10, 0, 3, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 11, 19, 9, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 20, 3, 1, 1, "east", "", "", 0, 0, ""},
    {"gornaud_2", MAP_PLACE_SPAWN, 13, 6, 6, 7, "gornaud_2", "", "", 0, 0, ""},
    {"gornaud_1", MAP_PLACE_SPAWN, 0, 3, 20, 16, "gornaud_1", "", "", 0, 0, ""},
    {"kazaul_1", MAP_PLACE_SPAWN, 17, 11, 1, 1, "kazaul_1", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain56_map_changes[] = {
    {10, 0, 3, 1, "blackwater_mountain16", "south"},
    {11, 19, 9, 1, "blackwater_mountain55", "north"},
    {20, 3, 1, 1, "bwmfill3", "west4"}
};
