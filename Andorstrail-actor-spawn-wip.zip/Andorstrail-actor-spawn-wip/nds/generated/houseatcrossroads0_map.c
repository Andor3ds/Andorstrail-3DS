#include "houseatcrossroads0_map.h"

const MapPlace houseatcrossroads0_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 3, 11, 1, 1, "south", "", "", 0, 0, ""},
    {"middle", MAP_PLACE_MAPCHANGE, 9, 11, 1, 1, "middle", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 2, 3, 1, 1, "down", "", "", 0, 0, ""},
    {"dds_miri_spawn2", MAP_PLACE_SCRIPT, 8, 10, 3, 1, "dds_miri_spawn2", "", "", 0, 0, ""},
    {"gallain", MAP_PLACE_SPAWN, 9, 3, 5, 3, "gallain", "", "", 0, 0, ""},
    {"ailshara", MAP_PLACE_SPAWN, 4, 4, 1, 1, "ailshara", "", "", 0, 0, ""},
    {"Gandoren", MAP_PLACE_SPAWN, 12, 9, 1, 1, "Gandoren", "", "", 0, 0, ""},
    {"crossroads_guest", MAP_PLACE_SPAWN, 3, 6, 9, 5, "crossroads_guest", "", "", 0, 0, ""},
    {"celdar", MAP_PLACE_SPAWN, 2, 8, 1, 1, "celdar", "", "", 0, 0, ""},
    {"dds_miri", MAP_PLACE_SPAWN, 7, 4, 2, 2, "dds_miri", "", "", 0, 0, ""},
    {"burhczyd12", MAP_PLACE_SPAWN, 4, 8, 5, 1, "burhczyd12", "", "", 0, 0, ""},
    {"burhczyd12e", MAP_PLACE_SPAWN, 4, 8, 5, 1, "burhczyd12e", "", "", 0, 0, ""}
};
const MapChangeEvent houseatcrossroads0_map_changes[] = {
    {3, 11, 1, 1, "houseatcrossroads2", "north"},
    {9, 11, 1, 1, "crossroads", "middle"},
    {2, 3, 1, 1, "houseatcrossroads1", "up"}
};
