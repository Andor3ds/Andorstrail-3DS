#ifndef ANDOR_GAPFILLER3_MAP_H
#define ANDOR_GAPFILLER3_MAP_H
#include "map_data.h"

#define GAPFILLER3_WIDTH 14
#define GAPFILLER3_HEIGHT 10
#define GAPFILLER3_PIXEL_WIDTH (GAPFILLER3_WIDTH * 32)
#define GAPFILLER3_PIXEL_HEIGHT (GAPFILLER3_HEIGHT * 32)
#define GAPFILLER3_START_X 5
#define GAPFILLER3_START_Y 0
#define GAPFILLER3_PLACE_COUNT 3
#define GAPFILLER3_MAP_CHANGE_COUNT 2

static const unsigned char gapfiller3_walkable[GAPFILLER3_WIDTH * GAPFILLER3_HEIGHT] = {
    0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace gapfiller3_places[];
extern const unsigned int gapfiller3_place_count;
extern const MapChangeEvent gapfiller3_map_changes[];
extern const unsigned int gapfiller3_map_change_count;

#endif
