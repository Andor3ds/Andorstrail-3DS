#include "crossglen_farmhouse_map.h"

const MapPlace crossglen_farmhouse_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 6, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"stairs_down", MAP_PLACE_MAPCHANGE, 1, 6, 1, 1, "stairs_down", "", "", 0, 0, ""},
    {"Leta", MAP_PLACE_SPAWN, 1, 3, 8, 4, "Leta", "", "", 0, 0, ""},
    {"crossglen_dark_spirit_spawn", MAP_PLACE_SPAWN, 3, 4, 5, 2, "crossglen_dark_spirit_spawn", "", "", 0, 0, ""},
    {"old_couple_spawn", MAP_PLACE_SPAWN, 2, 3, 6, 3, "old_couple_spawn", "", "", 0, 0, ""},
    {"old_couple_spawn", MAP_PLACE_SPAWN, 3, 3, 5, 3, "old_couple_spawn", "", "", 0, 0, ""}
};
const MapChangeEvent crossglen_farmhouse_map_changes[] = {
    {6, 7, 1, 1, "crossglen", "farmhouse"},
    {1, 6, 1, 1, "crossglen_farmhouse_basement", "stairs_up"}
};
