#include "blackwater_mountain55_map.h"

const MapPlace blackwater_mountain55_places[] = {
    {"south1", MAP_PLACE_MAPCHANGE, 1, 18, 7, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 17, 18, 5, 1, "south2", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 13, 0, 9, 1, "north", "", "", 0, 0, ""},
    {"hettar_bones", MAP_PLACE_SCRIPT, 21, 3, 1, 1, "hettar_bones", "", "", 0, 0, ""},
    {"cave", MAP_PLACE_MAPCHANGE, 14, 4, 1, 1, "cave", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 1, 14, 16, 3, "wyrm_2", "", "", 0, 0, ""},
    {"wyrm_2_1", MAP_PLACE_SPAWN, 11, 9, 12, 4, "wyrm_2_1", "", "", 0, 0, ""},
    {"wyrm_3", MAP_PLACE_SPAWN, 1, 14, 16, 3, "wyrm_3", "", "", 0, 0, ""},
    {"wyrm_3_1", MAP_PLACE_SPAWN, 1, 11, 19, 2, "wyrm_3_1", "", "", 0, 0, ""},
    {"hettar", MAP_PLACE_SPAWN, 18, 15, 3, 1, "hettar", "", "", 0, 0, ""},
    {"hettar_dog", MAP_PLACE_SPAWN, 20, 2, 2, 3, "hettar_dog", "", "", 0, 0, ""},
    {"hettar_dog2", MAP_PLACE_SPAWN, 18, 15, 3, 1, "hettar_dog2", "", "", 0, 0, ""},
    {"hettar_dog3", MAP_PLACE_SPAWN, 20, 2, 2, 3, "hettar_dog3", "", "", 0, 0, ""},
    {"whootibarfag", MAP_PLACE_SPAWN, 11, 5, 2, 4, "whootibarfag", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 13, 2, 1, 1, "ratdom_rat", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain55_map_changes[] = {
    {1, 18, 7, 1, "blackwater_mountain32", "north1"},
    {17, 18, 5, 1, "blackwater_mountain32", "north2"},
    {13, 0, 9, 1, "blackwater_mountain56", "south"},
    {14, 4, 1, 1, "ratdom_maze_455a", "up"}
};
