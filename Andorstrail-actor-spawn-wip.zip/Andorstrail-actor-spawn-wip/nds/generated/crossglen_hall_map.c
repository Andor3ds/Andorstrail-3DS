#include "crossglen_hall_map.h"

const MapPlace crossglen_hall_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 3, 14, 1, 1, "entrance", "", "", 0, 0, ""},
    {"rest4", MAP_PLACE_REST, 16, 6, 1, 1, "rest4", "", "", 0, 0, ""},
    {"rest5", MAP_PLACE_REST, 18, 6, 1, 1, "rest5", "", "", 0, 0, ""},
    {"rest3", MAP_PLACE_REST, 18, 3, 1, 1, "rest3", "", "", 0, 0, ""},
    {"rest2", MAP_PLACE_REST, 16, 3, 1, 1, "rest2", "", "", 0, 0, ""},
    {"rest1", MAP_PLACE_REST, 14, 3, 1, 1, "rest1", "", "", 0, 0, ""},
    {"Leonid", MAP_PLACE_SPAWN, 2, 2, 3, 2, "Leonid", "", "", 0, 0, ""},
    {"Mara", MAP_PLACE_SPAWN, 4, 6, 6, 5, "Mara", "", "", 0, 0, ""},
    {"drunk", MAP_PLACE_SPAWN, 6, 5, 8, 6, "drunk", "", "", 0, 0, ""},
    {"Arambold", MAP_PLACE_SPAWN, 14, 4, 5, 1, "Arambold", "", "", 0, 0, ""},
    {"Tharal", MAP_PLACE_SPAWN, 16, 12, 1, 1, "Tharal", "", "", 0, 0, ""},
    {"Gruil", MAP_PLACE_SPAWN, 1, 7, 1, 1, "Gruil", "", "", 0, 0, ""},
    {"burhczyd1", MAP_PLACE_SPAWN, 11, 6, 3, 2, "burhczyd1", "", "", 0, 0, ""},
    {"burhczyd1e", MAP_PLACE_SPAWN, 11, 6, 3, 2, "burhczyd1e", "", "", 0, 0, ""}
};
const MapChangeEvent crossglen_hall_map_changes[] = {
    {3, 14, 1, 1, "crossglen", "hall"}
};
