#ifndef ANDOR_BLACKWATER_MOUNTAIN17_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN17_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN17_WIDTH 20
#define BLACKWATER_MOUNTAIN17_HEIGHT 10
#define BLACKWATER_MOUNTAIN17_PIXEL_WIDTH (BLACKWATER_MOUNTAIN17_WIDTH * 32)
#define BLACKWATER_MOUNTAIN17_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN17_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN17_START_X 3
#define BLACKWATER_MOUNTAIN17_START_Y 9
#define BLACKWATER_MOUNTAIN17_PLACE_COUNT 6
#define BLACKWATER_MOUNTAIN17_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain17_walkable[BLACKWATER_MOUNTAIN17_WIDTH * BLACKWATER_MOUNTAIN17_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0
};

extern const MapPlace blackwater_mountain17_places[];
extern const unsigned int blackwater_mountain17_place_count;
extern const MapChangeEvent blackwater_mountain17_map_changes[];
extern const unsigned int blackwater_mountain17_map_change_count;

#endif
