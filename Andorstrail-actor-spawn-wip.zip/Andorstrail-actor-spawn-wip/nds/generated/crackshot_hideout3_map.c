#include "crackshot_hideout3_map.h"

const MapPlace crackshot_hideout3_places[] = {
    {"South", MAP_PLACE_MAPCHANGE, 9, 18, 1, 1, "South", "", "", 0, 0, ""},
    {"g04_package1", MAP_PLACE_CONTAINER, 16, 16, 1, 1, "g04_package1", "", "", 0, 0, ""},
    {"guild03_hideout3_open_chest", MAP_PLACE_SCRIPT, 16, 15, 1, 1, "guild03_hideout3_open_chest", "", "", 0, 0, ""},
    {"guild03_check_crackshot_death", MAP_PLACE_SCRIPT, 8, 4, 3, 4, "guild03_check_crackshot_death", "", "", 0, 0, "step"},
    {"guild03_hideout3_exit_select", MAP_PLACE_SCRIPT, 9, 17, 1, 1, "guild03_hideout3_exit_select", "", "", 0, 0, "enter"},
    {"North", MAP_PLACE_MAPCHANGE, 9, 2, 1, 1, "North", "", "", 0, 0, ""},
    {"g03_sergeant", MAP_PLACE_SPAWN, 6, 15, 1, 1, "g03_sergeant", "", "", 0, 0, ""},
    {"crackshot_dying", MAP_PLACE_SPAWN, 0, 0, 1, 1, "crackshot_dying", "", "", 0, 0, ""},
    {"Object", MAP_PLACE_KEY, 9, 1, 1, 2, "tt_guild03_hideout3_lock", "questProgress", "troubling_times_nd", 20, 0, ""},
    {"g03_hideout3_reb1", MAP_PLACE_SPAWN, 1, 6, 5, 4, "g03_hideout3_reb1", "", "", 0, 0, ""},
    {"g03_hideout3_reb2", MAP_PLACE_SPAWN, 13, 8, 5, 4, "g03_hideout3_reb2", "", "", 0, 0, ""},
    {"g03_hideout3_reb3", MAP_PLACE_SPAWN, 16, 15, 1, 1, "g03_hideout3_reb3", "", "", 0, 0, ""},
    {"g03_hideout3_reb4", MAP_PLACE_SPAWN, 6, 7, 7, 7, "g03_hideout3_reb4", "", "", 0, 0, ""},
    {"g03_hideout_reb5", MAP_PLACE_SPAWN, 9, 4, 1, 2, "g03_hideout_reb5", "", "", 0, 0, ""},
    {"tt_seraphina2", MAP_PLACE_SPAWN, 9, 3, 1, 1, "tt_seraphina2", "", "", 0, 0, ""}
};
const MapChangeEvent crackshot_hideout3_map_changes[] = {
    {9, 18, 1, 1, "crackshot_hideout2", "North"},
    {9, 2, 1, 1, "crackshot_hideout4", "South"}
};
