#include "fallhaven_clothes_map.h"

const MapPlace fallhaven_clothes_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 4, 11, 1, 1, "entrance", "", "", 0, 0, ""},
    {"window", MAP_PLACE_MAPCHANGE, 14, 2, 1, 1, "window", "", "", 0, 0, ""},
    {"fallhaven_clothes_coup_0", MAP_PLACE_SCRIPT, 2, 2, 17, 9, "fallhaven_clothes_coup_0", "", "", 0, 0, "step"},
    {"fallhaven_clothes_window_out", MAP_PLACE_SCRIPT, 14, 2, 1, 1, "fallhaven_clothes_window_out", "", "", 0, 0, ""},
    {"fallhaven_clothes", MAP_PLACE_SPAWN, 5, 3, 12, 7, "fallhaven_clothes", "", "", 0, 0, ""},
    {"andor:1", MAP_PLACE_KEY, 16, 3, 1, 1, "fallhaven_clothes_coup_10", "questProgress", "andor", 1, 1, ""},
    {"feygard_nondisplayed:66", MAP_PLACE_KEY, 14, 2, 1, 2, "dummy_key_noPhrase", "questProgress", "feygard_nondisplayed", 66, 0, ""}
};
const MapChangeEvent fallhaven_clothes_map_changes[] = {
    {4, 11, 1, 1, "fallhaven_ne", "clothes"},
    {14, 2, 1, 1, "fallhaven_ne", "clothes_window"}
};
