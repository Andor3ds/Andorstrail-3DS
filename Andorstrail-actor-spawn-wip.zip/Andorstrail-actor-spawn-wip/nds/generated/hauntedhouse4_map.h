#ifndef ANDOR_HAUNTEDHOUSE4_MAP_H
#define ANDOR_HAUNTEDHOUSE4_MAP_H
#include "map_data.h"

#define HAUNTEDHOUSE4_WIDTH 10
#define HAUNTEDHOUSE4_HEIGHT 8
#define HAUNTEDHOUSE4_PIXEL_WIDTH (HAUNTEDHOUSE4_WIDTH * 32)
#define HAUNTEDHOUSE4_PIXEL_HEIGHT (HAUNTEDHOUSE4_HEIGHT * 32)
#define HAUNTEDHOUSE4_START_X 2
#define HAUNTEDHOUSE4_START_Y 7
#define HAUNTEDHOUSE4_PLACE_COUNT 3
#define HAUNTEDHOUSE4_MAP_CHANGE_COUNT 1

static const unsigned char hauntedhouse4_walkable[HAUNTEDHOUSE4_WIDTH * HAUNTEDHOUSE4_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace hauntedhouse4_places[];
extern const unsigned int hauntedhouse4_place_count;
extern const MapChangeEvent hauntedhouse4_map_changes[];
extern const unsigned int hauntedhouse4_map_change_count;

#endif
