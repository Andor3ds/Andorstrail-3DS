#ifndef ANDOR_BLACKWATER_MOUNTAIN39_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN39_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN39_WIDTH 20
#define BLACKWATER_MOUNTAIN39_HEIGHT 20
#define BLACKWATER_MOUNTAIN39_PIXEL_WIDTH (BLACKWATER_MOUNTAIN39_WIDTH * 32)
#define BLACKWATER_MOUNTAIN39_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN39_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN39_START_X 15
#define BLACKWATER_MOUNTAIN39_START_Y 19
#define BLACKWATER_MOUNTAIN39_PLACE_COUNT 5
#define BLACKWATER_MOUNTAIN39_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain39_walkable[BLACKWATER_MOUNTAIN39_WIDTH * BLACKWATER_MOUNTAIN39_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain39_places[];
extern const unsigned int blackwater_mountain39_place_count;
extern const MapChangeEvent blackwater_mountain39_map_changes[];
extern const unsigned int blackwater_mountain39_map_change_count;

#endif
