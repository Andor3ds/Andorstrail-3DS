#ifndef ANDOR_WILD6_HOUSE_BASEMENT_MAP_H
#define ANDOR_WILD6_HOUSE_BASEMENT_MAP_H
#include "map_data.h"

#define WILD6_HOUSE_BASEMENT_WIDTH 9
#define WILD6_HOUSE_BASEMENT_HEIGHT 7
#define WILD6_HOUSE_BASEMENT_PIXEL_WIDTH (WILD6_HOUSE_BASEMENT_WIDTH * 32)
#define WILD6_HOUSE_BASEMENT_PIXEL_HEIGHT (WILD6_HOUSE_BASEMENT_HEIGHT * 32)
#define WILD6_HOUSE_BASEMENT_START_X 1
#define WILD6_HOUSE_BASEMENT_START_Y 5
#define WILD6_HOUSE_BASEMENT_PLACE_COUNT 2
#define WILD6_HOUSE_BASEMENT_MAP_CHANGE_COUNT 2

static const unsigned char wild6_house_basement_walkable[WILD6_HOUSE_BASEMENT_WIDTH * WILD6_HOUSE_BASEMENT_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace wild6_house_basement_places[];
extern const unsigned int wild6_house_basement_place_count;
extern const MapChangeEvent wild6_house_basement_map_changes[];
extern const unsigned int wild6_house_basement_map_change_count;

#endif
