#ifndef ANDOR_BLACKWATER_MOUNTAIN52_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN52_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN52_WIDTH 30
#define BLACKWATER_MOUNTAIN52_HEIGHT 10
#define BLACKWATER_MOUNTAIN52_PIXEL_WIDTH (BLACKWATER_MOUNTAIN52_WIDTH * 32)
#define BLACKWATER_MOUNTAIN52_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN52_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN52_START_X 29
#define BLACKWATER_MOUNTAIN52_START_Y 3
#define BLACKWATER_MOUNTAIN52_PLACE_COUNT 14
#define BLACKWATER_MOUNTAIN52_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain52_walkable[BLACKWATER_MOUNTAIN52_WIDTH * BLACKWATER_MOUNTAIN52_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain52_places[];
extern const unsigned int blackwater_mountain52_place_count;
extern const MapChangeEvent blackwater_mountain52_map_changes[];
extern const unsigned int blackwater_mountain52_map_change_count;

#endif
