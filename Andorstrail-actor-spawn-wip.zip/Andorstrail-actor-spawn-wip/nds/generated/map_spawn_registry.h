#ifndef ANDOR_MAP_SPAWN_REGISTRY_H
#define ANDOR_MAP_SPAWN_REGISTRY_H
#include "map_data.h"
extern const MapSpawnArea map_spawn_areas[];
extern const unsigned int map_spawn_area_count;
#endif
