#include "fallhaven_potions_map.h"

const MapPlace fallhaven_potions_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 2, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"fallhaven_potions", MAP_PLACE_SPAWN, 2, 3, 6, 2, "fallhaven_potions", "", "", 0, 0, ""},
    {"fungi_rescued2", MAP_PLACE_SPAWN, 3, 5, 1, 1, "fungi_rescued2", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_potions_map_changes[] = {
    {2, 7, 1, 1, "fallhaven_ne", "potions"}
};
