#include "fallhaven_se_map.h"

const MapPlace fallhaven_se_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 13, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 15, 1, 4, "east", "", "", 0, 0, ""},
    {"farmer", MAP_PLACE_MAPCHANGE, 17, 5, 1, 1, "farmer", "", "", 0, 0, ""},
    {"storage", MAP_PLACE_MAPCHANGE, 10, 5, 1, 1, "storage", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 1, 1, 6, "west", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 10, 1, 2, "west2", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 13, 1, 1, "west3", "", "", 0, 0, ""},
    {"west4", MAP_PLACE_MAPCHANGE, 0, 15, 1, 1, "west4", "", "", 0, 0, ""},
    {"fallhaven_farmer1", MAP_PLACE_SPAWN, 17, 8, 7, 4, "fallhaven_farmer1", "", "", 0, 0, ""},
    {"fallhaven_bandit", MAP_PLACE_SPAWN, 3, 16, 1, 1, "fallhaven_bandit", "", "", 0, 0, ""},
    {"forestant", MAP_PLACE_SPAWN, 5, 12, 7, 6, "forestant", "", "", 0, 0, ""},
    {"fallhaven_citizen4", MAP_PLACE_SPAWN, 0, 2, 25, 6, "fallhaven_citizen4", "", "", 0, 0, ""},
    {"fallhaven_outdoor_farmer", MAP_PLACE_SPAWN, 21, 3, 3, 6, "fallhaven_outdoor_farmer", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_se_map_changes[] = {
    {13, 0, 1, 1, "fallhaven_ne", "south"},
    {29, 15, 1, 4, "wild12", "nw"},
    {17, 5, 1, 1, "fallhaven_farmer", "entrance"},
    {10, 5, 1, 1, "fallhaven_storage", "entrance"},
    {0, 1, 1, 6, "fallhaven_sw", "east"},
    {0, 10, 1, 2, "fallhaven_sw", "east2"},
    {0, 13, 1, 1, "fallhaven_sw", "east3"},
    {0, 15, 1, 1, "fallhaven_sw", "east4"}
};
