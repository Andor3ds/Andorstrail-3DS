#include "ratdom_maze1_map.h"

const MapPlace ratdom_maze1_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 29, 4, 1, 1, "east", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 14, 1, 1, "west", "", "", 0, 0, ""},
    {"ratdom_drop_torch", MAP_PLACE_CONTAINER, 28, 3, 1, 1, "ratdom_drop_torch", "", "", 0, 0, ""},
    {"ratdom_maze_light1", MAP_PLACE_SCRIPT, 19, 9, 10, 4, "ratdom_maze_light1", "", "", 0, 0, "always"},
    {"ratdom_maze_light1b", MAP_PLACE_SCRIPT, 24, 3, 6, 6, "ratdom_maze_light1b", "", "", 0, 0, "always"},
    {"ratdom_maze_light2", MAP_PLACE_SCRIPT, 10, 9, 9, 7, "ratdom_maze_light2", "", "", 0, 0, "always"},
    {"ratdom_maze_light3", MAP_PLACE_SCRIPT, 6, 6, 4, 9, "ratdom_maze_light3", "", "", 0, 0, "always"},
    {"ratdom_maze_light4", MAP_PLACE_SCRIPT, 4, 3, 6, 3, "ratdom_maze_light4", "", "", 0, 0, "always"},
    {"ratdom_maze_light5", MAP_PLACE_SCRIPT, 0, 5, 4, 11, "ratdom_maze_light5", "", "", 0, 0, "always"},
    {"ratdom_maze_light6", MAP_PLACE_SCRIPT, 10, 0, 13, 6, "ratdom_maze_light6", "", "", 0, 0, "always"},
    {"ratdom_maze_light7", MAP_PLACE_SCRIPT, 25, 13, 4, 3, "ratdom_maze_light7", "", "", 0, 0, "always"},
    {"ratdom_maze_light8", MAP_PLACE_SCRIPT, 12, 6, 10, 2, "ratdom_maze_light8", "", "", 0, 0, "always"},
    {"ratdom_maze_rat1", MAP_PLACE_SCRIPT, 16, 10, 6, 2, "ratdom_maze_rat1", "", "", 0, 0, ""},
    {"ratdom_rat_conv2", MAP_PLACE_SCRIPT, 11, 14, 1, 2, "ratdom_rat_conv2", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 7, 0, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"crossglen_caverat", MAP_PLACE_SPAWN, 2, 3, 4, 13, "crossglen_caverat", "", "", 0, 0, ""},
    {"crossglen_caverat2", MAP_PLACE_SPAWN, 8, 10, 1, 3, "crossglen_caverat2", "", "", 0, 0, ""},
    {"crossglen_caverat_1", MAP_PLACE_SPAWN, 12, 3, 11, 5, "crossglen_caverat_1", "", "", 0, 0, ""},
    {"crossglen_caverat_3", MAP_PLACE_SPAWN, 25, 11, 4, 5, "crossglen_caverat_3", "", "", 0, 0, ""},
    {"ratdom_maze_rat2_key", MAP_PLACE_KEY, 6, 6, 1, 1, "ratdom_maze_rat2", "wear", "ratdom_torch", 0, 0, ""},
    {"ratdom_maze_rat2_key2", MAP_PLACE_KEY, 11, 0, 2, 1, "ratdom_maze_rat2_key2", "questProgress", "andor", 1, 1, ""}
};
const MapChangeEvent ratdom_maze1_map_changes[] = {
    {29, 4, 1, 1, "crossglen_cave", "west"},
    {0, 14, 1, 1, "ratdom_maze2", "east"}
};
