#ifndef ANDOR_BWMFILL6_MAP_H
#define ANDOR_BWMFILL6_MAP_H
#include "map_data.h"

#define BWMFILL6_WIDTH 14
#define BWMFILL6_HEIGHT 20
#define BWMFILL6_PIXEL_WIDTH (BWMFILL6_WIDTH * 32)
#define BWMFILL6_PIXEL_HEIGHT (BWMFILL6_HEIGHT * 32)
#define BWMFILL6_START_X 13
#define BWMFILL6_START_Y 14
#define BWMFILL6_PLACE_COUNT 11
#define BWMFILL6_MAP_CHANGE_COUNT 5

static const unsigned char bwmfill6_walkable[BWMFILL6_WIDTH * BWMFILL6_HEIGHT] = {
    1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0,
    1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0,
    1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0,
    1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0,
    1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
    1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
};

extern const MapPlace bwmfill6_places[];
extern const unsigned int bwmfill6_place_count;
extern const MapChangeEvent bwmfill6_map_changes[];
extern const unsigned int bwmfill6_map_change_count;

#endif
