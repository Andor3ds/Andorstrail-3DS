#ifndef ANDOR_CRACKSHOT_HIDEOUT2_MAP_H
#define ANDOR_CRACKSHOT_HIDEOUT2_MAP_H
#include "map_data.h"

#define CRACKSHOT_HIDEOUT2_WIDTH 9
#define CRACKSHOT_HIDEOUT2_HEIGHT 27
#define CRACKSHOT_HIDEOUT2_PIXEL_WIDTH (CRACKSHOT_HIDEOUT2_WIDTH * 32)
#define CRACKSHOT_HIDEOUT2_PIXEL_HEIGHT (CRACKSHOT_HIDEOUT2_HEIGHT * 32)
#define CRACKSHOT_HIDEOUT2_START_X 0
#define CRACKSHOT_HIDEOUT2_START_Y 22
#define CRACKSHOT_HIDEOUT2_PLACE_COUNT 8
#define CRACKSHOT_HIDEOUT2_MAP_CHANGE_COUNT 2

static const unsigned char crackshot_hideout2_walkable[CRACKSHOT_HIDEOUT2_WIDTH * CRACKSHOT_HIDEOUT2_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 1,
    0, 0, 0, 0, 0, 1, 1, 1, 1,
    0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 0, 0, 1, 0,
    0, 0, 0, 0, 1, 1, 0, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0,
    1, 1, 1, 1, 1, 1, 0, 0, 0,
    1, 1, 1, 1, 1, 0, 0, 0, 0,
    1, 1, 1, 1, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace crackshot_hideout2_places[];
extern const unsigned int crackshot_hideout2_place_count;
extern const MapChangeEvent crackshot_hideout2_map_changes[];
extern const unsigned int crackshot_hideout2_map_change_count;

#endif
