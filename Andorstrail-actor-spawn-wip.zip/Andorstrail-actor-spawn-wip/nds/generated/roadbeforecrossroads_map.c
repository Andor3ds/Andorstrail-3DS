#include "roadbeforecrossroads_map.h"

const MapPlace roadbeforecrossroads_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 0, 11, 1, 7, "north", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 20, 16, 1, 5, "east", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 9, 20, 8, 1, "south", "", "", 0, 0, ""},
    {"sign_wolf_pack_jakrar", MAP_PLACE_SCRIPT, 8, 5, 8, 6, "sign_wolf_pack_jakrar", "", "", 0, 0, "always"},
    {"fox2", MAP_PLACE_SPAWN, 7, 12, 6, 2, "fox2", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 16, 15, 3, 1, "forestserpent1", "", "", 0, 0, ""},
    {"forestserpent1_1", MAP_PLACE_SPAWN, 2, 18, 6, 2, "forestserpent1_1", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 9, 5, 7, 4, "forestwolf1", "", "", 0, 0, ""},
    {"wolf_leader", MAP_PLACE_SPAWN, 10, 5, 4, 3, "wolf_leader", "", "", 0, 0, ""},
    {"pathway_fallhaven:30", MAP_PLACE_KEY, 11, 10, 2, 1, "key_wolf_pack_jakrar", "questProgress", "pathway_fallhaven", 30, 0, ""}
};
const MapChangeEvent roadbeforecrossroads_map_changes[] = {
    {0, 11, 1, 7, "crossroads", "southeast"},
    {20, 16, 1, 5, "roadbeforecrossroads1", "west"},
    {9, 20, 8, 1, "woodcave0", "north"}
};
