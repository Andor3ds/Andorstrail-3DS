#ifndef ANDOR_FALLHAVEN_GRAVEDIGGER_MAP_H
#define ANDOR_FALLHAVEN_GRAVEDIGGER_MAP_H
#include "map_data.h"

#define FALLHAVEN_GRAVEDIGGER_WIDTH 10
#define FALLHAVEN_GRAVEDIGGER_HEIGHT 8
#define FALLHAVEN_GRAVEDIGGER_PIXEL_WIDTH (FALLHAVEN_GRAVEDIGGER_WIDTH * 32)
#define FALLHAVEN_GRAVEDIGGER_PIXEL_HEIGHT (FALLHAVEN_GRAVEDIGGER_HEIGHT * 32)
#define FALLHAVEN_GRAVEDIGGER_START_X 2
#define FALLHAVEN_GRAVEDIGGER_START_Y 7
#define FALLHAVEN_GRAVEDIGGER_PLACE_COUNT 3
#define FALLHAVEN_GRAVEDIGGER_MAP_CHANGE_COUNT 2

static const unsigned char fallhaven_gravedigger_walkable[FALLHAVEN_GRAVEDIGGER_WIDTH * FALLHAVEN_GRAVEDIGGER_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_gravedigger_places[];
extern const unsigned int fallhaven_gravedigger_place_count;
extern const MapChangeEvent fallhaven_gravedigger_map_changes[];
extern const unsigned int fallhaven_gravedigger_map_change_count;

#endif
