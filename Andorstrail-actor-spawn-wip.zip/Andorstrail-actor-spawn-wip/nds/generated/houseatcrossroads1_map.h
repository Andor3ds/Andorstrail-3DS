#ifndef ANDOR_HOUSEATCROSSROADS1_MAP_H
#define ANDOR_HOUSEATCROSSROADS1_MAP_H
#include "map_data.h"

#define HOUSEATCROSSROADS1_WIDTH 16
#define HOUSEATCROSSROADS1_HEIGHT 12
#define HOUSEATCROSSROADS1_PIXEL_WIDTH (HOUSEATCROSSROADS1_WIDTH * 32)
#define HOUSEATCROSSROADS1_PIXEL_HEIGHT (HOUSEATCROSSROADS1_HEIGHT * 32)
#define HOUSEATCROSSROADS1_START_X 2
#define HOUSEATCROSSROADS1_START_Y 3
#define HOUSEATCROSSROADS1_PLACE_COUNT 9
#define HOUSEATCROSSROADS1_MAP_CHANGE_COUNT 2

static const unsigned char houseatcrossroads1_walkable[HOUSEATCROSSROADS1_WIDTH * HOUSEATCROSSROADS1_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0,
    0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0,
    0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0,
    0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace houseatcrossroads1_places[];
extern const unsigned int houseatcrossroads1_place_count;
extern const MapChangeEvent houseatcrossroads1_map_changes[];
extern const unsigned int houseatcrossroads1_map_change_count;

#endif
