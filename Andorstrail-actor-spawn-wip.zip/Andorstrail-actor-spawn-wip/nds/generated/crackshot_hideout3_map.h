#ifndef ANDOR_CRACKSHOT_HIDEOUT3_MAP_H
#define ANDOR_CRACKSHOT_HIDEOUT3_MAP_H
#include "map_data.h"

#define CRACKSHOT_HIDEOUT3_WIDTH 19
#define CRACKSHOT_HIDEOUT3_HEIGHT 19
#define CRACKSHOT_HIDEOUT3_PIXEL_WIDTH (CRACKSHOT_HIDEOUT3_WIDTH * 32)
#define CRACKSHOT_HIDEOUT3_PIXEL_HEIGHT (CRACKSHOT_HIDEOUT3_HEIGHT * 32)
#define CRACKSHOT_HIDEOUT3_START_X 9
#define CRACKSHOT_HIDEOUT3_START_Y 18
#define CRACKSHOT_HIDEOUT3_PLACE_COUNT 15
#define CRACKSHOT_HIDEOUT3_MAP_CHANGE_COUNT 2

static const unsigned char crackshot_hideout3_walkable[CRACKSHOT_HIDEOUT3_WIDTH * CRACKSHOT_HIDEOUT3_HEIGHT] = {
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0,
    0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0,
    0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0,
    0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0,
    0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
    0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace crackshot_hideout3_places[];
extern const unsigned int crackshot_hideout3_place_count;
extern const MapChangeEvent crackshot_hideout3_map_changes[];
extern const unsigned int crackshot_hideout3_map_change_count;

#endif
