#include "wild6_house_basement_map.h"

const MapPlace wild6_house_basement_places[] = {
    {"first_floor", MAP_PLACE_MAPCHANGE, 1, 5, 1, 1, "first_floor", "", "", 0, 0, ""},
    {"tunnel", MAP_PLACE_MAPCHANGE, 4, 2, 1, 1, "tunnel", "", "", 0, 0, ""}
};
const MapChangeEvent wild6_house_basement_map_changes[] = {
    {1, 5, 1, 1, "wild6_house", "basement"},
    {4, 2, 1, 1, "thieves_vault_tunnel", "basement"}
};
