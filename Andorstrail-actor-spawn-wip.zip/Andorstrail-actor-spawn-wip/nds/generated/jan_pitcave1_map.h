#ifndef ANDOR_JAN_PITCAVE1_MAP_H
#define ANDOR_JAN_PITCAVE1_MAP_H
#include "map_data.h"

#define JAN_PITCAVE1_WIDTH 10
#define JAN_PITCAVE1_HEIGHT 10
#define JAN_PITCAVE1_PIXEL_WIDTH (JAN_PITCAVE1_WIDTH * 32)
#define JAN_PITCAVE1_PIXEL_HEIGHT (JAN_PITCAVE1_HEIGHT * 32)
#define JAN_PITCAVE1_START_X 2
#define JAN_PITCAVE1_START_Y 2
#define JAN_PITCAVE1_PLACE_COUNT 4
#define JAN_PITCAVE1_MAP_CHANGE_COUNT 2

static const unsigned char jan_pitcave1_walkable[JAN_PITCAVE1_WIDTH * JAN_PITCAVE1_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace jan_pitcave1_places[];
extern const unsigned int jan_pitcave1_place_count;
extern const MapChangeEvent jan_pitcave1_map_changes[];
extern const unsigned int jan_pitcave1_map_change_count;

#endif
