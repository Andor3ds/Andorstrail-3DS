#include "crossglen_smith_map.h"

const MapPlace crossglen_smith_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 6, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"nondisplay:5", MAP_PLACE_KEY, 5, 3, 1, 1, "keyarea_crossglen_smith", "questProgress", "nondisplay", 5, 0, ""},
    {"Audir", MAP_PLACE_SPAWN, 5, 3, 4, 4, "Audir", "", "", 0, 0, ""}
};
const MapChangeEvent crossglen_smith_map_changes[] = {
    {6, 7, 1, 1, "crossglen", "smith"}
};
