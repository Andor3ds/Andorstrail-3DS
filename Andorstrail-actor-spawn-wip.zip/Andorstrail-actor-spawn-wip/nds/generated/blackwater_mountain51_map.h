#ifndef ANDOR_BLACKWATER_MOUNTAIN51_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN51_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN51_WIDTH 14
#define BLACKWATER_MOUNTAIN51_HEIGHT 10
#define BLACKWATER_MOUNTAIN51_PIXEL_WIDTH (BLACKWATER_MOUNTAIN51_WIDTH * 32)
#define BLACKWATER_MOUNTAIN51_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN51_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN51_START_X 10
#define BLACKWATER_MOUNTAIN51_START_Y 8
#define BLACKWATER_MOUNTAIN51_PLACE_COUNT 4
#define BLACKWATER_MOUNTAIN51_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain51_walkable[BLACKWATER_MOUNTAIN51_WIDTH * BLACKWATER_MOUNTAIN51_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0,
    1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain51_places[];
extern const unsigned int blackwater_mountain51_place_count;
extern const MapChangeEvent blackwater_mountain51_map_changes[];
extern const unsigned int blackwater_mountain51_map_change_count;

#endif
