#ifndef ANDOR_FALLHAVEN_RIGMOR_MAP_H
#define ANDOR_FALLHAVEN_RIGMOR_MAP_H
#include "map_data.h"

#define FALLHAVEN_RIGMOR_WIDTH 15
#define FALLHAVEN_RIGMOR_HEIGHT 10
#define FALLHAVEN_RIGMOR_PIXEL_WIDTH (FALLHAVEN_RIGMOR_WIDTH * 32)
#define FALLHAVEN_RIGMOR_PIXEL_HEIGHT (FALLHAVEN_RIGMOR_HEIGHT * 32)
#define FALLHAVEN_RIGMOR_START_X 2
#define FALLHAVEN_RIGMOR_START_Y 9
#define FALLHAVEN_RIGMOR_PLACE_COUNT 2
#define FALLHAVEN_RIGMOR_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_rigmor_walkable[FALLHAVEN_RIGMOR_WIDTH * FALLHAVEN_RIGMOR_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_rigmor_places[];
extern const unsigned int fallhaven_rigmor_place_count;
extern const MapChangeEvent fallhaven_rigmor_map_changes[];
extern const unsigned int fallhaven_rigmor_map_change_count;

#endif
