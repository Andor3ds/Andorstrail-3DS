#ifndef ANDOR_LONEFORD16_MAP_H
#define ANDOR_LONEFORD16_MAP_H
#include "map_data.h"

#define LONEFORD16_WIDTH 9
#define LONEFORD16_HEIGHT 8
#define LONEFORD16_PIXEL_WIDTH (LONEFORD16_WIDTH * 32)
#define LONEFORD16_PIXEL_HEIGHT (LONEFORD16_HEIGHT * 32)
#define LONEFORD16_START_X 3
#define LONEFORD16_START_Y 7
#define LONEFORD16_PLACE_COUNT 2
#define LONEFORD16_MAP_CHANGE_COUNT 1

static const unsigned char loneford16_walkable[LONEFORD16_WIDTH * LONEFORD16_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0
};

extern const MapPlace loneford16_places[];
extern const unsigned int loneford16_place_count;
extern const MapChangeEvent loneford16_map_changes[];
extern const unsigned int loneford16_map_change_count;

#endif
