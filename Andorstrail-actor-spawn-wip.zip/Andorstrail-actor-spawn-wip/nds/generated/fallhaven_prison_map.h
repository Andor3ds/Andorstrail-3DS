#ifndef ANDOR_FALLHAVEN_PRISON_MAP_H
#define ANDOR_FALLHAVEN_PRISON_MAP_H
#include "map_data.h"

#define FALLHAVEN_PRISON_WIDTH 15
#define FALLHAVEN_PRISON_HEIGHT 10
#define FALLHAVEN_PRISON_PIXEL_WIDTH (FALLHAVEN_PRISON_WIDTH * 32)
#define FALLHAVEN_PRISON_PIXEL_HEIGHT (FALLHAVEN_PRISON_HEIGHT * 32)
#define FALLHAVEN_PRISON_START_X 5
#define FALLHAVEN_PRISON_START_Y 9
#define FALLHAVEN_PRISON_PLACE_COUNT 5
#define FALLHAVEN_PRISON_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_prison_walkable[FALLHAVEN_PRISON_WIDTH * FALLHAVEN_PRISON_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0,
    0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_prison_places[];
extern const unsigned int fallhaven_prison_place_count;
extern const MapChangeEvent fallhaven_prison_map_changes[];
extern const unsigned int fallhaven_prison_map_change_count;

#endif
