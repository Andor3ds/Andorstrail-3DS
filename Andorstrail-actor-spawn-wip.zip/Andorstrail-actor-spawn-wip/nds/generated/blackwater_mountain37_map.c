#include "blackwater_mountain37_map.h"

const MapPlace blackwater_mountain37_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 3, 3, 1, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 1, 12, 1, 1, "south", "", "", 0, 0, ""},
    {"wyrm_4", MAP_PLACE_SPAWN, 5, 5, 1, 1, "wyrm_4", "", "", 0, 0, ""},
    {"wyrm_3", MAP_PLACE_SPAWN, 9, 6, 1, 1, "wyrm_3", "", "", 0, 0, ""},
    {"wyrm_4_1", MAP_PLACE_SPAWN, 11, 8, 2, 5, "wyrm_4_1", "", "", 0, 0, ""},
    {"wyrm_3_1", MAP_PLACE_SPAWN, 8, 13, 3, 1, "wyrm_3_1", "", "", 0, 0, ""},
    {"wyrm_4_2", MAP_PLACE_SPAWN, 5, 12, 2, 1, "wyrm_4_2", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain37_map_changes[] = {
    {3, 3, 1, 1, "blackwater_mountain36", "north"},
    {1, 12, 1, 1, "blackwater_mountain38", "north"}
};
