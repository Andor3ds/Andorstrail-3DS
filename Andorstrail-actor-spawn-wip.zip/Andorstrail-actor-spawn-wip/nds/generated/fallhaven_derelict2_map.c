#include "fallhaven_derelict2_map.h"

const MapPlace fallhaven_derelict2_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 2, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 23, 10, 1, 1, "down", "", "", 0, 0, ""},
    {"tt_start", MAP_PLACE_SCRIPT, 5, 4, 1, 1, "tt_start", "", "", 0, 0, ""},
    {"tg_thief", MAP_PLACE_SPAWN, 9, 4, 5, 3, "tg_thief", "", "", 0, 0, ""},
    {"tg_cook", MAP_PLACE_SPAWN, 1, 14, 4, 2, "tg_cook", "", "", 0, 0, ""},
    {"troublemaker", MAP_PLACE_SPAWN, 17, 3, 7, 3, "troublemaker", "", "", 0, 0, ""},
    {"pickpocket", MAP_PLACE_SPAWN, 7, 9, 5, 6, "pickpocket", "", "", 0, 0, ""},
    {"farrik", MAP_PLACE_SPAWN, 12, 15, 1, 1, "farrik", "", "", 0, 0, ""},
    {"umar", MAP_PLACE_SPAWN, 19, 15, 4, 3, "umar", "", "", 0, 0, ""},
    {"fanamor", MAP_PLACE_SPAWN, 3, 9, 1, 1, "fanamor", "", "", 0, 0, ""},
    {"nanath", MAP_PLACE_SPAWN, 9, 13, 2, 2, "nanath", "", "", 0, 0, ""},
    {"Thieves03:40", MAP_PLACE_KEY, 23, 10, 1, 1, "fallhaven_tunnel1", "questProgress", "Thieves03", 40, 0, ""}
};
const MapChangeEvent fallhaven_derelict2_map_changes[] = {
    {2, 2, 1, 1, "fallhaven_derelict", "down"},
    {23, 10, 1, 1, "fallhaven_tunnel1", "up"}
};
