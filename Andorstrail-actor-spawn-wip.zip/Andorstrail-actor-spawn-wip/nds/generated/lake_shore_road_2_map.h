#ifndef ANDOR_LAKE_SHORE_ROAD_2_MAP_H
#define ANDOR_LAKE_SHORE_ROAD_2_MAP_H
#include "map_data.h"

#define LAKE_SHORE_ROAD_2_WIDTH 20
#define LAKE_SHORE_ROAD_2_HEIGHT 20
#define LAKE_SHORE_ROAD_2_PIXEL_WIDTH (LAKE_SHORE_ROAD_2_WIDTH * 32)
#define LAKE_SHORE_ROAD_2_PIXEL_HEIGHT (LAKE_SHORE_ROAD_2_HEIGHT * 32)
#define LAKE_SHORE_ROAD_2_START_X 3
#define LAKE_SHORE_ROAD_2_START_Y 0
#define LAKE_SHORE_ROAD_2_PLACE_COUNT 11
#define LAKE_SHORE_ROAD_2_MAP_CHANGE_COUNT 6

static const unsigned char lake_shore_road_2_walkable[LAKE_SHORE_ROAD_2_WIDTH * LAKE_SHORE_ROAD_2_HEIGHT] = {
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0,
    1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0,
    1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0,
    1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0,
    0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0,
    0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0
};

extern const MapPlace lake_shore_road_2_places[];
extern const unsigned int lake_shore_road_2_place_count;
extern const MapChangeEvent lake_shore_road_2_map_changes[];
extern const unsigned int lake_shore_road_2_map_change_count;

#endif
