#ifndef ANDOR_FALLHAVEN_LUMBERJACK_MAP_H
#define ANDOR_FALLHAVEN_LUMBERJACK_MAP_H
#include "map_data.h"

#define FALLHAVEN_LUMBERJACK_WIDTH 12
#define FALLHAVEN_LUMBERJACK_HEIGHT 8
#define FALLHAVEN_LUMBERJACK_PIXEL_WIDTH (FALLHAVEN_LUMBERJACK_WIDTH * 32)
#define FALLHAVEN_LUMBERJACK_PIXEL_HEIGHT (FALLHAVEN_LUMBERJACK_HEIGHT * 32)
#define FALLHAVEN_LUMBERJACK_START_X 9
#define FALLHAVEN_LUMBERJACK_START_Y 7
#define FALLHAVEN_LUMBERJACK_PLACE_COUNT 1
#define FALLHAVEN_LUMBERJACK_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_lumberjack_walkable[FALLHAVEN_LUMBERJACK_WIDTH * FALLHAVEN_LUMBERJACK_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0
};

extern const MapPlace fallhaven_lumberjack_places[];
extern const unsigned int fallhaven_lumberjack_place_count;
extern const MapChangeEvent fallhaven_lumberjack_map_changes[];
extern const unsigned int fallhaven_lumberjack_map_change_count;

#endif
