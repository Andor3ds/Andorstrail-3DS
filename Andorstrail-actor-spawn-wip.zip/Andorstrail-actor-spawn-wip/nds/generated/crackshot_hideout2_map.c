#include "crackshot_hideout2_map.h"

const MapPlace crackshot_hideout2_places[] = {
    {"West", MAP_PLACE_MAPCHANGE, 0, 22, 1, 4, "West", "", "", 0, 0, ""},
    {"North", MAP_PLACE_MAPCHANGE, 5, 4, 1, 1, "North", "", "", 0, 0, ""},
    {"g03_deadpatrol_1", MAP_PLACE_SPAWN, 6, 18, 1, 1, "g03_deadpatrol_1", "", "", 0, 0, ""},
    {"g03_deadpatrol_2", MAP_PLACE_SPAWN, 1, 15, 1, 1, "g03_deadpatrol_2", "", "", 0, 0, ""},
    {"Rebelled thief", MAP_PLACE_SPAWN, 4, 6, 4, 3, "Rebelled thief", "", "", 0, 0, ""},
    {"Webslock", MAP_PLACE_KEY, 8, 4, 1, 2, "guild03_doorlock_3", "factionScore", "ThievesGuild", 999, 0, ""},
    {"g03_doorlock_2b", MAP_PLACE_KEY, 5, 5, 2, 1, "guild03_doorlock_2", "questProgress", "thieves_hidden", 40, 0, ""},
    {"g03_doorlock_2a", MAP_PLACE_KEY, 5, 5, 2, 1, "guild03_doorlock_2", "questProgress", "thieves_hidden", 50, 0, ""}
};
const MapChangeEvent crackshot_hideout2_map_changes[] = {
    {0, 22, 1, 4, "crackshot_hideout1", "East"},
    {5, 4, 1, 1, "crackshot_hideout3", "South"}
};
