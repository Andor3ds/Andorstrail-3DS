#ifndef ANDOR_CROSSGLEN_HALL_MAP_H
#define ANDOR_CROSSGLEN_HALL_MAP_H
#include "map_data.h"

#define CROSSGLEN_HALL_WIDTH 20
#define CROSSGLEN_HALL_HEIGHT 15
#define CROSSGLEN_HALL_PIXEL_WIDTH (CROSSGLEN_HALL_WIDTH * 32)
#define CROSSGLEN_HALL_PIXEL_HEIGHT (CROSSGLEN_HALL_HEIGHT * 32)
#define CROSSGLEN_HALL_START_X 3
#define CROSSGLEN_HALL_START_Y 14
#define CROSSGLEN_HALL_PLACE_COUNT 14
#define CROSSGLEN_HALL_MAP_CHANGE_COUNT 1

static const unsigned char crossglen_hall_walkable[CROSSGLEN_HALL_WIDTH * CROSSGLEN_HALL_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace crossglen_hall_places[];
extern const unsigned int crossglen_hall_place_count;
extern const MapChangeEvent crossglen_hall_map_changes[];
extern const unsigned int crossglen_hall_map_change_count;

#endif
