#include "white_house_map.h"

const MapPlace white_house_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 3, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"basement", MAP_PLACE_MAPCHANGE, 1, 6, 1, 1, "basement", "", "", 0, 0, ""},
    {"white_house_going_downstairs", MAP_PLACE_SCRIPT, 2, 5, 1, 2, "white_house_going_downstairs", "", "", 0, 0, "enter"},
    {"white_house_going_downstairs", MAP_PLACE_SCRIPT, 1, 5, 1, 1, "white_house_going_downstairs", "", "", 0, 0, "enter"},
    {"Nocmar", MAP_PLACE_SPAWN, 3, 4, 3, 1, "Nocmar", "", "", 0, 0, ""},
    {"blockBasement", MAP_PLACE_KEY, 1, 6, 1, 1, "nocmar_block_basement_10", "questProgress", "nocmar", 200, 0, ""}
};
const MapChangeEvent white_house_map_changes[] = {
    {3, 7, 1, 1, "gapfiller2", "cabin"},
    {1, 6, 1, 1, "white_house_basement", "up"}
};
