#include "blackwater_mountain32_map.h"

const MapPlace blackwater_mountain32_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 29, 3, 1, 2, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 11, 3, 1, 1, "north", "", "", 0, 0, ""},
    {"sign_blackwater32", MAP_PLACE_SIGN, 26, 4, 1, 1, "sign_blackwater32", "", "", 0, 0, ""},
    {"ortholion_subdued_s", MAP_PLACE_SCRIPT, 10, 11, 3, 1, "ortholion_subdued_s", "", "", 0, 0, "enter"},
    {"ortholion_subdued_s2", MAP_PLACE_SCRIPT, 10, 4, 3, 3, "ortholion_subdued_s2", "", "", 0, 0, "always"},
    {"north1", MAP_PLACE_MAPCHANGE, 1, 0, 7, 1, "north1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 17, 0, 5, 1, "north2", "", "", 0, 0, ""},
    {"chk_wild_berry", MAP_PLACE_SCRIPT, 11, 3, 1, 1, "chk_wild_berry", "", "", 0, 0, ""},
    {"north3", MAP_PLACE_MAPCHANGE, 25, 0, 1, 1, "north3", "", "", 0, 0, ""},
    {"north4", MAP_PLACE_MAPCHANGE, 27, 0, 1, 1, "north4", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 26, 21, 1, 1, "wyrm_2", "", "", 0, 0, ""},
    {"wyrm_2_1", MAP_PLACE_SPAWN, 19, 2, 9, 7, "wyrm_2_1", "", "", 0, 0, ""},
    {"wyrm_3", MAP_PLACE_SPAWN, 10, 5, 3, 6, "wyrm_3", "", "", 0, 0, ""},
    {"wyrm_3_1", MAP_PLACE_SPAWN, 3, 16, 11, 5, "wyrm_3_1", "", "", 0, 0, ""},
    {"wyrm_3_2", MAP_PLACE_SPAWN, 2, 23, 22, 4, "wyrm_3_2", "", "", 0, 0, ""},
    {"wyrm_3_3", MAP_PLACE_SPAWN, 9, 14, 2, 2, "wyrm_3_3", "", "", 0, 0, ""},
    {"wyrm_3_4", MAP_PLACE_SPAWN, 15, 7, 10, 7, "wyrm_3_4", "", "", 0, 0, ""},
    {"wyrm_3_5", MAP_PLACE_SPAWN, 19, 14, 1, 3, "wyrm_3_5", "", "", 0, 0, ""},
    {"wyrm_2_2", MAP_PLACE_SPAWN, 24, 23, 5, 4, "wyrm_2_2", "", "", 0, 0, ""},
    {"wyrm_3_6", MAP_PLACE_SPAWN, 11, 21, 1, 1, "wyrm_3_6", "", "", 0, 0, ""},
    {"wyrm_3_7", MAP_PLACE_SPAWN, 1, 12, 6, 9, "wyrm_3_7", "", "", 0, 0, ""},
    {"wyrm_2_3", MAP_PLACE_SPAWN, 15, 16, 13, 5, "wyrm_2_3", "", "", 0, 0, ""},
    {"ortholion_subdued", MAP_PLACE_SPAWN, 10, 5, 3, 1, "ortholion_subdued", "", "", 0, 0, ""},
    {"wild_berry", MAP_PLACE_SPAWN, 1, 15, 6, 12, "wild_berry", "", "", 0, 0, ""},
    {"wild_berry2", MAP_PLACE_SPAWN, 2, 1, 19, 3, "wild_berry2", "", "", 0, 0, ""},
    {"ortholion_subdued_1", MAP_PLACE_KEY, 11, 3, 1, 1, "ortholion_subdued_3", "questProgress", "bwm72_beginning", 20, 1, ""}
};
const MapChangeEvent blackwater_mountain32_map_changes[] = {
    {29, 3, 1, 2, "blackwater_mountain30", "west"},
    {11, 3, 1, 1, "blackwater_mountain36", "south"},
    {1, 0, 7, 1, "blackwater_mountain55", "south1"},
    {17, 0, 5, 1, "blackwater_mountain55", "south2"},
    {25, 0, 1, 1, "bwmfill4", "south1"},
    {27, 0, 1, 1, "bwmfill4", "south2"}
};
