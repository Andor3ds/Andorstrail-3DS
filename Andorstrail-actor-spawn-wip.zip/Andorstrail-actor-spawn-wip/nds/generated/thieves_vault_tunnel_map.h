#ifndef ANDOR_THIEVES_VAULT_TUNNEL_MAP_H
#define ANDOR_THIEVES_VAULT_TUNNEL_MAP_H
#include "map_data.h"

#define THIEVES_VAULT_TUNNEL_WIDTH 3
#define THIEVES_VAULT_TUNNEL_HEIGHT 5
#define THIEVES_VAULT_TUNNEL_PIXEL_WIDTH (THIEVES_VAULT_TUNNEL_WIDTH * 32)
#define THIEVES_VAULT_TUNNEL_PIXEL_HEIGHT (THIEVES_VAULT_TUNNEL_HEIGHT * 32)
#define THIEVES_VAULT_TUNNEL_START_X 1
#define THIEVES_VAULT_TUNNEL_START_Y 0
#define THIEVES_VAULT_TUNNEL_PLACE_COUNT 2
#define THIEVES_VAULT_TUNNEL_MAP_CHANGE_COUNT 2

static const unsigned char thieves_vault_tunnel_walkable[THIEVES_VAULT_TUNNEL_WIDTH * THIEVES_VAULT_TUNNEL_HEIGHT] = {
    0, 1, 0,
    0, 1, 0,
    0, 1, 0,
    0, 1, 0,
    0, 1, 0
};

extern const MapPlace thieves_vault_tunnel_places[];
extern const unsigned int thieves_vault_tunnel_place_count;
extern const MapChangeEvent thieves_vault_tunnel_map_changes[];
extern const unsigned int thieves_vault_tunnel_map_change_count;

#endif
