#include "wild12_map.h"

const MapPlace wild12_places[] = {
    {"nw", MAP_PLACE_MAPCHANGE, 0, 2, 1, 4, "nw", "", "", 0, 0, ""},
    {"sw", MAP_PLACE_MAPCHANGE, 0, 17, 1, 2, "sw", "", "", 0, 0, ""},
    {"sign_wild12", MAP_PLACE_SIGN, 12, 14, 1, 1, "sign_wild12", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 15, 1, 2, "east", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 13, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 3, 4, 9, 6, "forestwasp", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 3, 12, 9, 6, "forestboar2", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 9, 9, 8, 6, "forestserpent1", "", "", 0, 0, ""},
    {"fallhaven_bandit", MAP_PLACE_SPAWN, 17, 3, 1, 1, "fallhaven_bandit", "", "", 0, 0, ""}
};
const MapChangeEvent wild12_map_changes[] = {
    {0, 2, 1, 4, "fallhaven_se", "east"},
    {0, 17, 1, 2, "gapfiller1", "east"},
    {19, 15, 1, 2, "wild13", "west"},
    {13, 19, 1, 1, "bogsten5", "north"}
};
