#include "mywild18_map.h"

const MapPlace mywild18_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 10, 1, 1, "west", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 22, 5, 1, 2, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 22, 10, 1, 1, "east2", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 22, 15, 1, 2, "east3", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 2, 19, 2, 1, "south", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 2, 3, 11, 6, "forestwolf1", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 14, 4, 4, 4, "forestboar2", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 9, 15, 6, 3, "forestboar2", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 1, 13, 9, 5, "forestwolf1", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 15, 8, 4, 8, "forestwolf1", "", "", 0, 0, ""}
};
const MapChangeEvent mywild18_map_changes[] = {
    {0, 10, 1, 1, "wild7", "east"},
    {22, 5, 1, 2, "mywild19", "west1"},
    {22, 10, 1, 1, "mywild19", "west2"},
    {22, 15, 1, 2, "mywild19", "west3"},
    {2, 19, 2, 1, "lake_shore_road_1", "north"}
};
