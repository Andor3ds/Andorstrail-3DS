#ifndef ANDOR_BLACKWATER_MOUNTAIN71_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN71_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN71_WIDTH 12
#define BLACKWATER_MOUNTAIN71_HEIGHT 20
#define BLACKWATER_MOUNTAIN71_PIXEL_WIDTH (BLACKWATER_MOUNTAIN71_WIDTH * 32)
#define BLACKWATER_MOUNTAIN71_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN71_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN71_START_X 2
#define BLACKWATER_MOUNTAIN71_START_Y 0
#define BLACKWATER_MOUNTAIN71_PLACE_COUNT 9
#define BLACKWATER_MOUNTAIN71_MAP_CHANGE_COUNT 3

static const unsigned char blackwater_mountain71_walkable[BLACKWATER_MOUNTAIN71_WIDTH * BLACKWATER_MOUNTAIN71_HEIGHT] = {
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain71_places[];
extern const unsigned int blackwater_mountain71_place_count;
extern const MapChangeEvent blackwater_mountain71_map_changes[];
extern const unsigned int blackwater_mountain71_map_change_count;

#endif
