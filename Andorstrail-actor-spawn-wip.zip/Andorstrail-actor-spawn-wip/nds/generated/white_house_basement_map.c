#include "white_house_basement_map.h"

const MapPlace white_house_basement_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 0, 5, 1, 1, "up", "", "", 0, 0, ""},
    {"white_house_basement_selector", MAP_PLACE_SCRIPT, 1, 5, 1, 2, "white_house_basement_selector", "", "", 0, 0, "enter"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 2, 6, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 3, 5, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 3, 3, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 5, 4, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 6, 2, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 7, 3, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 8, 5, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 10, 6, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 9, 6, 1, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"undertell_lava_ground", MAP_PLACE_SCRIPT, 6, 6, 2, 1, "undertell_lava_ground", "", "", 0, 0, "always"},
    {"wh_basement_unlock_box_selector", MAP_PLACE_SCRIPT, 6, 4, 2, 2, "wh_basement_unlock_box_selector", "", "", 0, 0, "step"},
    {"wh_dragon_spawn", MAP_PLACE_SPAWN, 9, 2, 1, 1, "wh_dragon_spawn", "", "", 0, 0, ""},
    {"preventAccessToDragon", MAP_PLACE_KEY, 8, 2, 3, 3, "dragon_thought_10", "questProgress", "nocmar", 200, 1, ""}
};
const MapChangeEvent white_house_basement_map_changes[] = {
    {0, 5, 1, 1, "white_house", "basement"}
};
