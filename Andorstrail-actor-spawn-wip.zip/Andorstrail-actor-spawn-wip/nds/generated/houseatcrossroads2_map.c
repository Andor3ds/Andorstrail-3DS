#include "houseatcrossroads2_map.h"

const MapPlace houseatcrossroads2_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 3, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 1, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"crossroads_guard", MAP_PLACE_SPAWN, 4, 4, 1, 1, "crossroads_guard", "", "", 0, 0, ""}
};
const MapChangeEvent houseatcrossroads2_map_changes[] = {
    {3, 2, 1, 1, "houseatcrossroads3", "down"},
    {1, 0, 1, 1, "houseatcrossroads0", "south"}
};
