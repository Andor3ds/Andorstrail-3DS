#include "catacombs1_map.h"

const MapPlace catacombs1_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 18, 7, 1, 1, "up", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 1, 7, 1, 1, "down", "", "", 0, 0, ""},
    {"window", MAP_PLACE_MAPCHANGE, 10, 1, 1, 1, "window", "", "", 0, 0, ""},
    {"sign_catacombs1_grave1", MAP_PLACE_SIGN, 4, 3, 1, 1, "sign_catacombs1_grave1", "", "", 0, 0, ""},
    {"sign_catacombs1_grave2", MAP_PLACE_SIGN, 8, 3, 1, 1, "sign_catacombs1_grave2", "", "", 0, 0, ""},
    {"sign_catacombs1_grave3_selector", MAP_PLACE_SCRIPT, 10, 3, 1, 1, "sign_catacombs1_grave3_selector", "", "", 0, 0, ""},
    {"sign_catacombs1_grave4", MAP_PLACE_SIGN, 14, 3, 1, 1, "sign_catacombs1_grave4", "", "", 0, 0, ""},
    {"feygard_nondisplayed:73", MAP_PLACE_KEY, 10, 1, 1, 1, "fallhaven_coup_62", "questProgress", "feygard_nondisplayed", 73, 0, ""},
    {"catacombguard1", MAP_PLACE_SPAWN, 7, 7, 1, 1, "catacombguard1", "", "", 0, 0, ""},
    {"catacombrat1", MAP_PLACE_SPAWN, 3, 4, 14, 5, "catacombrat1", "", "", 0, 0, ""}
};
const MapChangeEvent catacombs1_map_changes[] = {
    {18, 7, 1, 1, "fallhaven_church", "down"},
    {1, 7, 1, 1, "catacombs2", "up"},
    {10, 1, 1, 1, "fallhaven_ne", "church_window"}
};
