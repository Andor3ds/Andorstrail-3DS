#include "mywild20_map.h"

const MapPlace mywild20_places[] = {
    {"west1", MAP_PLACE_MAPCHANGE, 0, 7, 1, 1, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 14, 1, 1, "west2", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 20, 1, 1, "west3", "", "", 0, 0, ""},
    {"shack", MAP_PLACE_MAPCHANGE, 7, 4, 1, 1, "shack", "", "", 0, 0, ""},
    {"house", MAP_PLACE_MAPCHANGE, 9, 15, 1, 1, "house", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 9, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 2, 7, 2, 3, "forestwolf1", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 11, 3, 6, 2, "forestserpent1", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 15, 4, 4, 6, "forestserpent1", "", "", 0, 0, ""}
};
const MapChangeEvent mywild20_map_changes[] = {
    {0, 7, 1, 1, "mywild19", "east1"},
    {0, 14, 1, 1, "mywild19", "east2"},
    {0, 20, 1, 1, "mywild19", "east3"},
    {7, 4, 1, 1, "mywild20_houseright", "exit"},
    {9, 15, 1, 1, "mywild20_houseleft", "exit"},
    {9, 0, 2, 1, "wild10", "south"}
};
