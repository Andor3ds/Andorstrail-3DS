#include "jan_pitcave1_map.h"

const MapPlace jan_pitcave1_places[] = {
    {"down", MAP_PLACE_MAPCHANGE, 7, 7, 1, 1, "down", "", "", 0, 0, ""},
    {"up", MAP_PLACE_MAPCHANGE, 2, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"pitcave1", MAP_PLACE_SPAWN, 4, 8, 3, 1, "pitcave1", "", "", 0, 0, ""},
    {"pitcave1_1", MAP_PLACE_SPAWN, 4, 3, 5, 1, "pitcave1_1", "", "", 0, 0, ""}
};
const MapChangeEvent jan_pitcave1_map_changes[] = {
    {7, 7, 1, 1, "jan_pitcave2", "up"},
    {2, 2, 1, 1, "wild3", "jan_pitcave"}
};
