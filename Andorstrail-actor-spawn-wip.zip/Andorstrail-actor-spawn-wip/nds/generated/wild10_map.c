#include "wild10_map.h"

const MapPlace wild10_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 15, 1, 2, "west", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 8, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"sign_wild10", MAP_PLACE_SIGN, 10, 7, 1, 1, "sign_wild10", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 8, 1, 2, "east", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 11, 1, 2, "west2", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 3, 1, 1, "west3", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 19, 2, 1, 3, "east2", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 9, 19, 2, 1, "south", "", "", 0, 0, ""},
    {"chk_lytwing_wildflowers", MAP_PLACE_SCRIPT, 8, 0, 2, 1, "chk_lytwing_wildflowers", "", "", 0, 0, "enter"},
    {"chk_lytwing_wildflowers", MAP_PLACE_SCRIPT, 19, 8, 1, 2, "chk_lytwing_wildflowers", "", "", 0, 0, "enter"},
    {"fallhaven_bandit", MAP_PLACE_SPAWN, 18, 17, 1, 1, "fallhaven_bandit", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 2, 7, 9, 12, "forestserpent1", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 3, 3, 12, 6, "forestwasp", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 12, 7, 6, 6, "forestboar2", "", "", 0, 0, ""},
    {"wild_flowers", MAP_PLACE_SPAWN, 2, 1, 5, 1, "wild_flowers", "", "", 0, 0, ""},
    {"wild_flowers", MAP_PLACE_SPAWN, 18, 9, 1, 2, "wild_flowers", "", "", 0, 0, ""},
    {"wild_flowers", MAP_PLACE_SPAWN, 13, 2, 6, 1, "wild_flowers", "", "", 0, 0, ""}
};
const MapChangeEvent wild10_map_changes[] = {
    {0, 15, 1, 2, "wild9", "east"},
    {8, 0, 2, 1, "fallhaven_sw", "south"},
    {19, 8, 1, 2, "wild11", "west"},
    {0, 11, 1, 2, "wild9", "east2"},
    {0, 3, 1, 1, "wild9", "east3"},
    {19, 2, 1, 3, "wild11", "west2"},
    {9, 19, 2, 1, "mywild20", "north"}
};
