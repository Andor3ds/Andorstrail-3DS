#include "hauntedhouse1_map.h"

const MapPlace hauntedhouse1_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 2, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 8, 5, 1, 1, "down", "", "", 0, 0, ""},
    {"minorhaunt1", MAP_PLACE_SPAWN, 1, 3, 8, 3, "minorhaunt1", "", "", 0, 0, ""}
};
const MapChangeEvent hauntedhouse1_map_changes[] = {
    {2, 7, 1, 1, "wild4", "entrance"},
    {8, 5, 1, 1, "hauntedhouse2", "up"}
};
