#ifndef ANDOR_BWMFILL8_MAP_H
#define ANDOR_BWMFILL8_MAP_H
#include "map_data.h"

#define BWMFILL8_WIDTH 9
#define BWMFILL8_HEIGHT 30
#define BWMFILL8_PIXEL_WIDTH (BWMFILL8_WIDTH * 32)
#define BWMFILL8_PIXEL_HEIGHT (BWMFILL8_HEIGHT * 32)
#define BWMFILL8_START_X 8
#define BWMFILL8_START_Y 2
#define BWMFILL8_PLACE_COUNT 3
#define BWMFILL8_MAP_CHANGE_COUNT 1

static const unsigned char bwmfill8_walkable[BWMFILL8_WIDTH * BWMFILL8_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 0, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 1, 1, 1,
    0, 0, 0, 0, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 1, 1, 1, 0, 1, 0,
    0, 0, 1, 1, 1, 1, 0, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0,
    1, 1, 1, 1, 0, 0, 0, 0, 0,
    1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace bwmfill8_places[];
extern const unsigned int bwmfill8_place_count;
extern const MapChangeEvent bwmfill8_map_changes[];
extern const unsigned int bwmfill8_map_change_count;

#endif
