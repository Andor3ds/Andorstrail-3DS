#ifndef ANDOR_BLACKWATER_MOUNTAIN36_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN36_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN36_WIDTH 11
#define BLACKWATER_MOUNTAIN36_HEIGHT 10
#define BLACKWATER_MOUNTAIN36_PIXEL_WIDTH (BLACKWATER_MOUNTAIN36_WIDTH * 32)
#define BLACKWATER_MOUNTAIN36_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN36_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN36_START_X 5
#define BLACKWATER_MOUNTAIN36_START_Y 9
#define BLACKWATER_MOUNTAIN36_PLACE_COUNT 6
#define BLACKWATER_MOUNTAIN36_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain36_walkable[BLACKWATER_MOUNTAIN36_WIDTH * BLACKWATER_MOUNTAIN36_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain36_places[];
extern const unsigned int blackwater_mountain36_place_count;
extern const MapChangeEvent blackwater_mountain36_map_changes[];
extern const unsigned int blackwater_mountain36_map_change_count;

#endif
