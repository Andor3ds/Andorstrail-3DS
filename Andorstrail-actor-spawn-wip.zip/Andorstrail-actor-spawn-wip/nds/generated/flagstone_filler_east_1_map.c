#include "flagstone_filler_east_1_map.h"

const MapPlace flagstone_filler_east_1_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 19, 1, 1, 16, "east", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 1, 17, 18, 1, "south", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 10, 1, 1, "west", "", "", 0, 0, ""},
    {"strawberry", MAP_PLACE_CONTAINER, 2, 1, 1, 1, "strawberry", "", "", 0, 0, ""},
    {"basilisk+spawn", MAP_PLACE_SPAWN, 4, 11, 1, 1, "basilisk+spawn", "", "", 0, 0, ""},
    {"wolf_spawn1", MAP_PLACE_SPAWN, 1, 1, 4, 7, "wolf_spawn1", "", "", 0, 0, ""},
    {"stn_lizard_spawn1", MAP_PLACE_SPAWN, 12, 12, 6, 4, "stn_lizard_spawn1", "", "", 0, 0, ""},
    {"stn_lizard-spawn2", MAP_PLACE_SPAWN, 12, 1, 6, 2, "stn_lizard-spawn2", "", "", 0, 0, ""},
    {"wolf_spawn2", MAP_PLACE_SPAWN, 7, 4, 5, 5, "wolf_spawn2", "", "", 0, 0, ""}
};
const MapChangeEvent flagstone_filler_east_1_map_changes[] = {
    {19, 1, 1, 16, "lake_shore_road_0", "west"},
    {1, 17, 18, 1, "flagstone_filler_east_2", "north"},
    {0, 10, 1, 1, "flagstone0", "southeast"}
};
