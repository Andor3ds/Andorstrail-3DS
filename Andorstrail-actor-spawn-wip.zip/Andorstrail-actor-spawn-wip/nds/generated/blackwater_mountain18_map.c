#include "blackwater_mountain18_map.h"

const MapPlace blackwater_mountain18_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 3, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"up", MAP_PLACE_MAPCHANGE, 2, 17, 1, 1, "up", "", "", 0, 0, ""},
    {"gornaud_3", MAP_PLACE_SPAWN, 4, 9, 1, 3, "gornaud_3", "", "", 0, 0, ""},
    {"gornaud_3_1", MAP_PLACE_SPAWN, 2, 7, 1, 5, "gornaud_3_1", "", "", 0, 0, ""},
    {"gornaud_3_2", MAP_PLACE_SPAWN, 4, 3, 8, 1, "gornaud_3_2", "", "", 0, 0, ""},
    {"gornaud_2", MAP_PLACE_SPAWN, 5, 7, 2, 1, "gornaud_2", "", "", 0, 0, ""},
    {"gornaud_2_1", MAP_PLACE_SPAWN, 7, 7, 7, 14, "gornaud_2_1", "", "", 0, 0, ""},
    {"gornaud_2_2", MAP_PLACE_SPAWN, 4, 18, 5, 3, "gornaud_2_2", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain18_map_changes[] = {
    {3, 0, 1, 1, "blackwater_mountain17", "south2"},
    {2, 17, 1, 1, "blackwater_mountain19", "down"}
};
