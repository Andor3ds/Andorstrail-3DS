#ifndef ANDOR_RATDOM_BWM1_MAP_H
#define ANDOR_RATDOM_BWM1_MAP_H
#include "map_data.h"

#define RATDOM_BWM1_WIDTH 10
#define RATDOM_BWM1_HEIGHT 30
#define RATDOM_BWM1_PIXEL_WIDTH (RATDOM_BWM1_WIDTH * 32)
#define RATDOM_BWM1_PIXEL_HEIGHT (RATDOM_BWM1_HEIGHT * 32)
#define RATDOM_BWM1_START_X 9
#define RATDOM_BWM1_START_Y 1
#define RATDOM_BWM1_PLACE_COUNT 10
#define RATDOM_BWM1_MAP_CHANGE_COUNT 6

static const unsigned char ratdom_bwm1_walkable[RATDOM_BWM1_WIDTH * RATDOM_BWM1_HEIGHT] = {
    0, 1, 0, 0, 0, 0, 0, 1, 0, 0,
    1, 1, 1, 1, 0, 0, 0, 0, 0, 1,
    1, 1, 1, 1, 0, 0, 1, 0, 0, 1,
    1, 1, 1, 1, 0, 0, 1, 1, 1, 1,
    1, 0, 1, 1, 0, 1, 1, 1, 1, 1,
    1, 1, 1, 0, 0, 1, 1, 1, 1, 1,
    1, 0, 1, 1, 0, 1, 1, 1, 1, 0,
    1, 1, 1, 1, 0, 0, 1, 1, 1, 0,
    1, 1, 1, 1, 1, 0, 0, 1, 1, 0,
    0, 1, 1, 0, 0, 1, 0, 1, 0, 0,
    0, 1, 1, 1, 1, 1, 0, 1, 1, 0,
    0, 1, 0, 1, 1, 0, 0, 1, 1, 0,
    0, 1, 1, 1, 0, 0, 0, 1, 1, 0,
    0, 1, 1, 1, 0, 0, 1, 1, 1, 0,
    0, 1, 1, 0, 0, 1, 1, 1, 1, 0,
    1, 1, 1, 0, 0, 1, 1, 1, 1, 0,
    1, 1, 0, 0, 1, 1, 1, 1, 1, 0,
    1, 1, 0, 1, 1, 1, 0, 1, 0, 0,
    1, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    1, 0, 0, 0, 0, 0, 0, 1, 1, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 0
};

extern const MapPlace ratdom_bwm1_places[];
extern const unsigned int ratdom_bwm1_place_count;
extern const MapChangeEvent ratdom_bwm1_map_changes[];
extern const unsigned int ratdom_bwm1_map_change_count;

#endif
