#include "wild11_map.h"

const MapPlace wild11_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 8, 1, 2, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 9, 1, 2, "east", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 10, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 2, 1, 3, "west2", "", "", 0, 0, ""},
    {"chk_lytwing_wildflowers", MAP_PLACE_SCRIPT, 0, 2, 1, 3, "chk_lytwing_wildflowers", "", "", 0, 0, "enter"},
    {"chk_lytwing_wildflowers", MAP_PLACE_SCRIPT, 0, 8, 1, 2, "chk_lytwing_wildflowers", "", "", 0, 0, "enter"},
    {"pack1", MAP_PLACE_SPAWN, 8, 15, 4, 3, "pack1", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 14, 13, 5, 6, "forestwolf1", "", "", 0, 0, ""},
    {"forestbeetle", MAP_PLACE_SPAWN, 2, 5, 16, 8, "forestbeetle", "", "", 0, 0, ""},
    {"forestwasp2", MAP_PLACE_SPAWN, 1, 13, 6, 6, "forestwasp2", "", "", 0, 0, ""},
    {"wild_flowers", MAP_PLACE_SPAWN, 6, 1, 4, 1, "wild_flowers", "", "", 0, 0, ""},
    {"wild_flowers", MAP_PLACE_SPAWN, 3, 1, 1, 4, "wild_flowers", "", "", 0, 0, ""}
};
const MapChangeEvent wild11_map_changes[] = {
    {0, 8, 1, 2, "wild10", "east"},
    {19, 9, 1, 2, "gapfiller1", "west"},
    {10, 19, 1, 1, "wild11_clearing", "north"},
    {0, 2, 1, 3, "wild10", "east2"}
};
