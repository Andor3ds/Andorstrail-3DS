#ifndef ANDOR_WHITE_HOUSE_BASEMENT_MAP_H
#define ANDOR_WHITE_HOUSE_BASEMENT_MAP_H
#include "map_data.h"

#define WHITE_HOUSE_BASEMENT_WIDTH 12
#define WHITE_HOUSE_BASEMENT_HEIGHT 8
#define WHITE_HOUSE_BASEMENT_PIXEL_WIDTH (WHITE_HOUSE_BASEMENT_WIDTH * 32)
#define WHITE_HOUSE_BASEMENT_PIXEL_HEIGHT (WHITE_HOUSE_BASEMENT_HEIGHT * 32)
#define WHITE_HOUSE_BASEMENT_START_X 0
#define WHITE_HOUSE_BASEMENT_START_Y 5
#define WHITE_HOUSE_BASEMENT_PLACE_COUNT 15
#define WHITE_HOUSE_BASEMENT_MAP_CHANGE_COUNT 1

static const unsigned char white_house_basement_walkable[WHITE_HOUSE_BASEMENT_WIDTH * WHITE_HOUSE_BASEMENT_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace white_house_basement_places[];
extern const unsigned int white_house_basement_place_count;
extern const MapChangeEvent white_house_basement_map_changes[];
extern const unsigned int white_house_basement_map_change_count;

#endif
