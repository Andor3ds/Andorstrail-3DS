#include "fallhaven_church_map.h"

const MapPlace fallhaven_church_places[] = {
    {"southeast", MAP_PLACE_MAPCHANGE, 16, 11, 1, 1, "southeast", "", "", 0, 0, ""},
    {"southwest", MAP_PLACE_MAPCHANGE, 3, 11, 1, 1, "southwest", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 18, 5, 1, 1, "down", "", "", 0, 0, ""},
    {"fsc_calc", MAP_PLACE_SCRIPT, 9, 5, 2, 1, "fsc_calc", "", "", 0, 0, ""},
    {"thoronir", MAP_PLACE_SPAWN, 9, 3, 1, 1, "thoronir", "", "", 0, 0, ""},
    {"chapelgoer", MAP_PLACE_SPAWN, 2, 8, 16, 3, "chapelgoer", "", "", 0, 0, ""},
    {"bucus:50", MAP_PLACE_KEY, 13, 6, 1, 1, "key_fallhavenchurch", "questProgress", "bucus", 50, 0, ""}
};
const MapChangeEvent fallhaven_church_map_changes[] = {
    {16, 11, 1, 1, "fallhaven_ne", "church"},
    {3, 11, 1, 1, "fallhaven_nw", "church"},
    {18, 5, 1, 1, "catacombs1", "up"}
};
