#ifndef ANDOR_BLACKWATER_MOUNTAIN40_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN40_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN40_WIDTH 11
#define BLACKWATER_MOUNTAIN40_HEIGHT 11
#define BLACKWATER_MOUNTAIN40_PIXEL_WIDTH (BLACKWATER_MOUNTAIN40_WIDTH * 32)
#define BLACKWATER_MOUNTAIN40_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN40_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN40_START_X 5
#define BLACKWATER_MOUNTAIN40_START_Y 0
#define BLACKWATER_MOUNTAIN40_PLACE_COUNT 4
#define BLACKWATER_MOUNTAIN40_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain40_walkable[BLACKWATER_MOUNTAIN40_WIDTH * BLACKWATER_MOUNTAIN40_HEIGHT] = {
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain40_places[];
extern const unsigned int blackwater_mountain40_place_count;
extern const MapChangeEvent blackwater_mountain40_map_changes[];
extern const unsigned int blackwater_mountain40_map_change_count;

#endif
