#include "home_map.h"

const MapPlace home_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 5, 9, 1, 1, "entrance", "", "", 0, 0, ""},
    {"rest", MAP_PLACE_REST, 1, 4, 1, 1, "rest", "", "", 0, 0, ""},
    {"startitems2", MAP_PLACE_CONTAINER, 10, 8, 1, 1, "startitems2", "", "", 0, 0, ""},
    {"grownfood_init", MAP_PLACE_SCRIPT, 7, 4, 1, 2, "grownfood_init", "", "", 0, 0, ""},
    {"parents_argue_selector", MAP_PLACE_SCRIPT, 2, 4, 5, 5, "parents_argue_selector", "", "", 0, 0, "step"},
    {"ratdom_wakeup", MAP_PLACE_SCRIPT, 2, 4, 1, 2, "ratdom_wakeup", "", "", 0, 0, ""},
    {"cavea", MAP_PLACE_MAPCHANGE, 5, 1, 1, 1, "cavea", "", "", 0, 0, ""},
    {"andor:1", MAP_PLACE_KEY, 0, 9, 12, 1, "keyarea_andor1", "questProgress", "andor", 1, 0, ""},
    {"cavea", MAP_PLACE_KEY, 4, 0, 3, 3, "mg2_home_cavea", "questProgress", "andor", 1, 1, ""},
    {"mikhail", MAP_PLACE_SPAWN, 9, 4, 1, 1, "mikhail", "", "", 0, 0, ""},
    {"crossglen_valentina_spawn", MAP_PLACE_SPAWN, 9, 6, 1, 1, "crossglen_valentina_spawn", "", "", 0, 0, ""},
    {"ratdom_mikhail", MAP_PLACE_SPAWN, 11, 0, 1, 1, "ratdom_mikhail", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 1, 4, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"ratdom_startitems2", MAP_PLACE_CONTAINER, 10, 8, 1, 1, "ratdom_startitems2", "", "", 0, 0, ""}
};
const MapChangeEvent home_map_changes[] = {
    {5, 9, 1, 1, "crossglen", "home"}
};
