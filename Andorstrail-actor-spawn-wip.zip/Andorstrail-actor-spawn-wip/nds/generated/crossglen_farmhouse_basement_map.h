#ifndef ANDOR_CROSSGLEN_FARMHOUSE_BASEMENT_MAP_H
#define ANDOR_CROSSGLEN_FARMHOUSE_BASEMENT_MAP_H
#include "map_data.h"

#define CROSSGLEN_FARMHOUSE_BASEMENT_WIDTH 10
#define CROSSGLEN_FARMHOUSE_BASEMENT_HEIGHT 8
#define CROSSGLEN_FARMHOUSE_BASEMENT_PIXEL_WIDTH (CROSSGLEN_FARMHOUSE_BASEMENT_WIDTH * 32)
#define CROSSGLEN_FARMHOUSE_BASEMENT_PIXEL_HEIGHT (CROSSGLEN_FARMHOUSE_BASEMENT_HEIGHT * 32)
#define CROSSGLEN_FARMHOUSE_BASEMENT_START_X 0
#define CROSSGLEN_FARMHOUSE_BASEMENT_START_Y 6
#define CROSSGLEN_FARMHOUSE_BASEMENT_PLACE_COUNT 6
#define CROSSGLEN_FARMHOUSE_BASEMENT_MAP_CHANGE_COUNT 1

static const unsigned char crossglen_farmhouse_basement_walkable[CROSSGLEN_FARMHOUSE_BASEMENT_WIDTH * CROSSGLEN_FARMHOUSE_BASEMENT_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    1, 1, 1, 1, 0, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace crossglen_farmhouse_basement_places[];
extern const unsigned int crossglen_farmhouse_basement_place_count;
extern const MapChangeEvent crossglen_farmhouse_basement_map_changes[];
extern const unsigned int crossglen_farmhouse_basement_map_change_count;

#endif
