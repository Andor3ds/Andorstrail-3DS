#include "roadbeforecrossroads2_map.h"

const MapPlace roadbeforecrossroads2_places[] = {
    {"north1", MAP_PLACE_MAPCHANGE, 9, 0, 4, 1, "north1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 22, 0, 5, 1, "north2", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 28, 20, 1, 6, "east", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 23, 1, 2, "west", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 14, 29, 2, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 21, 29, 1, 1, "south2", "", "", 0, 0, ""},
    {"sign_rbfcr2", MAP_PLACE_SIGN, 21, 18, 1, 1, "sign_rbfcr2", "", "", 0, 0, ""},
    {"brv_patrol_check_stop_hero", MAP_PLACE_SCRIPT, 21, 6, 5, 1, "brv_patrol_check_stop_hero", "", "", 0, 0, "enter"},
    {"forestwolf1", MAP_PLACE_SPAWN, 10, 2, 5, 4, "forestwolf1", "", "", 0, 0, ""},
    {"forestfox2", MAP_PLACE_SPAWN, 3, 1, 6, 4, "forestfox2", "", "", 0, 0, ""},
    {"fox2", MAP_PLACE_SPAWN, 10, 7, 3, 2, "fox2", "", "", 0, 0, ""},
    {"forestwolf1_1", MAP_PLACE_SPAWN, 9, 9, 4, 3, "forestwolf1_1", "", "", 0, 0, ""},
    {"fox2_1", MAP_PLACE_SPAWN, 8, 12, 6, 9, "fox2_1", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 8, 23, 2, 1, "forestserpent1", "", "", 0, 0, ""},
    {"forestwolf1_2", MAP_PLACE_SPAWN, 2, 22, 6, 4, "forestwolf1_2", "", "", 0, 0, ""},
    {"fox2_2", MAP_PLACE_SPAWN, 15, 8, 5, 6, "fox2_2", "", "", 0, 0, ""},
    {"forestboar3", MAP_PLACE_SPAWN, 17, 19, 6, 7, "forestboar3", "", "", 0, 0, ""},
    {"fox2_3", MAP_PLACE_SPAWN, 17, 2, 5, 2, "fox2_3", "", "", 0, 0, ""},
    {"forestfox2_1", MAP_PLACE_SPAWN, 1, 9, 7, 5, "forestfox2_1", "", "", 0, 0, ""},
    {"knights", MAP_PLACE_SPAWN, 20, 4, 7, 6, "knights", "", "", 0, 0, ""},
    {"stop_hero", MAP_PLACE_KEY, 20, 4, 7, 6, "brv_wait_patrol", "questProgress", "brv_nondisplay", 140, 1, ""}
};
const MapChangeEvent roadbeforecrossroads2_map_changes[] = {
    {9, 0, 4, 1, "roadbeforecrossroads1", "south1"},
    {22, 0, 5, 1, "roadbeforecrossroads1", "south2"},
    {28, 20, 1, 6, "roadbeforecrossroads3", "west"},
    {0, 23, 1, 2, "woodsettlement0", "east"},
    {14, 29, 2, 1, "fallhaven_ne", "north1"},
    {21, 29, 1, 1, "fallhaven_ne", "north2"}
};
