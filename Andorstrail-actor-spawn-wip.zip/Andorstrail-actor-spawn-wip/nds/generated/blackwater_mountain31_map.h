#ifndef ANDOR_BLACKWATER_MOUNTAIN31_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN31_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN31_WIDTH 11
#define BLACKWATER_MOUNTAIN31_HEIGHT 8
#define BLACKWATER_MOUNTAIN31_PIXEL_WIDTH (BLACKWATER_MOUNTAIN31_WIDTH * 32)
#define BLACKWATER_MOUNTAIN31_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN31_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN31_START_X 5
#define BLACKWATER_MOUNTAIN31_START_Y 7
#define BLACKWATER_MOUNTAIN31_PLACE_COUNT 5
#define BLACKWATER_MOUNTAIN31_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain31_walkable[BLACKWATER_MOUNTAIN31_WIDTH * BLACKWATER_MOUNTAIN31_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain31_places[];
extern const unsigned int blackwater_mountain31_place_count;
extern const MapChangeEvent blackwater_mountain31_map_changes[];
extern const unsigned int blackwater_mountain31_map_change_count;

#endif
