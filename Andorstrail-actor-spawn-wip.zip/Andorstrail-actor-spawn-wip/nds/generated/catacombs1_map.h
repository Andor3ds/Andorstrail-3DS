#ifndef ANDOR_CATACOMBS1_MAP_H
#define ANDOR_CATACOMBS1_MAP_H
#include "map_data.h"

#define CATACOMBS1_WIDTH 19
#define CATACOMBS1_HEIGHT 10
#define CATACOMBS1_PIXEL_WIDTH (CATACOMBS1_WIDTH * 32)
#define CATACOMBS1_PIXEL_HEIGHT (CATACOMBS1_HEIGHT * 32)
#define CATACOMBS1_START_X 18
#define CATACOMBS1_START_Y 7
#define CATACOMBS1_PLACE_COUNT 10
#define CATACOMBS1_MAP_CHANGE_COUNT 3

static const unsigned char catacombs1_walkable[CATACOMBS1_WIDTH * CATACOMBS1_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0,
    0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace catacombs1_places[];
extern const unsigned int catacombs1_place_count;
extern const MapChangeEvent catacombs1_map_changes[];
extern const unsigned int catacombs1_map_change_count;

#endif
