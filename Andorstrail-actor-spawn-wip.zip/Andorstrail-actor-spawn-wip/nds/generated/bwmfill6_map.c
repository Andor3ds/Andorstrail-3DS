#include "bwmfill6_map.h"

const MapPlace bwmfill6_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 2, 0, 5, 1, "north", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 13, 14, 1, 3, "east", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 13, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 0, 1, 11, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 16, 1, 2, "west2", "", "", 0, 0, ""},
    {"bwmfill6_container", MAP_PLACE_CONTAINER, 5, 18, 1, 1, "bwmfill6_container", "", "", 0, 0, ""},
    {"gold100", MAP_PLACE_CONTAINER, 1, 18, 1, 1, "gold100", "", "", 0, 0, ""},
    {"gornaud1", MAP_PLACE_SPAWN, 11, 12, 1, 1, "gornaud1", "", "", 0, 0, ""},
    {"primwolf1", MAP_PLACE_SPAWN, 2, 3, 6, 5, "primwolf1", "", "", 0, 0, ""},
    {"primwolf2", MAP_PLACE_SPAWN, 9, 7, 4, 4, "primwolf2", "", "", 0, 0, ""},
    {"wyrm_3", MAP_PLACE_SPAWN, 3, 17, 2, 2, "wyrm_3", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill6_map_changes[] = {
    {2, 0, 5, 1, "ratdom_bwm1", "south"},
    {13, 14, 1, 3, "wild2", "west"},
    {13, 19, 1, 1, "bwmfill7", "north1"},
    {0, 0, 1, 11, "bwmfill5", "east1"},
    {0, 16, 1, 2, "bwmfill5", "east2"}
};
