#include "roadtocarntower0_map.h"

const MapPlace roadtocarntower0_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 29, 15, 1, 3, "east", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 1, 1, 3, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 5, 1, 6, "west2", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 15, 1, 3, "west3", "", "", 0, 0, ""},
    {"north1", MAP_PLACE_MAPCHANGE, 1, 0, 21, 1, "north1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 23, 0, 5, 1, "north2", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 6, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"fieldwasp_unique", MAP_PLACE_SPAWN, 2, 2, 26, 11, "fieldwasp_unique", "", "", 0, 0, ""},
    {"fox1", MAP_PLACE_SPAWN, 4, 14, 24, 4, "fox1", "", "", 0, 0, ""},
    {"fieldwasp_1", MAP_PLACE_SPAWN, 2, 2, 26, 11, "fieldwasp_1", "", "", 0, 0, ""}
};
const MapChangeEvent roadtocarntower0_map_changes[] = {
    {29, 15, 1, 3, "crossroads", "west"},
    {0, 1, 1, 3, "roadtocarntower1", "east1"},
    {0, 5, 1, 6, "roadtocarntower1", "east2"},
    {0, 15, 1, 3, "roadtocarntower1", "east3"},
    {1, 0, 21, 1, "fields8", "south1"},
    {23, 0, 5, 1, "fields8", "south2"},
    {6, 19, 1, 1, "bwmfill1", "north"}
};
