#include "blackwater_mountain36_map.h"

const MapPlace blackwater_mountain36_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 5, 9, 1, 1, "south", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 5, 5, 1, 1, "north", "", "", 0, 0, ""},
    {"wyrm_4", MAP_PLACE_SPAWN, 7, 7, 1, 1, "wyrm_4", "", "", 0, 0, ""},
    {"wyrm_4_1", MAP_PLACE_SPAWN, 3, 7, 1, 1, "wyrm_4_1", "", "", 0, 0, ""},
    {"wyrm_4_2", MAP_PLACE_SPAWN, 2, 6, 1, 2, "wyrm_4_2", "", "", 0, 0, ""},
    {"wyrm_4_3", MAP_PLACE_SPAWN, 8, 6, 1, 2, "wyrm_4_3", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain36_map_changes[] = {
    {5, 9, 1, 1, "blackwater_mountain32", "north"},
    {5, 5, 1, 1, "blackwater_mountain37", "north"}
};
