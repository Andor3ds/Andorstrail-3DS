#include "bwmfill1_map.h"

const MapPlace bwmfill1_places[] = {
    {"west1", MAP_PLACE_MAPCHANGE, 0, 2, 1, 1, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 4, 1, 2, "west2", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 7, 1, 4, "west3", "", "", 0, 0, ""},
    {"west4", MAP_PLACE_MAPCHANGE, 0, 12, 1, 3, "west4", "", "", 0, 0, ""},
    {"west5", MAP_PLACE_MAPCHANGE, 0, 16, 1, 1, "west5", "", "", 0, 0, ""},
    {"west6", MAP_PLACE_MAPCHANGE, 0, 23, 1, 7, "west6", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 6, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"forestboar1", MAP_PLACE_SPAWN, 4, 1, 16, 7, "forestboar1", "", "", 0, 0, ""},
    {"foresboar2", MAP_PLACE_SPAWN, 20, 11, 9, 12, "foresboar2", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 9, 6, 19, 11, "forestwasp", "", "", 0, 0, ""},
    {"forestwolf", MAP_PLACE_SPAWN, 11, 15, 13, 7, "forestwolf", "", "", 0, 0, ""},
    {"forestboar4", MAP_PLACE_SPAWN, 18, 24, 5, 9, "forestboar4", "", "", 0, 0, ""},
    {"gornaud1", MAP_PLACE_SPAWN, 4, 25, 10, 5, "gornaud1", "", "", 0, 0, ""},
    {"gornaud2", MAP_PLACE_SPAWN, 3, 18, 6, 6, "gornaud2", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill1_map_changes[] = {
    {0, 2, 1, 1, "blackwater_mountain54", "east1"},
    {0, 4, 1, 2, "blackwater_mountain54", "east2"},
    {0, 7, 1, 4, "blackwater_mountain54", "east3"},
    {0, 12, 1, 3, "blackwater_mountain54", "east4"},
    {0, 16, 1, 1, "bwmfill2", "east1"},
    {0, 23, 1, 7, "bwmfill2", "east2"},
    {6, 0, 1, 1, "roadtocarntower0", "south"}
};
