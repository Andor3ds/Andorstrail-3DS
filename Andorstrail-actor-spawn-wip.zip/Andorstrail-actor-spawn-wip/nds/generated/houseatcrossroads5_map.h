#ifndef ANDOR_HOUSEATCROSSROADS5_MAP_H
#define ANDOR_HOUSEATCROSSROADS5_MAP_H
#include "map_data.h"

#define HOUSEATCROSSROADS5_WIDTH 11
#define HOUSEATCROSSROADS5_HEIGHT 9
#define HOUSEATCROSSROADS5_PIXEL_WIDTH (HOUSEATCROSSROADS5_WIDTH * 32)
#define HOUSEATCROSSROADS5_PIXEL_HEIGHT (HOUSEATCROSSROADS5_HEIGHT * 32)
#define HOUSEATCROSSROADS5_START_X 8
#define HOUSEATCROSSROADS5_START_Y 8
#define HOUSEATCROSSROADS5_PLACE_COUNT 2
#define HOUSEATCROSSROADS5_MAP_CHANGE_COUNT 1

static const unsigned char houseatcrossroads5_walkable[HOUSEATCROSSROADS5_WIDTH * HOUSEATCROSSROADS5_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0
};

extern const MapPlace houseatcrossroads5_places[];
extern const unsigned int houseatcrossroads5_place_count;
extern const MapChangeEvent houseatcrossroads5_map_changes[];
extern const unsigned int houseatcrossroads5_map_change_count;

#endif
