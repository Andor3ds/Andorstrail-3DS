#include "loneford16_map.h"

const MapPlace loneford16_places[] = {
    {"inside", MAP_PLACE_MAPCHANGE, 3, 7, 1, 1, "inside", "", "", 0, 0, ""},
    {"aemens", MAP_PLACE_SPAWN, 1, 3, 7, 3, "aemens", "", "", 0, 0, ""}
};
const MapChangeEvent loneford16_map_changes[] = {
    {3, 7, 1, 1, "loneford13", "outside"}
};
