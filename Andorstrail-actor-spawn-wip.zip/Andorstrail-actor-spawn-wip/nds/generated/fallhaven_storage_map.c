#include "fallhaven_storage_map.h"

const MapPlace fallhaven_storage_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 11, 9, 1, 1, "entrance", "", "", 0, 0, ""},
    {"khorand", MAP_PLACE_SPAWN, 1, 3, 13, 5, "khorand", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_storage_map_changes[] = {
    {11, 9, 1, 1, "fallhaven_se", "storage"}
};
