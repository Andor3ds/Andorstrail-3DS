#include "blackwater_mountain39_map.h"

const MapPlace blackwater_mountain39_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 15, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 2, 8, 1, 1, "down", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 6, 6, 2, 1, "wyrm_2", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 8, 3, 9, 4, "wyrm_2", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 5, 7, 14, 11, "wyrm_2", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain39_map_changes[] = {
    {15, 19, 1, 1, "blackwater_mountain30", "cave"},
    {2, 8, 1, 1, "blackwater_mountain20", "up"}
};
