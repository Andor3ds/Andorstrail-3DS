#include "bwmfill5_map.h"

const MapPlace bwmfill5_places[] = {
    {"north1", MAP_PLACE_MAPCHANGE, 0, 0, 21, 1, "north1", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 21, 0, 1, 11, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 21, 16, 1, 2, "east2", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 6, 1, 5, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 13, 1, 5, "west2", "", "", 0, 0, ""},
    {"gornaud1", MAP_PLACE_SPAWN, 6, 4, 10, 8, "gornaud1", "", "", 0, 0, ""},
    {"primwolf1", MAP_PLACE_SPAWN, 3, 2, 5, 5, "primwolf1", "", "", 0, 0, ""},
    {"primwolf2", MAP_PLACE_SPAWN, 17, 2, 3, 9, "primwolf2", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 5, 14, 1, 2, "wyrm_2", "", "", 0, 0, ""},
    {"wyrm_3", MAP_PLACE_SPAWN, 11, 15, 7, 2, "wyrm_3", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill5_map_changes[] = {
    {0, 0, 21, 1, "bwmfill3", "south2"},
    {21, 0, 1, 11, "bwmfill6", "west1"},
    {21, 16, 1, 2, "bwmfill6", "west2"},
    {0, 6, 1, 5, "bwmfill4", "east1"},
    {0, 13, 1, 5, "bwmfill4", "east2"}
};
