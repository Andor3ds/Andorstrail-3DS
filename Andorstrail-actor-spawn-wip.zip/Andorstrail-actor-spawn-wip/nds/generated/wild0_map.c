#include "wild0_map.h"

const MapPlace wild0_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 12, 20, 1, 1, "south", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 10, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 17, 8, 1, 1, "down", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 20, 5, 1, 2, "east", "", "", 0, 0, ""},
    {"forestdog", MAP_PLACE_SPAWN, 6, 16, 8, 3, "forestdog", "", "", 0, 0, ""},
    {"forestboar", MAP_PLACE_SPAWN, 5, 12, 5, 3, "forestboar", "", "", 0, 0, ""},
    {"fox1", MAP_PLACE_SPAWN, 2, 4, 5, 6, "fox1", "", "", 0, 0, ""},
    {"forestboar_1", MAP_PLACE_SPAWN, 8, 3, 6, 5, "forestboar_1", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 11, 12, 6, 2, "forestwasp", "", "", 0, 0, ""},
    {"erinith", MAP_PLACE_SPAWN, 17, 17, 1, 1, "erinith", "", "", 0, 0, ""},
    {"larva_1", MAP_PLACE_SPAWN, 16, 6, 3, 4, "larva_1", "", "", 0, 0, ""},
    {"larva_1_1", MAP_PLACE_SPAWN, 10, 6, 1, 1, "larva_1_1", "", "", 0, 0, ""},
    {"fox1_1", MAP_PLACE_SPAWN, 7, 15, 1, 1, "fox1_1", "", "", 0, 0, ""},
    {"larva_1_2", MAP_PLACE_SPAWN, 11, 2, 1, 1, "larva_1_2", "", "", 0, 0, ""}
};
const MapChangeEvent wild0_map_changes[] = {
    {12, 20, 1, 1, "wild1", "north"},
    {10, 0, 2, 1, "crossroads", "south"},
    {17, 8, 1, 1, "woodcave1", "up"},
    {20, 5, 1, 2, "woodcave0", "west"}
};
