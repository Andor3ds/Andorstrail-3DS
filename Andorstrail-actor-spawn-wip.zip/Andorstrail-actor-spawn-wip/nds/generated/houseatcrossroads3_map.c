#include "houseatcrossroads3_map.h"

const MapPlace houseatcrossroads3_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 2, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 3, 3, 1, 1, "down", "", "", 0, 0, ""},
    {"crossroads_guard", MAP_PLACE_SPAWN, 1, 4, 1, 1, "crossroads_guard", "", "", 0, 0, ""}
};
const MapChangeEvent houseatcrossroads3_map_changes[] = {
    {2, 2, 1, 1, "houseatcrossroads4", "down"},
    {3, 3, 1, 1, "houseatcrossroads2", "up"}
};
