#include "ratdom_maze3_map.h"

const MapPlace ratdom_maze3_places[] = {
    {"down", MAP_PLACE_MAPCHANGE, 3, 6, 1, 1, "down", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 7, 7, 1, 1, "south", "", "", 0, 0, ""},
    {"ratdom_maze_light1", MAP_PLACE_SCRIPT, 6, 3, 2, 4, "ratdom_maze_light1", "", "", 0, 0, "always"},
    {"ratdom_maze_light6", MAP_PLACE_SCRIPT, 2, 3, 4, 4, "ratdom_maze_light6", "", "", 0, 0, "always"},
    {"ratdom_rat", MAP_PLACE_SPAWN, 7, 0, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"crossglen_caverat", MAP_PLACE_SPAWN, 2, 3, 5, 2, "crossglen_caverat", "", "", 0, 0, ""},
    {"crossglen_caverat2", MAP_PLACE_SPAWN, 5, 3, 3, 3, "crossglen_caverat2", "", "", 0, 0, ""}
};
const MapChangeEvent ratdom_maze3_map_changes[] = {
    {3, 6, 1, 1, "ratdom_maze2", "up"},
    {7, 7, 1, 1, "ratdom_bwm1", "cave"}
};
