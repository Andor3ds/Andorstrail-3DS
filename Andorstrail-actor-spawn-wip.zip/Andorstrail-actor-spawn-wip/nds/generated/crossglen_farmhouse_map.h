#ifndef ANDOR_CROSSGLEN_FARMHOUSE_MAP_H
#define ANDOR_CROSSGLEN_FARMHOUSE_MAP_H
#include "map_data.h"

#define CROSSGLEN_FARMHOUSE_WIDTH 10
#define CROSSGLEN_FARMHOUSE_HEIGHT 8
#define CROSSGLEN_FARMHOUSE_PIXEL_WIDTH (CROSSGLEN_FARMHOUSE_WIDTH * 32)
#define CROSSGLEN_FARMHOUSE_PIXEL_HEIGHT (CROSSGLEN_FARMHOUSE_HEIGHT * 32)
#define CROSSGLEN_FARMHOUSE_START_X 6
#define CROSSGLEN_FARMHOUSE_START_Y 7
#define CROSSGLEN_FARMHOUSE_PLACE_COUNT 6
#define CROSSGLEN_FARMHOUSE_MAP_CHANGE_COUNT 2

static const unsigned char crossglen_farmhouse_walkable[CROSSGLEN_FARMHOUSE_WIDTH * CROSSGLEN_FARMHOUSE_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 0, 0, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0
};

extern const MapPlace crossglen_farmhouse_places[];
extern const unsigned int crossglen_farmhouse_place_count;
extern const MapChangeEvent crossglen_farmhouse_map_changes[];
extern const unsigned int crossglen_farmhouse_map_change_count;

#endif
