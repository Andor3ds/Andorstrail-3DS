#include "bwmfill3_map.h"

const MapPlace bwmfill3_places[] = {
    {"north1", MAP_PLACE_MAPCHANGE, 4, 0, 4, 1, "north1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 9, 0, 6, 1, "north2", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 4, 1, 7, "west", "", "", 0, 0, ""},
    {"west4", MAP_PLACE_MAPCHANGE, 0, 16, 1, 1, "west4", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 28, 20, 1, 3, "east2", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 28, 1, 1, 8, "east1", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 1, 29, 3, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 7, 29, 21, 1, "south2", "", "", 0, 0, ""},
    {"sign_bwmfill3", MAP_PLACE_SIGN, 13, 2, 1, 1, "sign_bwmfill3", "", "", 0, 0, ""},
    {"house1", MAP_PLACE_MAPCHANGE, 19, 8, 1, 1, "house1", "", "", 0, 0, ""},
    {"house2", MAP_PLACE_MAPCHANGE, 24, 8, 1, 1, "house2", "", "", 0, 0, ""},
    {"bwmfill_killsheep", MAP_PLACE_SCRIPT, 3, 8, 25, 20, "bwmfill_killsheep", "", "", 0, 0, "step"},
    {"bwm_sheep1", MAP_PLACE_SPAWN, 19, 10, 8, 6, "bwm_sheep1", "", "", 0, 0, ""},
    {"bwm_sheep1b", MAP_PLACE_SPAWN, 15, 22, 6, 6, "bwm_sheep1b", "", "", 0, 0, ""},
    {"bwm_sheep1c", MAP_PLACE_SPAWN, 5, 14, 2, 1, "bwm_sheep1c", "", "", 0, 0, ""},
    {"tunlon", MAP_PLACE_SPAWN, 23, 12, 2, 2, "tunlon", "", "", 0, 0, ""},
    {"tunlon2", MAP_PLACE_SPAWN, 23, 12, 2, 2, "tunlon2", "", "", 0, 0, ""},
    {"dummy_key", MAP_PLACE_KEY, 23, 12, 2, 2, "dummy_key", "questProgress", "andor", 1, 0, ""},
    {"dummy_key_noPhrase", MAP_PLACE_KEY, 15, 12, 2, 1, "dummy_key_noPhrase", "questProgress", "andor", 1, 1, ""},
    {"dummy_key_noPhrase2", MAP_PLACE_KEY, 10, 12, 3, 2, "dummy_key_noPhrase", "questProgress", "andor", 1, 1, ""},
    {"dummy_key_noPhrase3", MAP_PLACE_KEY, 13, 22, 1, 1, "dummy_key_noPhrase", "questProgress", "andor", 1, 1, ""}
};
const MapChangeEvent bwmfill3_map_changes[] = {
    {4, 0, 4, 1, "bwmfill2", "south1"},
    {9, 0, 6, 1, "bwmfill2", "south2"},
    {0, 4, 1, 7, "blackwater_mountain16", "east2"},
    {0, 16, 1, 1, "blackwater_mountain56", "east"},
    {28, 20, 1, 3, "ratdom_bwm1", "west2"},
    {28, 1, 1, 8, "ratdom_bwm1", "west1"},
    {1, 29, 3, 1, "bwmfill4", "north"},
    {7, 29, 21, 1, "bwmfill5", "north1"},
    {19, 8, 1, 1, "bwmfill_tunlon", "door1"},
    {24, 8, 1, 1, "bwmfill_tunlon", "door2"}
};
