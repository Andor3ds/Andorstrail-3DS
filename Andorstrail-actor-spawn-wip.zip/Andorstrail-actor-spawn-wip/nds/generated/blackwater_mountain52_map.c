#include "blackwater_mountain52_map.h"

const MapPlace blackwater_mountain52_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 29, 3, 1, 2, "south", "", "", 0, 0, ""},
    {"sign_bwm52_grave1", MAP_PLACE_SIGN, 3, 7, 1, 1, "sign_bwm52_grave1", "", "", 0, 0, ""},
    {"sign_bwm52_grave2", MAP_PLACE_SIGN, 4, 4, 1, 1, "sign_bwm52_grave2", "", "", 0, 0, ""},
    {"sign_bwm52_grave3", MAP_PLACE_SIGN, 4, 7, 1, 1, "sign_bwm52_grave3", "", "", 0, 0, ""},
    {"sign_bwm52_grave4", MAP_PLACE_SIGN, 25, 5, 1, 1, "sign_bwm52_grave4", "", "", 0, 0, ""},
    {"sign_bwm52_grave5", MAP_PLACE_SIGN, 24, 6, 1, 1, "sign_bwm52_grave5", "", "", 0, 0, ""},
    {"sign_bwm52_grave7", MAP_PLACE_SIGN, 15, 4, 1, 1, "sign_bwm52_grave7", "", "", 0, 0, ""},
    {"sign_bwm52_grave6", MAP_PLACE_SIGN, 16, 4, 1, 1, "sign_bwm52_grave6", "", "", 0, 0, ""},
    {"sign_bwm52_papers1", MAP_PLACE_SIGN, 13, 6, 1, 1, "sign_bwm52_papers1", "", "", 0, 0, ""},
    {"sign_bwm52_papers2", MAP_PLACE_SIGN, 4, 5, 1, 1, "sign_bwm52_papers2", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 2, "west", "", "", 0, 0, ""},
    {"restless_dead_1", MAP_PLACE_SPAWN, 21, 5, 7, 4, "restless_dead_1", "", "", 0, 0, ""},
    {"restless_dead_1_1", MAP_PLACE_SPAWN, 8, 3, 13, 6, "restless_dead_1_1", "", "", 0, 0, ""},
    {"blackwater_guard2", MAP_PLACE_SPAWN, 2, 3, 5, 6, "blackwater_guard2", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain52_map_changes[] = {
    {29, 3, 1, 2, "blackwater_mountain51", "north"},
    {0, 5, 1, 2, "blackwater_mountain43", "east"}
};
