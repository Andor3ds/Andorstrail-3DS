#include "blackwater_mountain54_map.h"

const MapPlace blackwater_mountain54_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 8, 1, 5, "west", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 29, 2, 1, 1, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 4, 1, 2, "east2", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 29, 7, 1, 4, "east3", "", "", 0, 0, ""},
    {"east4", MAP_PLACE_MAPCHANGE, 29, 12, 1, 3, "east4", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 24, 14, 1, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 27, 14, 2, 1, "south2", "", "", 0, 0, ""},
    {"tjure", MAP_PLACE_SPAWN, 4, 2, 3, 4, "tjure", "", "", 0, 0, ""},
    {"forestboar", MAP_PLACE_SPAWN, 11, 2, 17, 9, "forestboar", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 2, 7, 26, 7, "forestwasp", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain54_map_changes[] = {
    {0, 8, 1, 5, "blackwater_mountain53", "east"},
    {29, 2, 1, 1, "bwmfill1", "west1"},
    {29, 4, 1, 2, "bwmfill1", "west2"},
    {29, 7, 1, 4, "bwmfill1", "west3"},
    {29, 12, 1, 3, "bwmfill1", "west4"},
    {24, 14, 1, 1, "bwmfill2", "north1"},
    {27, 14, 2, 1, "bwmfill2", "north2"}
};
