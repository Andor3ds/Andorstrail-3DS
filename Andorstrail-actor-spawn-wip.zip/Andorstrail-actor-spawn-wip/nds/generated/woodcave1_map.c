#include "woodcave1_map.h"

const MapPlace woodcave1_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 6, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"larva_2", MAP_PLACE_SPAWN, 2, 4, 7, 4, "larva_2", "", "", 0, 0, ""},
    {"larva_2_1", MAP_PLACE_SPAWN, 2, 4, 5, 4, "larva_2_1", "", "", 0, 0, ""},
    {"larva_boss", MAP_PLACE_SPAWN, 2, 8, 1, 1, "larva_boss", "", "", 0, 0, ""}
};
const MapChangeEvent woodcave1_map_changes[] = {
    {6, 2, 1, 1, "wild0", "down"}
};
