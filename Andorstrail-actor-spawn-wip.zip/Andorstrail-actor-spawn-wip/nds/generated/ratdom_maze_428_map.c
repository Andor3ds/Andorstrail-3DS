#include "ratdom_maze_428_map.h"

const MapPlace ratdom_maze_428_places[] = {
    {"south2", MAP_PLACE_MAPCHANGE, 13, 28, 2, 2, "south2", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 0, 28, 2, 2, "south1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 13, 0, 2, 2, "north2", "", "", 0, 0, ""},
    {"north1", MAP_PLACE_MAPCHANGE, 0, 0, 2, 2, "north1", "", "", 0, 0, ""},
    {"ratdom_maze_light1", MAP_PLACE_SCRIPT, 0, 0, 4, 6, "ratdom_maze_light1", "", "", 0, 0, "always"},
    {"ratdom_maze_light2", MAP_PLACE_SCRIPT, 11, 0, 4, 6, "ratdom_maze_light2", "", "", 0, 0, "always"},
    {"ratdom_maze_light3", MAP_PLACE_SCRIPT, 0, 23, 4, 7, "ratdom_maze_light3", "", "", 0, 0, "always"},
    {"ratdom_maze_light4", MAP_PLACE_SCRIPT, 11, 24, 4, 6, "ratdom_maze_light4", "", "", 0, 0, "always"},
    {"ratdom_maze_light5", MAP_PLACE_SCRIPT, 4, 3, 7, 6, "ratdom_maze_light5", "", "", 0, 0, "always"},
    {"ratdom_maze_light6", MAP_PLACE_SCRIPT, 4, 20, 7, 8, "ratdom_maze_light6", "", "", 0, 0, "always"},
    {"ratdom_maze_light7", MAP_PLACE_SCRIPT, 5, 9, 6, 11, "ratdom_maze_light7", "", "", 0, 0, "always"},
    {"ratdom_rat_conv1", MAP_PLACE_SCRIPT, 7, 10, 2, 1, "ratdom_rat_conv1", "", "", 0, 0, ""},
    {"ratdom_rat_conv2", MAP_PLACE_SCRIPT, 7, 13, 4, 1, "ratdom_rat_conv2", "", "", 0, 0, ""},
    {"ratdom_rat_conv3", MAP_PLACE_SCRIPT, 6, 19, 3, 1, "ratdom_rat_conv3", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 7, 0, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"ratdom_maze_rat", MAP_PLACE_SPAWN, 2, 22, 4, 6, "ratdom_maze_rat", "", "", 0, 0, ""},
    {"cavesnake2", MAP_PLACE_SPAWN, 5, 9, 6, 13, "cavesnake2", "", "", 0, 0, ""}
};
const MapChangeEvent ratdom_maze_428_map_changes[] = {
    {13, 28, 2, 2, "ratdom_maze_439", "north1"},
    {0, 28, 2, 2, "ratdom_maze_438", "north2"},
    {13, 0, 2, 2, "ratdom_maze_419", "south1"},
    {0, 0, 2, 2, "ratdom_maze_418", "south2"}
};
