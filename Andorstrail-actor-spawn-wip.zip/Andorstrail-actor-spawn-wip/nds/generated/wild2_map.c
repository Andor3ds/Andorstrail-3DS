#include "wild2_map.h"

const MapPlace wild2_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 19, 5, 1, 3, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 4, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"cave", MAP_PLACE_MAPCHANGE, 2, 9, 1, 1, "cave", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 15, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 19, 11, 1, 2, "east2", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 14, 1, 3, "west", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 0, 19, 3, 1, "south2", "", "", 0, 0, ""},
    {"forestant", MAP_PLACE_SPAWN, 1, 11, 10, 3, "forestant", "", "", 0, 0, ""},
    {"forestant_1", MAP_PLACE_SPAWN, 16, 9, 2, 4, "forestant_1", "", "", 0, 0, ""},
    {"forestsnake", MAP_PLACE_SPAWN, 13, 2, 6, 2, "forestsnake", "", "", 0, 0, ""},
    {"forestsnake_1", MAP_PLACE_SPAWN, 12, 6, 4, 5, "forestsnake_1", "", "", 0, 0, ""},
    {"inspiring_snake_master", MAP_PLACE_SPAWN, 12, 11, 1, 1, "inspiring_snake_master", "", "", 0, 0, ""}
};
const MapChangeEvent wild2_map_changes[] = {
    {19, 5, 1, 3, "wild3", "west"},
    {4, 0, 1, 1, "crossglen", "south"},
    {2, 9, 1, 1, "snakecave1", "south"},
    {15, 19, 1, 1, "wild5", "north"},
    {19, 11, 1, 2, "wild3", "west2"},
    {0, 14, 1, 3, "bwmfill6", "east"},
    {0, 19, 3, 1, "bwmfill7", "north2"}
};
