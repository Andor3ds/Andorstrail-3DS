#include "blackwater_mountain20_map.h"

const MapPlace blackwater_mountain20_places[] = {
    {"down", MAP_PLACE_MAPCHANGE, 1, 3, 1, 1, "down", "", "", 0, 0, ""},
    {"up", MAP_PLACE_MAPCHANGE, 6, 12, 1, 1, "up", "", "", 0, 0, ""},
    {"wyrm_1", MAP_PLACE_SPAWN, 3, 3, 5, 6, "wyrm_1", "", "", 0, 0, ""},
    {"wyrm_1_1", MAP_PLACE_SPAWN, 4, 9, 1, 4, "wyrm_1_1", "", "", 0, 0, ""},
    {"wyrm_1_2", MAP_PLACE_SPAWN, 2, 14, 7, 5, "wyrm_1_2", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain20_map_changes[] = {
    {1, 3, 1, 1, "blackwater_mountain19", "up"},
    {6, 12, 1, 1, "blackwater_mountain39", "down"}
};
