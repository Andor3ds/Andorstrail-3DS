#include "bwmfill4_map.h"

const MapPlace bwmfill4_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 1, 0, 3, 1, "north", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 5, 6, 1, 5, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 5, 13, 1, 5, "east2", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 1, 21, 1, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 3, 21, 1, 1, "south2", "", "", 0, 0, ""},
    {"gornaud1", MAP_PLACE_SPAWN, 1, 2, 4, 4, "gornaud1", "", "", 0, 0, ""},
    {"wyrm_2", MAP_PLACE_SPAWN, 1, 15, 3, 4, "wyrm_2", "", "", 0, 0, ""}
};
const MapChangeEvent bwmfill4_map_changes[] = {
    {1, 0, 3, 1, "bwmfill3", "south1"},
    {5, 6, 1, 5, "bwmfill5", "west1"},
    {5, 13, 1, 5, "bwmfill5", "west2"},
    {1, 21, 1, 1, "blackwater_mountain32", "north3"},
    {3, 21, 1, 1, "blackwater_mountain32", "north4"}
};
