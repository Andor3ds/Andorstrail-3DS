#include "blackwater_mountain53_map.h"

const MapPlace blackwater_mountain53_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 16, 8, 2, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 2, 1, 5, "east", "", "", 0, 0, ""},
    {"gornaud_1", MAP_PLACE_SPAWN, 1, 3, 3, 4, "gornaud_1", "", "", 0, 0, ""},
    {"gornaud_2_1", MAP_PLACE_SPAWN, 8, 7, 1, 1, "gornaud_2_1", "", "", 0, 0, ""},
    {"gornaud_1_1", MAP_PLACE_SPAWN, 11, 5, 9, 2, "gornaud_1_1", "", "", 0, 0, ""},
    {"gornaud_2_4", MAP_PLACE_SPAWN, 7, 3, 3, 2, "gornaud_2_4", "", "", 0, 0, ""},
    {"gornaud_2_5", MAP_PLACE_SPAWN, 15, 2, 7, 3, "gornaud_2_5", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain53_map_changes[] = {
    {16, 8, 2, 1, "blackwater_mountain16", "north"},
    {29, 2, 1, 5, "blackwater_mountain54", "west"}
};
