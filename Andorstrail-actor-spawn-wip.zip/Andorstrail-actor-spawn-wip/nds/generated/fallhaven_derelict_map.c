#include "fallhaven_derelict_map.h"

const MapPlace fallhaven_derelict_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 7, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 1, 5, 1, 1, "down", "", "", 0, 0, ""},
    {"Bucus", MAP_PLACE_SPAWN, 8, 3, 3, 2, "Bucus", "", "", 0, 0, ""},
    {"andor:50", MAP_PLACE_KEY, 3, 3, 1, 1, "fallhaven_derelict1", "questProgress", "andor", 50, 0, ""}
};
const MapChangeEvent fallhaven_derelict_map_changes[] = {
    {7, 7, 1, 1, "fallhaven_nw", "derelict"},
    {1, 5, 1, 1, "fallhaven_derelict2", "up"}
};
