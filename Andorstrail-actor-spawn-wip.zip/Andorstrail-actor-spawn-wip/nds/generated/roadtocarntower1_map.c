#include "roadtocarntower1_map.h"

const MapPlace roadtocarntower1_places[] = {
    {"east1", MAP_PLACE_MAPCHANGE, 29, 1, 1, 3, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 5, 1, 6, "east2", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 29, 15, 1, 3, "east3", "", "", 0, 0, ""},
    {"left1", MAP_PLACE_MAPCHANGE, 0, 1, 1, 4, "left1", "", "", 0, 0, ""},
    {"left4", MAP_PLACE_MAPCHANGE, 0, 13, 1, 4, "left4", "", "", 0, 0, ""},
    {"left3", MAP_PLACE_MAPCHANGE, 0, 10, 1, 2, "left3", "", "", 0, 0, ""},
    {"left2", MAP_PLACE_MAPCHANGE, 0, 6, 1, 2, "left2", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 1, 0, 28, 1, "north", "", "", 0, 0, ""},
    {"hadracor", MAP_PLACE_SPAWN, 12, 7, 1, 1, "hadracor", "", "", 0, 0, ""},
    {"woodcutter_0", MAP_PLACE_SPAWN, 18, 5, 1, 1, "woodcutter_0", "", "", 0, 0, ""},
    {"woodcutter_2", MAP_PLACE_SPAWN, 22, 6, 1, 1, "woodcutter_2", "", "", 0, 0, ""},
    {"woodcutter_3", MAP_PLACE_SPAWN, 19, 9, 1, 1, "woodcutter_3", "", "", 0, 0, ""},
    {"woodcutter_4", MAP_PLACE_SPAWN, 6, 7, 1, 1, "woodcutter_4", "", "", 0, 0, ""},
    {"woodcutter_5", MAP_PLACE_SPAWN, 8, 9, 9, 3, "woodcutter_5", "", "", 0, 0, ""},
    {"fox1", MAP_PLACE_SPAWN, 6, 15, 15, 4, "fox1", "", "", 0, 0, ""},
    {"fieldwasp_0", MAP_PLACE_SPAWN, 25, 2, 3, 10, "fieldwasp_0", "", "", 0, 0, ""}
};
const MapChangeEvent roadtocarntower1_map_changes[] = {
    {29, 1, 1, 3, "roadtocarntower0", "west1"},
    {29, 5, 1, 6, "roadtocarntower0", "west2"},
    {29, 15, 1, 3, "roadtocarntower0", "west3"},
    {0, 1, 1, 4, "roadtocarntower2", "north1"},
    {0, 13, 1, 4, "roadtocarntower2", "north4"},
    {0, 10, 1, 2, "roadtocarntower2", "north3"},
    {0, 6, 1, 2, "roadtocarntower2", "north2"},
    {1, 0, 28, 1, "fields9", "south"}
};
