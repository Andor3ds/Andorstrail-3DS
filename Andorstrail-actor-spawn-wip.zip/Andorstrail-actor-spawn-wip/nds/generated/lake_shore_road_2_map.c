#include "lake_shore_road_2_map.h"

const MapPlace lake_shore_road_2_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 4, 19, 13, 1, "south", "", "", 0, 0, ""},
    {"pier", MAP_PLACE_MAPCHANGE, 19, 10, 1, 2, "pier", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 3, 0, 14, 1, "north", "", "", 0, 0, ""},
    {"start_over", MAP_PLACE_MAPCHANGE, 0, 5, 1, 1, "start_over", "", "", 0, 0, ""},
    {"top_south", MAP_PLACE_MAPCHANGE, 1, 19, 1, 1, "top_south", "", "", 0, 0, ""},
    {"dead_end", MAP_PLACE_MAPCHANGE, 2, 14, 1, 1, "dead_end", "", "", 0, 0, ""},
    {"top_west", MAP_PLACE_MAPCHANGE, 0, 15, 1, 2, "top_west", "", "", 0, 0, ""},
    {"stn_lizard_spawn1", MAP_PLACE_SPAWN, 3, 7, 1, 1, "stn_lizard_spawn1", "", "", 0, 0, ""},
    {"stn_lizard_spawn2", MAP_PLACE_SPAWN, 5, 2, 9, 7, "stn_lizard_spawn2", "", "", 0, 0, ""},
    {"vicious_hound_spawn1", MAP_PLACE_SPAWN, 5, 10, 6, 5, "vicious_hound_spawn1", "", "", 0, 0, ""},
    {"slithering_venomfang_spawn", MAP_PLACE_SPAWN, 6, 17, 3, 1, "slithering_venomfang_spawn", "", "", 0, 0, ""}
};
const MapChangeEvent lake_shore_road_2_map_changes[] = {
    {4, 19, 13, 1, "lake_shore_road_5", "north"},
    {19, 10, 1, 2, "lake_shore_road_3", "pier"},
    {3, 0, 14, 1, "lake_shore_road_0", "south"},
    {1, 19, 1, 1, "lake_shore_road_5", "top_north"},
    {2, 14, 1, 1, "lake_shore_road_2", "start_over"},
    {0, 15, 1, 2, "rat_mountain_1", "east"}
};
