#include "jan_pitcave2_map.h"

const MapPlace jan_pitcave2_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 26, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 25, 26, 1, 1, "down", "", "", 0, 0, ""},
    {"sign_pitcave2", MAP_PLACE_SIGN, 27, 24, 1, 1, "sign_pitcave2", "", "", 0, 0, ""},
    {"pitcave1", MAP_PLACE_SPAWN, 17, 3, 8, 3, "pitcave1", "", "", 0, 0, ""},
    {"pitcave2", MAP_PLACE_SPAWN, 9, 8, 1, 1, "pitcave2", "", "", 0, 0, ""},
    {"pitcave2_1", MAP_PLACE_SPAWN, 17, 10, 12, 7, "pitcave2_1", "", "", 0, 0, ""},
    {"pitcave2_2", MAP_PLACE_SPAWN, 1, 8, 4, 9, "pitcave2_2", "", "", 0, 0, ""},
    {"pitcave2_3", MAP_PLACE_SPAWN, 15, 21, 3, 1, "pitcave2_3", "", "", 0, 0, ""},
    {"pitcave2_4", MAP_PLACE_SPAWN, 7, 13, 7, 16, "pitcave2_4", "", "", 0, 0, ""},
    {"pitcave2_boss", MAP_PLACE_SPAWN, 23, 23, 4, 2, "pitcave2_boss", "", "", 0, 0, ""},
    {"pitcave1_1", MAP_PLACE_SPAWN, 2, 23, 4, 4, "pitcave1_1", "", "", 0, 0, ""},
    {"pitcave2_5", MAP_PLACE_SPAWN, 2, 3, 6, 4, "pitcave2_5", "", "", 0, 0, ""},
    {"pitcave2_6", MAP_PLACE_SPAWN, 12, 6, 5, 3, "pitcave2_6", "", "", 0, 0, ""},
    {"pitcave2_7", MAP_PLACE_SPAWN, 21, 21, 4, 7, "pitcave2_7", "", "", 0, 0, ""}
};
const MapChangeEvent jan_pitcave2_map_changes[] = {
    {26, 2, 1, 1, "jan_pitcave1", "down"},
    {25, 26, 1, 1, "jan_pitcave3", "up"}
};
