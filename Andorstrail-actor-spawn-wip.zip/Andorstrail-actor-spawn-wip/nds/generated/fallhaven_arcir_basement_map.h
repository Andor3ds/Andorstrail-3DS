#ifndef ANDOR_FALLHAVEN_ARCIR_BASEMENT_MAP_H
#define ANDOR_FALLHAVEN_ARCIR_BASEMENT_MAP_H
#include "map_data.h"

#define FALLHAVEN_ARCIR_BASEMENT_WIDTH 12
#define FALLHAVEN_ARCIR_BASEMENT_HEIGHT 9
#define FALLHAVEN_ARCIR_BASEMENT_PIXEL_WIDTH (FALLHAVEN_ARCIR_BASEMENT_WIDTH * 32)
#define FALLHAVEN_ARCIR_BASEMENT_PIXEL_HEIGHT (FALLHAVEN_ARCIR_BASEMENT_HEIGHT * 32)
#define FALLHAVEN_ARCIR_BASEMENT_START_X 11
#define FALLHAVEN_ARCIR_BASEMENT_START_Y 7
#define FALLHAVEN_ARCIR_BASEMENT_PLACE_COUNT 3
#define FALLHAVEN_ARCIR_BASEMENT_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_arcir_basement_walkable[FALLHAVEN_ARCIR_BASEMENT_WIDTH * FALLHAVEN_ARCIR_BASEMENT_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_arcir_basement_places[];
extern const unsigned int fallhaven_arcir_basement_place_count;
extern const MapChangeEvent fallhaven_arcir_basement_map_changes[];
extern const unsigned int fallhaven_arcir_basement_map_change_count;

#endif
