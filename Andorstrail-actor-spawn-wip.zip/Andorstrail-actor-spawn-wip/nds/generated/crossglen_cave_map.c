#include "crossglen_cave_map.h"

const MapPlace crossglen_cave_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 2, 19, 1, 1, "entrance", "", "", 0, 0, ""},
    {"sign_crossglen_cave", MAP_PLACE_SIGN, 8, 10, 2, 1, "sign_crossglen_cave", "", "", 0, 0, ""},
    {"crossglen_cave_ratdom_key", MAP_PLACE_SCRIPT, 1, 4, 1, 1, "crossglen_cave_ratdom_key", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 4, 1, 1, "west", "", "", 0, 0, ""},
    {"crossglen_caverat", MAP_PLACE_SPAWN, 4, 11, 12, 5, "crossglen_caverat", "", "", 0, 0, ""},
    {"crossglen_caverat2", MAP_PLACE_SPAWN, 17, 9, 2, 5, "crossglen_caverat2", "", "", 0, 0, ""},
    {"crossglen_caveboss", MAP_PLACE_SPAWN, 2, 4, 1, 1, "crossglen_caveboss", "", "", 0, 0, ""},
    {"crossglen_caverat_1", MAP_PLACE_SPAWN, 7, 3, 11, 4, "crossglen_caverat_1", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 7, 0, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"ratdom_rat_statue", MAP_PLACE_SPAWN, 2, 4, 1, 1, "ratdom_rat_statue", "", "", 0, 0, ""}
};
const MapChangeEvent crossglen_cave_map_changes[] = {
    {2, 19, 1, 1, "crossglen", "cave"},
    {0, 4, 1, 1, "ratdom_maze1", "east"}
};
