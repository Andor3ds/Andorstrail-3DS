#include "blackwater_mountain10_map.h"

const MapPlace blackwater_mountain10_places[] = {
    {"entrance1", MAP_PLACE_MAPCHANGE, 6, 18, 1, 1, "entrance1", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 4, 0, 10, 1, "north", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 7, 1, 3, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 5, 1, 2, "east", "", "", 0, 0, ""},
    {"exit", MAP_PLACE_MAPCHANGE, 3, 3, 1, 1, "exit", "", "", 0, 0, ""},
    {"sign_blackwater10", MAP_PLACE_SIGN, 12, 6, 1, 1, "sign_blackwater10", "", "", 0, 0, ""},
    {"entrance2", MAP_PLACE_MAPCHANGE, 8, 18, 1, 1, "entrance2", "", "", 0, 0, ""},
    {"entrance3", MAP_PLACE_MAPCHANGE, 10, 18, 1, 1, "entrance3", "", "", 0, 0, ""},
    {"omi2_fix_ortholion_guard5", MAP_PLACE_SCRIPT, 7, 10, 3, 1, "omi2_fix_ortholion_guard5", "", "", 0, 0, "enter"},
    {"forestboar4", MAP_PLACE_SPAWN, 10, 2, 7, 8, "forestboar4", "", "", 0, 0, ""},
    {"primwolf1", MAP_PLACE_SPAWN, 2, 5, 12, 10, "primwolf1", "", "", 0, 0, ""},
    {"tonis", MAP_PLACE_SPAWN, 5, 2, 3, 2, "tonis", "", "", 0, 0, ""},
    {"ortholion_guard6", MAP_PLACE_SPAWN, 6, 11, 5, 1, "ortholion_guard6", "", "", 0, 0, ""},
    {"ortholion_guard3a", MAP_PLACE_SPAWN, 4, 14, 1, 4, "ortholion_guard3a", "", "", 0, 0, ""},
    {"ortholion_guard3", MAP_PLACE_SPAWN, 12, 11, 4, 4, "ortholion_guard3", "", "", 0, 0, ""},
    {"ortholion_guard5", MAP_PLACE_SPAWN, 7, 15, 3, 2, "ortholion_guard5", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain10_map_changes[] = {
    {6, 18, 1, 1, "blackwater_mountain9", "exit1"},
    {4, 0, 10, 1, "blackwater_mountain11", "south"},
    {0, 7, 1, 3, "blackwater_mountain12", "east"},
    {19, 5, 1, 2, "blackwater_mountain14", "west"},
    {8, 18, 1, 1, "blackwater_mountain9", "exit2"},
    {10, 18, 1, 1, "blackwater_mountain9", "exit3"}
};
