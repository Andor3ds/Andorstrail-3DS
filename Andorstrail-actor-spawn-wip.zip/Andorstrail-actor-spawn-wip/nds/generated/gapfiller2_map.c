#include "gapfiller2_map.h"

const MapPlace gapfiller2_places[] = {
    {"south2", MAP_PLACE_MAPCHANGE, 18, 25, 1, 1, "south2", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 3, 25, 3, 1, "south1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 22, 17, 1, 7, "east2", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 22, 14, 1, 2, "east1", "", "", 0, 0, ""},
    {"north1", MAP_PLACE_MAPCHANGE, 0, 0, 7, 1, "north1", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 1, 1, 7, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 13, 1, 6, "west2", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 13, 0, 2, 1, "north2", "", "", 0, 0, ""},
    {"chk_wild_berry", MAP_PLACE_SCRIPT, 13, 0, 2, 1, "chk_wild_berry", "", "", 0, 0, "always"},
    {"chk_lytwing_fallhaven", MAP_PLACE_SCRIPT, 12, 1, 4, 1, "chk_lytwing_fallhaven", "", "", 0, 0, "enter"},
    {"lytwing_fallhaven_tree", MAP_PLACE_SIGN, 8, 10, 3, 3, "lytwing_fallhaven_tree", "", "", 0, 0, ""},
    {"white_cabin_unlocked_selector", MAP_PLACE_SCRIPT, 13, 21, 2, 1, "white_cabin_unlocked_selector", "", "", 0, 0, "enter"},
    {"cabin", MAP_PLACE_MAPCHANGE, 13, 19, 1, 1, "cabin", "", "", 0, 0, ""},
    {"forestant", MAP_PLACE_SPAWN, 20, 15, 1, 2, "forestant", "", "", 0, 0, ""},
    {"forestbeetle", MAP_PLACE_SPAWN, 19, 17, 2, 7, "forestbeetle", "", "", 0, 0, ""},
    {"giant_snake", MAP_PLACE_SPAWN, 6, 22, 5, 3, "giant_snake", "", "", 0, 0, ""},
    {"wild_berry", MAP_PLACE_SPAWN, 12, 5, 10, 9, "wild_berry", "", "", 0, 0, ""},
    {"lytwing_circle", MAP_PLACE_SPAWN, 8, 7, 4, 5, "lytwing_circle", "", "", 0, 0, ""},
    {"dummy_key", MAP_PLACE_KEY, 6, 23, 1, 1, "dummy_key", "questProgress", "andor", 1, 0, ""},
    {"dummy_key", MAP_PLACE_KEY, 7, 22, 1, 1, "dummy_key", "questProgress", "andor", 1, 0, ""},
    {"whitecabin_key", MAP_PLACE_KEY, 13, 19, 1, 1, "sign_whitecabin", "questProgress", "nocmar", 90, 0, ""}
};
const MapChangeEvent gapfiller2_map_changes[] = {
    {18, 25, 1, 1, "wild9", "north2"},
    {3, 25, 3, 1, "wild9", "north1"},
    {22, 17, 1, 7, "fallhaven_sw", "west2"},
    {22, 14, 1, 2, "fallhaven_sw", "west1"},
    {0, 0, 7, 1, "wild3", "south2"},
    {0, 1, 1, 7, "wild5", "east1"},
    {0, 13, 1, 6, "wild5", "east2"},
    {13, 0, 2, 1, "gapfiller4", "south"},
    {13, 19, 1, 1, "white_house", "entrance"}
};
