#ifndef ANDOR_LONEFORD17_MAP_H
#define ANDOR_LONEFORD17_MAP_H
#include "map_data.h"

#define LONEFORD17_WIDTH 9
#define LONEFORD17_HEIGHT 8
#define LONEFORD17_PIXEL_WIDTH (LONEFORD17_WIDTH * 32)
#define LONEFORD17_PIXEL_HEIGHT (LONEFORD17_HEIGHT * 32)
#define LONEFORD17_START_X 3
#define LONEFORD17_START_Y 7
#define LONEFORD17_PLACE_COUNT 2
#define LONEFORD17_MAP_CHANGE_COUNT 1

static const unsigned char loneford17_walkable[LONEFORD17_WIDTH * LONEFORD17_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 0, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0
};

extern const MapPlace loneford17_places[];
extern const unsigned int loneford17_place_count;
extern const MapChangeEvent loneford17_map_changes[];
extern const unsigned int loneford17_map_change_count;

#endif
