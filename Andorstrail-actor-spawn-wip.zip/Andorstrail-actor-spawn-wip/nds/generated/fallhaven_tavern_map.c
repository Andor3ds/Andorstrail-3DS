#include "fallhaven_tavern_map.h"

const MapPlace fallhaven_tavern_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 5, 10, 1, 1, "entrance", "", "", 0, 0, ""},
    {"rest1", MAP_PLACE_REST, 18, 10, 1, 1, "rest1", "", "", 0, 0, ""},
    {"rest2", MAP_PLACE_REST, 18, 15, 1, 1, "rest2", "", "", 0, 0, ""},
    {"gal_chk_h2", MAP_PLACE_SCRIPT, 4, 9, 3, 1, "gal_chk_h2", "", "", 0, 0, ""},
    {"drunk", MAP_PLACE_SPAWN, 2, 4, 7, 4, "drunk", "", "", 0, 0, ""},
    {"Bela", MAP_PLACE_SPAWN, 13, 4, 2, 2, "Bela", "", "", 0, 0, ""},
    {"Ganos", MAP_PLACE_SPAWN, 1, 7, 1, 1, "Ganos", "", "", 0, 0, ""},
    {"burhczyd2", MAP_PLACE_SPAWN, 8, 8, 1, 1, "burhczyd2", "", "", 0, 0, ""},
    {"burhczyd2e", MAP_PLACE_SPAWN, 8, 8, 1, 1, "burhczyd2e", "", "", 0, 0, ""},
    {"Bela_2", MAP_PLACE_SPAWN, 18, 7, 1, 1, "Bela_2", "", "", 0, 0, ""},
    {"fallhaventavern:20", MAP_PLACE_KEY, 14, 9, 1, 1, "fallhaven_tavern_room", "questProgress", "fallhaventavern", 20, 0, ""},
    {"fallhaventavern:10", MAP_PLACE_KEY, 14, 14, 1, 1, "fallhaven_tavern_room", "questProgress", "fallhaventavern", 10, 0, ""},
    {"Thieves03:3", MAP_PLACE_KEY, 15, 14, 1, 2, "guild03_rest2", "questProgress", "Thieves03", 3, 0, ""},
    {"guild03_rest3", MAP_PLACE_SCRIPT, 18, 14, 1, 2, "guild03_rest3", "", "", 0, 0, "enter"},
    {"guild03_rest1", MAP_PLACE_SCRIPT, 17, 15, 1, 2, "guild03_rest1", "", "", 0, 0, "enter"}
};
const MapChangeEvent fallhaven_tavern_map_changes[] = {
    {5, 10, 1, 1, "fallhaven_nw", "tavern"}
};
