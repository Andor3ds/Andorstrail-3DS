#include "thieves_vault_map.h"

const MapPlace thieves_vault_places[] = {
    {"tunnel", MAP_PLACE_MAPCHANGE, 7, 13, 1, 1, "tunnel", "", "", 0, 0, ""},
    {"up", MAP_PLACE_MAPCHANGE, 7, 5, 1, 1, "up", "", "", 0, 0, ""},
    {"feygard_necklace_dl", MAP_PLACE_CONTAINER, 6, 3, 1, 1, "feygard_necklace_dl", "", "", 0, 0, ""},
    {"thieves_vault_silver", MAP_PLACE_CONTAINER, 3, 12, 1, 1, "thieves_vault_silver", "", "", 0, 0, ""},
    {"thieves_vault_gold", MAP_PLACE_CONTAINER, 2, 12, 1, 1, "thieves_vault_gold", "", "", 0, 0, ""},
    {"thieves_vault_gold", MAP_PLACE_CONTAINER, 12, 4, 1, 1, "thieves_vault_gold", "", "", 0, 0, ""},
    {"thieves_vault_gold", MAP_PLACE_CONTAINER, 12, 3, 1, 1, "thieves_vault_gold", "", "", 0, 0, ""},
    {"thieves_vault_gold", MAP_PLACE_CONTAINER, 9, 6, 1, 1, "thieves_vault_gold", "", "", 0, 0, ""},
    {"thieves_vault_silver", MAP_PLACE_CONTAINER, 3, 3, 1, 1, "thieves_vault_silver", "", "", 0, 0, ""},
    {"thieves_vault_gold", MAP_PLACE_CONTAINER, 5, 7, 1, 1, "thieves_vault_gold", "", "", 0, 0, ""},
    {"thieves_vault_bronze", MAP_PLACE_CONTAINER, 4, 12, 1, 1, "thieves_vault_bronze", "", "", 0, 0, ""},
    {"thieves_vault_jewelery", MAP_PLACE_CONTAINER, 1, 5, 1, 1, "thieves_vault_jewelery", "", "", 0, 0, ""}
};
const MapChangeEvent thieves_vault_map_changes[] = {
    {7, 13, 1, 1, "thieves_vault_tunnel", "vault"},
    {7, 5, 1, 1, "wild6", "down"}
};
