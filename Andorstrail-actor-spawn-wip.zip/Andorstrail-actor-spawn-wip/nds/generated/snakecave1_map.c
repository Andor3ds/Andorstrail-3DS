#include "snakecave1_map.h"

const MapPlace snakecave1_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 10, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 13, 1, 1, "west", "", "", 0, 0, ""},
    {"cavesnake1", MAP_PLACE_SPAWN, 9, 12, 9, 4, "cavesnake1", "", "", 0, 0, ""},
    {"cavesnake1_1", MAP_PLACE_SPAWN, 1, 4, 5, 5, "cavesnake1_1", "", "", 0, 0, ""},
    {"cavesnake1_2", MAP_PLACE_SPAWN, 13, 6, 1, 4, "cavesnake1_2", "", "", 0, 0, ""},
    {"cavesnake1_3", MAP_PLACE_SPAWN, 7, 8, 1, 3, "cavesnake1_3", "", "", 0, 0, ""},
    {"cavesnake1_4", MAP_PLACE_SPAWN, 2, 12, 5, 4, "cavesnake1_4", "", "", 0, 0, ""}
};
const MapChangeEvent snakecave1_map_changes[] = {
    {10, 19, 1, 1, "wild2", "cave"},
    {0, 13, 1, 1, "snakecave2", "east"}
};
