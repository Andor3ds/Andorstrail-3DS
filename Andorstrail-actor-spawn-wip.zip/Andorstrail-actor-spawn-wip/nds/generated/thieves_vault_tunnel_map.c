#include "thieves_vault_tunnel_map.h"

const MapPlace thieves_vault_tunnel_places[] = {
    {"basement", MAP_PLACE_MAPCHANGE, 1, 4, 1, 1, "basement", "", "", 0, 0, ""},
    {"vault", MAP_PLACE_MAPCHANGE, 1, 0, 1, 1, "vault", "", "", 0, 0, ""}
};
const MapChangeEvent thieves_vault_tunnel_map_changes[] = {
    {1, 4, 1, 1, "wild6_house_basement", "tunnel"},
    {1, 0, 1, 1, "thieves_vault", "tunnel"}
};
