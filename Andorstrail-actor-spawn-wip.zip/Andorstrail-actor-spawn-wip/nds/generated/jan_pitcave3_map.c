#include "jan_pitcave3_map.h"

const MapPlace jan_pitcave3_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 2, 2, 1, 1, "up", "", "", 0, 0, ""},
    {"pitcave_boss", MAP_PLACE_SPAWN, 4, 4, 5, 5, "pitcave_boss", "", "", 0, 0, ""}
};
const MapChangeEvent jan_pitcave3_map_changes[] = {
    {2, 2, 1, 1, "jan_pitcave2", "down"}
};
