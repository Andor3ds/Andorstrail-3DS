#ifndef ANDOR_FALLHAVEN_CLOTHES_MAP_H
#define ANDOR_FALLHAVEN_CLOTHES_MAP_H
#include "map_data.h"

#define FALLHAVEN_CLOTHES_WIDTH 20
#define FALLHAVEN_CLOTHES_HEIGHT 12
#define FALLHAVEN_CLOTHES_PIXEL_WIDTH (FALLHAVEN_CLOTHES_WIDTH * 32)
#define FALLHAVEN_CLOTHES_PIXEL_HEIGHT (FALLHAVEN_CLOTHES_HEIGHT * 32)
#define FALLHAVEN_CLOTHES_START_X 4
#define FALLHAVEN_CLOTHES_START_Y 11
#define FALLHAVEN_CLOTHES_PLACE_COUNT 7
#define FALLHAVEN_CLOTHES_MAP_CHANGE_COUNT 2

static const unsigned char fallhaven_clothes_walkable[FALLHAVEN_CLOTHES_WIDTH * FALLHAVEN_CLOTHES_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_clothes_places[];
extern const unsigned int fallhaven_clothes_place_count;
extern const MapChangeEvent fallhaven_clothes_map_changes[];
extern const unsigned int fallhaven_clothes_map_change_count;

#endif
