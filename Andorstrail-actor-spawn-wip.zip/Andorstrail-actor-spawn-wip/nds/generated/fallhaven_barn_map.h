#ifndef ANDOR_FALLHAVEN_BARN_MAP_H
#define ANDOR_FALLHAVEN_BARN_MAP_H
#include "map_data.h"

#define FALLHAVEN_BARN_WIDTH 17
#define FALLHAVEN_BARN_HEIGHT 10
#define FALLHAVEN_BARN_PIXEL_WIDTH (FALLHAVEN_BARN_WIDTH * 32)
#define FALLHAVEN_BARN_PIXEL_HEIGHT (FALLHAVEN_BARN_HEIGHT * 32)
#define FALLHAVEN_BARN_START_X 12
#define FALLHAVEN_BARN_START_Y 9
#define FALLHAVEN_BARN_PLACE_COUNT 4
#define FALLHAVEN_BARN_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_barn_walkable[FALLHAVEN_BARN_WIDTH * FALLHAVEN_BARN_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0
};

extern const MapPlace fallhaven_barn_places[];
extern const unsigned int fallhaven_barn_place_count;
extern const MapChangeEvent fallhaven_barn_map_changes[];
extern const unsigned int fallhaven_barn_map_change_count;

#endif
