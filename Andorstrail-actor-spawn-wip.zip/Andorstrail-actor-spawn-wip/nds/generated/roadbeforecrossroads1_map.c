#include "roadbeforecrossroads1_map.h"

const MapPlace roadbeforecrossroads1_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 3, 1, 5, "west", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 22, 27, 5, 1, "south2", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 9, 27, 4, 1, "south1", "", "", 0, 0, ""},
    {"down south", MAP_PLACE_MAPCHANGE, 8, 20, 1, 1, "down south", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 24, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"sign_roadbeforecrossroads1", MAP_PLACE_SIGN, 19, 6, 3, 5, "sign_roadbeforecrossroads1", "", "", 0, 0, ""},
    {"fox2", MAP_PLACE_SPAWN, 6, 3, 5, 2, "fox2", "", "", 0, 0, ""},
    {"jelly1", MAP_PLACE_SPAWN, 5, 14, 6, 9, "jelly1", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 16, 19, 5, 4, "forestserpent1", "", "", 0, 0, ""},
    {"forestfly1", MAP_PLACE_SPAWN, 24, 4, 4, 6, "forestfly1", "", "", 0, 0, ""},
    {"forestwolf2", MAP_PLACE_SPAWN, 20, 12, 4, 3, "forestwolf2", "", "", 0, 0, ""}
};
const MapChangeEvent roadbeforecrossroads1_map_changes[] = {
    {0, 3, 1, 5, "roadbeforecrossroads", "east"},
    {22, 27, 5, 1, "roadbeforecrossroads2", "north2"},
    {9, 27, 4, 1, "roadbeforecrossroads2", "north1"},
    {8, 20, 1, 1, "roadcave0", "up north"},
    {24, 0, 1, 1, "lodar0", "south"}
};
