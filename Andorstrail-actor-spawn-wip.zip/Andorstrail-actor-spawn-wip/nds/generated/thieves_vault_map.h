#ifndef ANDOR_THIEVES_VAULT_MAP_H
#define ANDOR_THIEVES_VAULT_MAP_H
#include "map_data.h"

#define THIEVES_VAULT_WIDTH 14
#define THIEVES_VAULT_HEIGHT 14
#define THIEVES_VAULT_PIXEL_WIDTH (THIEVES_VAULT_WIDTH * 32)
#define THIEVES_VAULT_PIXEL_HEIGHT (THIEVES_VAULT_HEIGHT * 32)
#define THIEVES_VAULT_START_X 7
#define THIEVES_VAULT_START_Y 5
#define THIEVES_VAULT_PLACE_COUNT 12
#define THIEVES_VAULT_MAP_CHANGE_COUNT 2

static const unsigned char thieves_vault_walkable[THIEVES_VAULT_WIDTH * THIEVES_VAULT_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0
};

extern const MapPlace thieves_vault_places[];
extern const unsigned int thieves_vault_place_count;
extern const MapChangeEvent thieves_vault_map_changes[];
extern const unsigned int thieves_vault_map_change_count;

#endif
