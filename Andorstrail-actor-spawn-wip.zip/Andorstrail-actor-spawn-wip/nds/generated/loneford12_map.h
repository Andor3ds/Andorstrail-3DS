#ifndef ANDOR_LONEFORD12_MAP_H
#define ANDOR_LONEFORD12_MAP_H
#include "map_data.h"

#define LONEFORD12_WIDTH 8
#define LONEFORD12_HEIGHT 17
#define LONEFORD12_PIXEL_WIDTH (LONEFORD12_WIDTH * 32)
#define LONEFORD12_PIXEL_HEIGHT (LONEFORD12_HEIGHT * 32)
#define LONEFORD12_START_X 0
#define LONEFORD12_START_Y 1
#define LONEFORD12_PLACE_COUNT 3
#define LONEFORD12_MAP_CHANGE_COUNT 3

static const unsigned char loneford12_walkable[LONEFORD12_WIDTH * LONEFORD12_HEIGHT] = {
    0, 0, 0, 1, 1, 1, 1, 0,
    1, 1, 0, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 0, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace loneford12_places[];
extern const unsigned int loneford12_place_count;
extern const MapChangeEvent loneford12_map_changes[];
extern const unsigned int loneford12_map_change_count;

#endif
