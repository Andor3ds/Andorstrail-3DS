#include "mywild19_map.h"

const MapPlace mywild19_places[] = {
    {"west1", MAP_PLACE_MAPCHANGE, 0, 5, 1, 2, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 10, 1, 1, "west2", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 16, 1, 2, "west3", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 23, 3, 1, 1, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 23, 10, 1, 1, "east2", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 23, 16, 1, 1, "east3", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 12, 19, 1, 1, "south", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 3, 4, 6, 5, "forestserpent1", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 4, 7, 3, 5, "forestwolf1", "", "", 0, 0, ""},
    {"forestserpent1", MAP_PLACE_SPAWN, 3, 12, 12, 4, "forestserpent1", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 13, 4, 7, 11, "forestwolf1", "", "", 0, 0, ""}
};
const MapChangeEvent mywild19_map_changes[] = {
    {0, 5, 1, 2, "mywild18", "east1"},
    {0, 10, 1, 1, "mywild18", "east2"},
    {0, 16, 1, 2, "mywild18", "east3"},
    {23, 3, 1, 1, "mywild20", "west1"},
    {23, 10, 1, 1, "mywild20", "west2"},
    {23, 16, 1, 1, "mywild20", "west3"},
    {12, 19, 1, 1, "mywildcave", "north"}
};
