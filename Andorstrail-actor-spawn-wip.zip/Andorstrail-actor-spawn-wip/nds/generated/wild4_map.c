#include "wild4_map.h"

const MapPlace wild4_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 3, 1, 1, "west", "", "", 0, 0, ""},
    {"entrance", MAP_PLACE_MAPCHANGE, 11, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"fox1", MAP_PLACE_SPAWN, 2, 3, 6, 5, "fox1", "", "", 0, 0, ""},
    {"minorhaunt1", MAP_PLACE_SPAWN, 6, 6, 8, 5, "minorhaunt1", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 6, 2, 13, 5, "forestwasp", "", "", 0, 0, ""},
    {"forestwasp_1", MAP_PLACE_SPAWN, 4, 10, 15, 4, "forestwasp_1", "", "", 0, 0, ""},
    {"forestwasp_2", MAP_PLACE_SPAWN, 22, 3, 7, 7, "forestwasp_2", "", "", 0, 0, ""}
};
const MapChangeEvent wild4_map_changes[] = {
    {0, 3, 1, 1, "wild1", "east"},
    {11, 7, 1, 1, "hauntedhouse1", "entrance"}
};
