#include "lodar0_map.h"

const MapPlace lodar0_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 6, 29, 1, 1, "south", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 24, 1, 1, "west", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 29, 18, 1, 2, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 5, 1, 3, "east2", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 1, 0, 4, 1, "north", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 1, 1, 15, "west2", "", "", 0, 0, ""},
    {"forestfly1", MAP_PLACE_SPAWN, 2, 24, 1, 2, "forestfly1", "", "", 0, 0, ""},
    {"lodar0_g", MAP_PLACE_SPAWN, 18, 25, 1, 1, "lodar0_g", "", "", 0, 0, ""},
    {"forestfly1_1", MAP_PLACE_SPAWN, 4, 26, 1, 2, "forestfly1_1", "", "", 0, 0, ""},
    {"forestfly1_2", MAP_PLACE_SPAWN, 8, 24, 9, 5, "forestfly1_2", "", "", 0, 0, ""},
    {"forestfly1_3", MAP_PLACE_SPAWN, 20, 21, 9, 8, "forestfly1_3", "", "", 0, 0, ""},
    {"forestfly1_4", MAP_PLACE_SPAWN, 14, 8, 3, 7, "forestfly1_4", "", "", 0, 0, ""},
    {"hanklbit1", MAP_PLACE_SPAWN, 15, 15, 1, 1, "hanklbit1", "", "", 0, 0, ""},
    {"hanklbit1_1", MAP_PLACE_SPAWN, 6, 11, 7, 6, "hanklbit1_1", "", "", 0, 0, ""},
    {"forestfly1_5", MAP_PLACE_SPAWN, 9, 3, 13, 5, "forestfly1_5", "", "", 0, 0, ""},
    {"forestfly1_6", MAP_PLACE_SPAWN, 21, 6, 7, 11, "forestfly1_6", "", "", 0, 0, ""},
    {"forestfly1_7", MAP_PLACE_SPAWN, 15, 16, 10, 5, "forestfly1_7", "", "", 0, 0, ""},
    {"forestfly1_8", MAP_PLACE_SPAWN, 9, 17, 6, 5, "forestfly1_8", "", "", 0, 0, ""}
};
const MapChangeEvent lodar0_map_changes[] = {
    {6, 29, 1, 1, "roadbeforecrossroads1", "north"},
    {0, 24, 1, 1, "lodar1", "east"},
    {29, 18, 1, 2, "lodar5", "west"},
    {29, 5, 1, 3, "lodar2", "west"},
    {1, 0, 4, 1, "loneford13", "south"},
    {0, 1, 1, 15, "loneford12", "east"}
};
