#include "hauntedhouse4_map.h"

const MapPlace hauntedhouse4_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 2, 7, 1, 1, "south", "", "", 0, 0, ""},
    {"skeletonmaster", MAP_PLACE_SPAWN, 6, 3, 3, 4, "skeletonmaster", "", "", 0, 0, ""},
    {"skeleton1", MAP_PLACE_SPAWN, 1, 2, 5, 4, "skeleton1", "", "", 0, 0, ""}
};
const MapChangeEvent hauntedhouse4_map_changes[] = {
    {2, 7, 1, 1, "hauntedhouse3", "north"}
};
