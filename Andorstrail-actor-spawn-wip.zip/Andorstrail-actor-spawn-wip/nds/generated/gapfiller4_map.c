#include "gapfiller4_map.h"

const MapPlace gapfiller4_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 14, 4, 1, 1, "east", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 11, 1, 1, "west", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 5, 23, 2, 1, "south", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 15, 1, 8, "west2", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 14, 14, 1, 2, "east2", "", "", 0, 0, ""},
    {"forestdog", MAP_PLACE_SPAWN, 2, 16, 10, 6, "forestdog", "", "", 0, 0, ""},
    {"fallhaven_guard", MAP_PLACE_SPAWN, 8, 4, 4, 4, "fallhaven_guard", "", "", 0, 0, ""}
};
const MapChangeEvent gapfiller4_map_changes[] = {
    {14, 4, 1, 1, "fallhaven_nw", "west"},
    {0, 11, 1, 1, "wild3", "east"},
    {5, 23, 2, 1, "gapfiller2", "north2"},
    {0, 15, 1, 8, "wild3", "east2"},
    {14, 14, 1, 2, "fallhaven_nw", "west2"}
};
