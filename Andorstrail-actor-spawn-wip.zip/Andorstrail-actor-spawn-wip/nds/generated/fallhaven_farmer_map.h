#ifndef ANDOR_FALLHAVEN_FARMER_MAP_H
#define ANDOR_FALLHAVEN_FARMER_MAP_H
#include "map_data.h"

#define FALLHAVEN_FARMER_WIDTH 12
#define FALLHAVEN_FARMER_HEIGHT 8
#define FALLHAVEN_FARMER_PIXEL_WIDTH (FALLHAVEN_FARMER_WIDTH * 32)
#define FALLHAVEN_FARMER_PIXEL_HEIGHT (FALLHAVEN_FARMER_HEIGHT * 32)
#define FALLHAVEN_FARMER_START_X 2
#define FALLHAVEN_FARMER_START_Y 7
#define FALLHAVEN_FARMER_PLACE_COUNT 2
#define FALLHAVEN_FARMER_MAP_CHANGE_COUNT 1

static const unsigned char fallhaven_farmer_walkable[FALLHAVEN_FARMER_WIDTH * FALLHAVEN_FARMER_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0,
    0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace fallhaven_farmer_places[];
extern const unsigned int fallhaven_farmer_place_count;
extern const MapChangeEvent fallhaven_farmer_map_changes[];
extern const unsigned int fallhaven_farmer_map_change_count;

#endif
