#include "loneford13_map.h"

const MapPlace loneford13_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 6, "west", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 10, 11, 4, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 26, 10, 1, 1, "east", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 6, 0, 3, 1, "north", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 3, 11, 4, 1, "south2", "", "", 0, 0, ""},
    {"outside", MAP_PLACE_MAPCHANGE, 12, 2, 1, 1, "outside", "", "", 0, 0, ""},
    {"gqtombstone_1", MAP_PLACE_SIGN, 17, 8, 1, 1, "gqtombstone_1", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 3, 1, 1, "west3", "", "", 0, 0, ""},
    {"sign_loneford2", MAP_PLACE_SIGN, 2, 2, 1, 1, "sign_loneford2", "", "", 0, 0, ""},
    {"outside2", MAP_PLACE_MAPCHANGE, 19, 3, 1, 1, "outside2", "", "", 0, 0, ""},
    {"loneford_well_script_1", MAP_PLACE_SCRIPT, 23, 3, 2, 3, "loneford_well_script_1", "", "", 0, 0, "enter"},
    {"gqtombstone_2", MAP_PLACE_SIGN, 19, 8, 1, 1, "gqtombstone_2", "", "", 0, 0, ""},
    {"loneford13_pitchfork", MAP_PLACE_KEY, 25, 8, 1, 1, "loneford13_pitchfork_selector", "questProgress", "sullengard_hidden", 500, 0, ""}
};
const MapChangeEvent loneford13_map_changes[] = {
    {0, 5, 1, 6, "loneford1", "east2"},
    {10, 11, 4, 1, "lodar0", "north"},
    {26, 10, 1, 1, "loneford14", "west"},
    {6, 0, 3, 1, "loneford2", "south2"},
    {3, 11, 4, 1, "loneford12", "north"},
    {12, 2, 1, 1, "loneford16", "inside"},
    {0, 3, 1, 1, "loneford1", "east3"},
    {19, 3, 1, 1, "loneford17", "inside2"}
};
