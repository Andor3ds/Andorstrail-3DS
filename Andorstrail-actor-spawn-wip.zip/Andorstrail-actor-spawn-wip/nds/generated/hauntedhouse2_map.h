#ifndef ANDOR_HAUNTEDHOUSE2_MAP_H
#define ANDOR_HAUNTEDHOUSE2_MAP_H
#include "map_data.h"

#define HAUNTEDHOUSE2_WIDTH 15
#define HAUNTEDHOUSE2_HEIGHT 10
#define HAUNTEDHOUSE2_PIXEL_WIDTH (HAUNTEDHOUSE2_WIDTH * 32)
#define HAUNTEDHOUSE2_PIXEL_HEIGHT (HAUNTEDHOUSE2_HEIGHT * 32)
#define HAUNTEDHOUSE2_START_X 14
#define HAUNTEDHOUSE2_START_Y 5
#define HAUNTEDHOUSE2_PLACE_COUNT 5
#define HAUNTEDHOUSE2_MAP_CHANGE_COUNT 2

static const unsigned char hauntedhouse2_walkable[HAUNTEDHOUSE2_WIDTH * HAUNTEDHOUSE2_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
    0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace hauntedhouse2_places[];
extern const unsigned int hauntedhouse2_place_count;
extern const MapChangeEvent hauntedhouse2_map_changes[];
extern const unsigned int hauntedhouse2_map_change_count;

#endif
