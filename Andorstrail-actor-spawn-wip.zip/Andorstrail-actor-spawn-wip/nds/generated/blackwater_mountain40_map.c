#include "blackwater_mountain40_map.h"

const MapPlace blackwater_mountain40_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 5, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 5, 8, 1, 1, "south", "", "", 0, 0, ""},
    {"kazaul_1", MAP_PLACE_SPAWN, 5, 6, 1, 1, "kazaul_1", "", "", 0, 0, ""},
    {"kazaul_1_1", MAP_PLACE_SPAWN, 7, 4, 3, 4, "kazaul_1_1", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain40_map_changes[] = {
    {5, 0, 1, 1, "blackwater_mountain14", "east"},
    {5, 8, 1, 1, "blackwater_mountain41", "north"}
};
