#include "houseatcrossroads1_map.h"

const MapPlace houseatcrossroads1_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 2, 3, 1, 1, "up", "", "", 0, 0, ""},
    {"rest", MAP_PLACE_REST, 8, 4, 1, 1, "rest", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 13, 2, 1, 1, "north", "", "", 0, 0, ""},
    {"crossroads_guest", MAP_PLACE_SPAWN, 5, 3, 1, 1, "crossroads_guest", "", "", 0, 0, ""},
    {"crossroads_sleepguard", MAP_PLACE_SPAWN, 1, 6, 1, 1, "crossroads_sleepguard", "", "", 0, 0, ""},
    {"crossroads_backguard", MAP_PLACE_SPAWN, 14, 6, 1, 1, "crossroads_backguard", "", "", 0, 0, ""},
    {"crossroads_guest_1", MAP_PLACE_SPAWN, 10, 9, 1, 1, "crossroads_guest_1", "", "", 0, 0, ""},
    {"crossroads_rat", MAP_PLACE_SPAWN, 12, 3, 3, 2, "crossroads_rat", "", "", 0, 0, ""},
    {"nondisplay:17", MAP_PLACE_KEY, 7, 3, 2, 2, "crossroads_sleep", "questProgress", "nondisplay", 17, 0, ""}
};
const MapChangeEvent houseatcrossroads1_map_changes[] = {
    {2, 3, 1, 1, "houseatcrossroads0", "down"},
    {13, 2, 1, 1, "houseatcrossroads5", "south"}
};
