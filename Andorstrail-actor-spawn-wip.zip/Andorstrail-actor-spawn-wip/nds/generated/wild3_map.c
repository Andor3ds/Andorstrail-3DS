#include "wild3_map.h"

const MapPlace wild3_places[] = {
    {"sign_wild3", MAP_PLACE_SIGN, 7, 4, 1, 1, "sign_wild3", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 8, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 5, 1, 3, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 19, 7, 1, 1, "east", "", "", 0, 0, ""},
    {"jan_pitcave", MAP_PLACE_MAPCHANGE, 6, 17, 1, 1, "jan_pitcave", "", "", 0, 0, ""},
    {"sign_wild3_grave", MAP_PLACE_SIGN, 9, 18, 1, 1, "sign_wild3_grave", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 11, 1, 2, "west2", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 9, 19, 3, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 13, 19, 7, 1, "south2", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 19, 11, 1, 8, "east2", "", "", 0, 0, ""},
    {"Jan", MAP_PLACE_SPAWN, 6, 13, 1, 1, "Jan", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 11, 16, 7, 2, "forestwasp", "", "", 0, 0, ""},
    {"forestdog", MAP_PLACE_SPAWN, 9, 9, 9, 7, "forestdog", "", "", 0, 0, ""},
    {"forestant", MAP_PLACE_SPAWN, 14, 2, 5, 3, "forestant", "", "", 0, 0, ""},
    {"forestant_1", MAP_PLACE_SPAWN, 2, 7, 7, 4, "forestant_1", "", "", 0, 0, ""}
};
const MapChangeEvent wild3_map_changes[] = {
    {8, 0, 2, 1, "gapfiller3", "south"},
    {0, 5, 1, 3, "wild2", "east"},
    {19, 7, 1, 1, "gapfiller4", "west"},
    {6, 17, 1, 1, "jan_pitcave1", "up"},
    {0, 11, 1, 2, "wild2", "east2"},
    {9, 19, 3, 1, "wild5", "northeast"},
    {13, 19, 7, 1, "gapfiller2", "north1"},
    {19, 11, 1, 8, "gapfiller4", "west2"}
};
