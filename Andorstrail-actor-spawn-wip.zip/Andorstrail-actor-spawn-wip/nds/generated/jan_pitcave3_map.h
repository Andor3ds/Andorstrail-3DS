#ifndef ANDOR_JAN_PITCAVE3_MAP_H
#define ANDOR_JAN_PITCAVE3_MAP_H
#include "map_data.h"

#define JAN_PITCAVE3_WIDTH 10
#define JAN_PITCAVE3_HEIGHT 10
#define JAN_PITCAVE3_PIXEL_WIDTH (JAN_PITCAVE3_WIDTH * 32)
#define JAN_PITCAVE3_PIXEL_HEIGHT (JAN_PITCAVE3_HEIGHT * 32)
#define JAN_PITCAVE3_START_X 2
#define JAN_PITCAVE3_START_Y 2
#define JAN_PITCAVE3_PLACE_COUNT 2
#define JAN_PITCAVE3_MAP_CHANGE_COUNT 1

static const unsigned char jan_pitcave3_walkable[JAN_PITCAVE3_WIDTH * JAN_PITCAVE3_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace jan_pitcave3_places[];
extern const unsigned int jan_pitcave3_place_count;
extern const MapChangeEvent jan_pitcave3_map_changes[];
extern const unsigned int jan_pitcave3_map_change_count;

#endif
