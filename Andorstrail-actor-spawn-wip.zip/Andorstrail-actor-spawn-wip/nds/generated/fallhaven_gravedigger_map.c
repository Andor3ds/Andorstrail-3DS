#include "fallhaven_gravedigger_map.h"

const MapPlace fallhaven_gravedigger_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 2, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"hatchway", MAP_PLACE_MAPCHANGE, 7, 4, 1, 1, "hatchway", "", "", 0, 0, ""},
    {"Hatchlever", MAP_PLACE_KEY, 4, 3, 1, 1, "guild02_hatchlever", "questProgress", "thieves_hidden", 10, 0, ""}
};
const MapChangeEvent fallhaven_gravedigger_map_changes[] = {
    {2, 7, 1, 1, "fallhaven_ne", "gravedigger"},
    {7, 4, 1, 1, "guildbrig1", "ladder"}
};
