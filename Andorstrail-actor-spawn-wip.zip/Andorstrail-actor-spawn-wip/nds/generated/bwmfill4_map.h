#ifndef ANDOR_BWMFILL4_MAP_H
#define ANDOR_BWMFILL4_MAP_H
#include "map_data.h"

#define BWMFILL4_WIDTH 6
#define BWMFILL4_HEIGHT 22
#define BWMFILL4_PIXEL_WIDTH (BWMFILL4_WIDTH * 32)
#define BWMFILL4_PIXEL_HEIGHT (BWMFILL4_HEIGHT * 32)
#define BWMFILL4_START_X 1
#define BWMFILL4_START_Y 0
#define BWMFILL4_PLACE_COUNT 7
#define BWMFILL4_MAP_CHANGE_COUNT 5

static const unsigned char bwmfill4_walkable[BWMFILL4_WIDTH * BWMFILL4_HEIGHT] = {
    0, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1,
    0, 1, 1, 1, 1, 1,
    0, 1, 1, 1, 1, 1,
    0, 0, 1, 1, 1, 1,
    0, 0, 0, 0, 1, 1,
    0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 1, 1,
    0, 1, 0, 1, 1, 1,
    0, 1, 1, 1, 1, 1,
    0, 1, 1, 1, 1, 1,
    0, 1, 1, 0, 0, 0,
    0, 1, 1, 0, 0, 0,
    0, 1, 1, 1, 0, 0,
    0, 1, 0, 1, 0, 0
};

extern const MapPlace bwmfill4_places[];
extern const unsigned int bwmfill4_place_count;
extern const MapChangeEvent bwmfill4_map_changes[];
extern const unsigned int bwmfill4_map_change_count;

#endif
