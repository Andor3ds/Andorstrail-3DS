#include "fields8_map.h"

const MapPlace fields8_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 0, 0, 30, 1, "north", "", "", 0, 0, ""},
    {"east1", MAP_PLACE_MAPCHANGE, 29, 1, 1, 2, "east1", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 4, 1, 10, "east2", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 1, 14, 21, 1, "south1", "", "", 0, 0, ""},
    {"south2", MAP_PLACE_MAPCHANGE, 23, 14, 5, 1, "south2", "", "", 0, 0, ""},
    {"west1", MAP_PLACE_MAPCHANGE, 0, 1, 1, 2, "west1", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 4, 1, 10, "west2", "", "", 0, 0, ""},
    {"fieldwasp_unique", MAP_PLACE_SPAWN, 2, 4, 26, 9, "fieldwasp_unique", "", "", 0, 0, ""},
    {"fieldwasp_1", MAP_PLACE_SPAWN, 2, 4, 26, 9, "fieldwasp_1", "", "", 0, 0, ""}
};
const MapChangeEvent fields8_map_changes[] = {
    {0, 0, 30, 1, "fields2", "south"},
    {29, 1, 1, 2, "fields0", "west1"},
    {29, 4, 1, 10, "fields0", "west2"},
    {1, 14, 21, 1, "roadtocarntower0", "north1"},
    {23, 14, 5, 1, "roadtocarntower0", "north2"},
    {0, 1, 1, 2, "fields9", "east1"},
    {0, 4, 1, 10, "fields9", "east2"}
};
