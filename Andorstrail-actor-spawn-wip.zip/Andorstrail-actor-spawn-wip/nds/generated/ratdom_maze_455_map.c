#include "ratdom_maze_455_map.h"

const MapPlace ratdom_maze_455_places[] = {
    {"east", MAP_PLACE_MAPCHANGE, 14, 27, 1, 2, "east", "", "", 0, 0, ""},
    {"south1", MAP_PLACE_MAPCHANGE, 0, 28, 1, 1, "south1", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 13, 0, 2, 2, "north2", "", "", 0, 0, ""},
    {"north1", MAP_PLACE_MAPCHANGE, 0, 0, 2, 2, "north1", "", "", 0, 0, ""},
    {"ratdom_maze_light4", MAP_PLACE_SCRIPT, 0, 0, 4, 6, "ratdom_maze_light4", "", "", 0, 0, "always"},
    {"ratdom_maze_light3", MAP_PLACE_SCRIPT, 11, 0, 4, 6, "ratdom_maze_light3", "", "", 0, 0, "always"},
    {"ratdom_maze_light2", MAP_PLACE_SCRIPT, 0, 24, 4, 6, "ratdom_maze_light2", "", "", 0, 0, "always"},
    {"ratdom_maze_light1", MAP_PLACE_SCRIPT, 11, 24, 4, 6, "ratdom_maze_light1", "", "", 0, 0, "always"},
    {"ratdom_maze_light5", MAP_PLACE_SCRIPT, 4, 3, 7, 6, "ratdom_maze_light5", "", "", 0, 0, "always"},
    {"ratdom_maze_light6", MAP_PLACE_SCRIPT, 4, 20, 7, 8, "ratdom_maze_light6", "", "", 0, 0, "always"},
    {"ratdom_maze_light7", MAP_PLACE_SCRIPT, 5, 9, 6, 11, "ratdom_maze_light7", "", "", 0, 0, "always"},
    {"ratdom_rat_conv1", MAP_PLACE_SCRIPT, 7, 10, 2, 1, "ratdom_rat_conv1", "", "", 0, 0, ""},
    {"ratdom_rat_conv2", MAP_PLACE_SCRIPT, 7, 13, 4, 1, "ratdom_rat_conv2", "", "", 0, 0, ""},
    {"ratdom_rat_conv3", MAP_PLACE_SCRIPT, 6, 19, 3, 1, "ratdom_rat_conv3", "", "", 0, 0, ""},
    {"ratdom_bwm_sign", MAP_PLACE_SCRIPT, 7, 22, 1, 1, "ratdom_bwm_sign", "", "", 0, 0, ""},
    {"ratdom_455_chest", MAP_PLACE_SCRIPT, 9, 28, 1, 1, "ratdom_455_chest", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 7, 0, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"ratdom_m7", MAP_PLACE_SPAWN, 5, 9, 6, 13, "ratdom_m7", "", "", 0, 0, ""},
    {"ratdom_maze_rat", MAP_PLACE_SPAWN, 6, 3, 6, 8, "ratdom_maze_rat", "", "", 0, 0, ""},
    {"burrower_4", MAP_PLACE_SPAWN, 9, 26, 5, 3, "burrower_4", "", "", 0, 0, ""}
};
const MapChangeEvent ratdom_maze_455_map_changes[] = {
    {14, 27, 1, 2, "ratdom_maze_455a", "west"},
    {0, 28, 1, 1, "ratdom_maze_564", "north2"},
    {13, 0, 2, 2, "ratdom_maze_445", "south1"},
    {0, 0, 2, 2, "ratdom_maze_444", "south2"}
};
