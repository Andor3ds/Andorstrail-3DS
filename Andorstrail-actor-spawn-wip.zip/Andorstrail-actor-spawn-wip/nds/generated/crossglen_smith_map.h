#ifndef ANDOR_CROSSGLEN_SMITH_MAP_H
#define ANDOR_CROSSGLEN_SMITH_MAP_H
#include "map_data.h"

#define CROSSGLEN_SMITH_WIDTH 10
#define CROSSGLEN_SMITH_HEIGHT 8
#define CROSSGLEN_SMITH_PIXEL_WIDTH (CROSSGLEN_SMITH_WIDTH * 32)
#define CROSSGLEN_SMITH_PIXEL_HEIGHT (CROSSGLEN_SMITH_HEIGHT * 32)
#define CROSSGLEN_SMITH_START_X 6
#define CROSSGLEN_SMITH_START_Y 7
#define CROSSGLEN_SMITH_PLACE_COUNT 3
#define CROSSGLEN_SMITH_MAP_CHANGE_COUNT 1

static const unsigned char crossglen_smith_walkable[CROSSGLEN_SMITH_WIDTH * CROSSGLEN_SMITH_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 1, 1, 0, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 0, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0
};

extern const MapPlace crossglen_smith_places[];
extern const unsigned int crossglen_smith_place_count;
extern const MapChangeEvent crossglen_smith_map_changes[];
extern const unsigned int crossglen_smith_map_change_count;

#endif
