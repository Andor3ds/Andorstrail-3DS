#include "roadcave0_map.h"

const MapPlace roadcave0_places[] = {
    {"up north", MAP_PLACE_MAPCHANGE, 16, 15, 1, 1, "up north", "", "", 0, 0, ""},
    {"down north", MAP_PLACE_MAPCHANGE, 16, 8, 1, 1, "down north", "", "", 0, 0, ""},
    {"jelly1", MAP_PLACE_SPAWN, 7, 16, 1, 1, "jelly1", "", "", 0, 0, ""},
    {"jelly1_1", MAP_PLACE_SPAWN, 2, 7, 3, 1, "jelly1_1", "", "", 0, 0, ""},
    {"jelly2", MAP_PLACE_SPAWN, 1, 9, 4, 5, "jelly2", "", "", 0, 0, ""},
    {"jelly1_2", MAP_PLACE_SPAWN, 9, 15, 6, 4, "jelly1_2", "", "", 0, 0, ""},
    {"jelly2_1", MAP_PLACE_SPAWN, 3, 15, 3, 3, "jelly2_1", "", "", 0, 0, ""},
    {"jelly1_3", MAP_PLACE_SPAWN, 6, 4, 1, 1, "jelly1_3", "", "", 0, 0, ""},
    {"jelly1_4", MAP_PLACE_SPAWN, 8, 3, 9, 4, "jelly1_4", "", "", 0, 0, ""},
    {"jelly2_2", MAP_PLACE_SPAWN, 9, 6, 6, 4, "jelly2_2", "", "", 0, 0, ""}
};
const MapChangeEvent roadcave0_map_changes[] = {
    {16, 15, 1, 1, "roadbeforecrossroads1", "down south"},
    {16, 8, 1, 1, "roadcave1", "up north"}
};
