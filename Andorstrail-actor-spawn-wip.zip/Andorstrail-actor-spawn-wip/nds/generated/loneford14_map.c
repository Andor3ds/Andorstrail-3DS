#include "loneford14_map.h"

const MapPlace loneford14_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 13, 1, 1, "west", "", "", 0, 0, ""},
    {"outside", MAP_PLACE_MAPCHANGE, 3, 7, 1, 1, "outside", "", "", 0, 0, ""}
};
const MapChangeEvent loneford14_map_changes[] = {
    {0, 13, 1, 1, "loneford13", "east"},
    {3, 7, 1, 1, "loneford15", "inside"}
};
