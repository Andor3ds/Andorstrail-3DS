#include "ratdom_maze2_map.h"

const MapPlace ratdom_maze2_places[] = {
    {"down", MAP_PLACE_MAPCHANGE, 3, 27, 1, 1, "down", "", "", 0, 0, ""},
    {"up", MAP_PLACE_MAPCHANGE, 2, 13, 1, 1, "up", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 7, 4, 1, 1, "east", "", "", 0, 0, ""},
    {"ratdom_maze_light1", MAP_PLACE_SCRIPT, 1, 3, 4, 6, "ratdom_maze_light1", "", "", 0, 0, "always"},
    {"ratdom_maze_light2", MAP_PLACE_SCRIPT, 1, 21, 5, 8, "ratdom_maze_light2", "", "", 0, 0, "always"},
    {"ratdom_maze_light3", MAP_PLACE_SCRIPT, 3, 9, 5, 5, "ratdom_maze_light3", "", "", 0, 0, "always"},
    {"ratdom_maze_light4", MAP_PLACE_SCRIPT, 5, 14, 2, 4, "ratdom_maze_light4", "", "", 0, 0, "always"},
    {"ratdom_maze_light5", MAP_PLACE_SCRIPT, 5, 3, 3, 2, "ratdom_maze_light5", "", "", 0, 0, "always"},
    {"ratdom_maze_light6", MAP_PLACE_SCRIPT, 1, 13, 4, 8, "ratdom_maze_light6", "", "", 0, 0, "always"},
    {"ratdom_rat_conv2", MAP_PLACE_SCRIPT, 1, 19, 1, 1, "ratdom_rat_conv2", "", "", 0, 0, ""},
    {"ratdom_rat", MAP_PLACE_SPAWN, 7, 0, 1, 1, "ratdom_rat", "", "", 0, 0, ""},
    {"crossglen_caverat_2", MAP_PLACE_SPAWN, 3, 10, 2, 1, "crossglen_caverat_2", "", "", 0, 0, ""},
    {"crossglen_caverat", MAP_PLACE_SPAWN, 1, 3, 5, 4, "crossglen_caverat", "", "", 0, 0, ""},
    {"crossglen_caverat_3", MAP_PLACE_SPAWN, 1, 16, 6, 10, "crossglen_caverat_3", "", "", 0, 0, ""}
};
const MapChangeEvent ratdom_maze2_map_changes[] = {
    {3, 27, 1, 1, "ratdom_maze_448", "north2"},
    {2, 13, 1, 1, "ratdom_maze3", "down"},
    {7, 4, 1, 1, "ratdom_maze1", "west"}
};
