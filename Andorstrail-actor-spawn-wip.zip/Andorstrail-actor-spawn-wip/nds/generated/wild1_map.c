#include "wild1_map.h"

const MapPlace wild1_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 15, 1, 2, "west", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 5, 20, 2, 1, "south", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 20, 1, 1, 1, "east", "", "", 0, 0, ""},
    {"sign_wild1", MAP_PLACE_SIGN, 4, 16, 1, 1, "sign_wild1", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 12, 0, 1, 1, "north", "", "", 0, 0, ""},
    {"forestdog", MAP_PLACE_SPAWN, 3, 2, 7, 7, "forestdog", "", "", 0, 0, ""},
    {"forestboar", MAP_PLACE_SPAWN, 2, 2, 4, 5, "forestboar", "", "", 0, 0, ""},
    {"fox1", MAP_PLACE_SPAWN, 10, 19, 4, 1, "fox1", "", "", 0, 0, ""},
    {"fox1_1", MAP_PLACE_SPAWN, 18, 7, 1, 2, "fox1_1", "", "", 0, 0, ""},
    {"fox1_2", MAP_PLACE_SPAWN, 17, 3, 1, 2, "fox1_2", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 9, 11, 6, 5, "forestwasp", "", "", 0, 0, ""}
};
const MapChangeEvent wild1_map_changes[] = {
    {0, 15, 1, 2, "crossglen", "east"},
    {5, 20, 2, 1, "gapfiller3", "north"},
    {20, 1, 1, 1, "wild4", "west"},
    {12, 0, 1, 1, "wild0", "south"}
};
