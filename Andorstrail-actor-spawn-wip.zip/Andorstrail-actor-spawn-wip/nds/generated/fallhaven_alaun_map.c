#include "fallhaven_alaun_map.h"

const MapPlace fallhaven_alaun_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 6, 7, 1, 1, "entrance", "", "", 0, 0, ""},
    {"alaun", MAP_PLACE_SPAWN, 2, 4, 7, 2, "alaun", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_alaun_map_changes[] = {
    {6, 7, 1, 1, "fallhaven_sw", "alaun"}
};
