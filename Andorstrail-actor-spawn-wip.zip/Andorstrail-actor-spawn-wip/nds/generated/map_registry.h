#ifndef ANDOR_MAP_REGISTRY_H
#define ANDOR_MAP_REGISTRY_H

#include "home_map.h"
#include "crossglen_map.h"
#include "crossglen_cave_map.h"
#include "crossglen_hall_map.h"
#include "crossglen_farmhouse_map.h"
#include "crossglen_smith_map.h"
#include "wild1_map.h"
#include "wild2_map.h"
#include "ratdom_bwm1_map.h"
#include "ratdom_maze1_map.h"
#include "crossglen_farmhouse_basement_map.h"
#include "gapfiller3_map.h"
#include "wild4_map.h"
#include "wild0_map.h"
#include "wild3_map.h"
#include "snakecave1_map.h"
#include "wild5_map.h"
#include "bwmfill6_map.h"
#include "bwmfill7_map.h"
#include "ratdom_maze3_map.h"
#include "bwmfill3_map.h"
#include "bwmfill2_map.h"
#include "ratdom_maze2_map.h"
#include "hauntedhouse1_map.h"
#include "crossroads_map.h"
#include "woodcave1_map.h"
#include "woodcave0_map.h"
#include "gapfiller4_map.h"
#include "jan_pitcave1_map.h"
#include "gapfiller2_map.h"
#include "snakecave2_map.h"
#include "wild6_map.h"
#include "bwmfill5_map.h"
#include "blackwater_mountain30_map.h"
#include "blackwater_mountain16_map.h"
#include "blackwater_mountain56_map.h"
#include "bwmfill4_map.h"
#include "bwmfill_tunlon_map.h"
#include "blackwater_mountain54_map.h"
#include "bwmfill1_map.h"
#include "ratdom_maze_448_map.h"
#include "hauntedhouse2_map.h"
#include "loneford1_map.h"
#include "roadbeforecrossroads_map.h"
#include "fields0_map.h"
#include "roadtocarntower0_map.h"
#include "houseatcrossroads0_map.h"
#include "crackshot_hideout1_map.h"
#include "fallhaven_nw_map.h"
#include "jan_pitcave2_map.h"
#include "wild9_map.h"
#include "fallhaven_sw_map.h"
#include "white_house_map.h"
#include "snakecave3_map.h"
#include "wild7_map.h"
#include "wild6_house_map.h"
#include "bwmfill8_map.h"
#include "thieves_vault_map.h"
#include "blackwater_mountain39_map.h"
#include "blackwater_mountain32_map.h"
#include "blackwater_mountain31_map.h"
#include "blackwater_mountain15_map.h"
#include "blackwater_mountain53_map.h"
#include "blackwater_mountain55_map.h"
#include "ratdom_maze_458_map.h"
#include "ratdom_maze_438_map.h"
#include "hauntedhouse3_map.h"
#include "loneford13_map.h"
#include "fields1_map.h"
#include "fields4_map.h"
#include "loneford12_map.h"
#include "roadbeforecrossroads1_map.h"
#include "fields8_map.h"
#include "roadtocarntower1_map.h"
#include "houseatcrossroads2_map.h"
#include "houseatcrossroads1_map.h"
#include "crackshot_hideout2_map.h"
#include "fallhaven_ne_map.h"
#include "fallhaven_rigmor_map.h"
#include "fallhaven_church_map.h"
#include "fallhaven_tavern_map.h"
#include "fallhaven_prison_map.h"
#include "fallhaven_derelict_map.h"
#include "fallhaven_arcir_map.h"
#include "fallhaven_athamyr_map.h"
#include "fallhaven_nocmar_map.h"
#include "jan_pitcave3_map.h"
#include "wild10_map.h"
#include "fallhaven_alaun_map.h"
#include "fallhaven_lumberjack_map.h"
#include "fallhaven_se_map.h"
#include "white_house_basement_map.h"
#include "wild8_map.h"
#include "mywild18_map.h"
#include "lake_shore_road_0_map.h"
#include "wild6_house_basement_map.h"
#include "thieves_vault_tunnel_map.h"
#include "blackwater_mountain20_map.h"
#include "blackwater_mountain36_map.h"
#include "blackwater_mountain51_map.h"
#include "blackwater_mountain14_map.h"
#include "blackwater_mountain17_map.h"
#include "blackwater_mountain70_map.h"
#include "ratdom_maze_455a_map.h"
#include "ratdom_maze_568_map.h"
#include "ratdom_maze_467_map.h"
#include "ratdom_maze_447_map.h"
#include "ratdom_maze_428_map.h"
#include "ratdom_maze_427_map.h"
#include "hauntedhouse4_map.h"
#include "lodar0_map.h"
#include "loneford14_map.h"
#include "loneford2_map.h"
#include "loneford16_map.h"
#include "loneford17_map.h"
#include "fields2_map.h"
#include "fields6_map.h"
#include "fields7_map.h"
#include "roadbeforecrossroads2_map.h"
#include "roadcave0_map.h"
#include "fields9_map.h"
#include "roadtocarntower2_map.h"
#include "houseatcrossroads3_map.h"
#include "houseatcrossroads5_map.h"
#include "crackshot_hideout3_map.h"
#include "fallhaven_clothes_map.h"
#include "fallhaven_barn_map.h"
#include "fallhaven_potions_map.h"
#include "fallhaven_gravedigger_map.h"
#include "catacombs1_map.h"
#include "roadbeforecrossroads5_map.h"
#include "roadbeforecrossroads4_map.h"
#include "fallhaven_derelict2_map.h"
#include "fallhaven_arcir_basement_map.h"
#include "wild11_map.h"
#include "mywild20_map.h"
#include "wild12_map.h"
#include "fallhaven_farmer_map.h"
#include "fallhaven_storage_map.h"
#include "flagstone0_map.h"
#include "mywild19_map.h"
#include "lake_shore_road_1_map.h"
#include "lake_shore_road_2_map.h"
#include "flagstone_filler_east_1_map.h"
#include "blackwater_mountain19_map.h"
#include "blackwater_mountain37_map.h"
#include "blackwater_mountain52_map.h"
#include "blackwater_mountain10_map.h"
#include "blackwater_mountain40_map.h"
#include "blackwater_mountain18_map.h"
#include "blackwater_mountain71_map.h"
#include "ratdom_maze_455_map.h"

static const GameMap maps[] = {
    {
        "home", HOME_WIDTH, HOME_HEIGHT, HOME_START_X, HOME_START_Y,
        home_walkable, "nitro:/maps/home.rgb555.z", home_places, HOME_PLACE_COUNT,
        home_map_changes, HOME_MAP_CHANGE_COUNT,
    },
    {
        "crossglen", CROSSGLEN_WIDTH, CROSSGLEN_HEIGHT, CROSSGLEN_START_X, CROSSGLEN_START_Y,
        crossglen_walkable, "nitro:/maps/crossglen.rgb555.z", crossglen_places, CROSSGLEN_PLACE_COUNT,
        crossglen_map_changes, CROSSGLEN_MAP_CHANGE_COUNT,
    },
    {
        "crossglen_cave", CROSSGLEN_CAVE_WIDTH, CROSSGLEN_CAVE_HEIGHT, CROSSGLEN_CAVE_START_X, CROSSGLEN_CAVE_START_Y,
        crossglen_cave_walkable, "nitro:/maps/crossglen_cave.rgb555.z", crossglen_cave_places, CROSSGLEN_CAVE_PLACE_COUNT,
        crossglen_cave_map_changes, CROSSGLEN_CAVE_MAP_CHANGE_COUNT,
    },
    {
        "crossglen_hall", CROSSGLEN_HALL_WIDTH, CROSSGLEN_HALL_HEIGHT, CROSSGLEN_HALL_START_X, CROSSGLEN_HALL_START_Y,
        crossglen_hall_walkable, "nitro:/maps/crossglen_hall.rgb555.z", crossglen_hall_places, CROSSGLEN_HALL_PLACE_COUNT,
        crossglen_hall_map_changes, CROSSGLEN_HALL_MAP_CHANGE_COUNT,
    },
    {
        "crossglen_farmhouse", CROSSGLEN_FARMHOUSE_WIDTH, CROSSGLEN_FARMHOUSE_HEIGHT, CROSSGLEN_FARMHOUSE_START_X, CROSSGLEN_FARMHOUSE_START_Y,
        crossglen_farmhouse_walkable, "nitro:/maps/crossglen_farmhouse.rgb555.z", crossglen_farmhouse_places, CROSSGLEN_FARMHOUSE_PLACE_COUNT,
        crossglen_farmhouse_map_changes, CROSSGLEN_FARMHOUSE_MAP_CHANGE_COUNT,
    },
    {
        "crossglen_smith", CROSSGLEN_SMITH_WIDTH, CROSSGLEN_SMITH_HEIGHT, CROSSGLEN_SMITH_START_X, CROSSGLEN_SMITH_START_Y,
        crossglen_smith_walkable, "nitro:/maps/crossglen_smith.rgb555.z", crossglen_smith_places, CROSSGLEN_SMITH_PLACE_COUNT,
        crossglen_smith_map_changes, CROSSGLEN_SMITH_MAP_CHANGE_COUNT,
    },
    {
        "wild1", WILD1_WIDTH, WILD1_HEIGHT, WILD1_START_X, WILD1_START_Y,
        wild1_walkable, "nitro:/maps/wild1.rgb555.z", wild1_places, WILD1_PLACE_COUNT,
        wild1_map_changes, WILD1_MAP_CHANGE_COUNT,
    },
    {
        "wild2", WILD2_WIDTH, WILD2_HEIGHT, WILD2_START_X, WILD2_START_Y,
        wild2_walkable, "nitro:/maps/wild2.rgb555.z", wild2_places, WILD2_PLACE_COUNT,
        wild2_map_changes, WILD2_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_bwm1", RATDOM_BWM1_WIDTH, RATDOM_BWM1_HEIGHT, RATDOM_BWM1_START_X, RATDOM_BWM1_START_Y,
        ratdom_bwm1_walkable, "nitro:/maps/ratdom_bwm1.rgb555.z", ratdom_bwm1_places, RATDOM_BWM1_PLACE_COUNT,
        ratdom_bwm1_map_changes, RATDOM_BWM1_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze1", RATDOM_MAZE1_WIDTH, RATDOM_MAZE1_HEIGHT, RATDOM_MAZE1_START_X, RATDOM_MAZE1_START_Y,
        ratdom_maze1_walkable, "nitro:/maps/ratdom_maze1.rgb555.z", ratdom_maze1_places, RATDOM_MAZE1_PLACE_COUNT,
        ratdom_maze1_map_changes, RATDOM_MAZE1_MAP_CHANGE_COUNT,
    },
    {
        "crossglen_farmhouse_basement", CROSSGLEN_FARMHOUSE_BASEMENT_WIDTH, CROSSGLEN_FARMHOUSE_BASEMENT_HEIGHT, CROSSGLEN_FARMHOUSE_BASEMENT_START_X, CROSSGLEN_FARMHOUSE_BASEMENT_START_Y,
        crossglen_farmhouse_basement_walkable, "nitro:/maps/crossglen_farmhouse_basement.rgb555.z", crossglen_farmhouse_basement_places, CROSSGLEN_FARMHOUSE_BASEMENT_PLACE_COUNT,
        crossglen_farmhouse_basement_map_changes, CROSSGLEN_FARMHOUSE_BASEMENT_MAP_CHANGE_COUNT,
    },
    {
        "gapfiller3", GAPFILLER3_WIDTH, GAPFILLER3_HEIGHT, GAPFILLER3_START_X, GAPFILLER3_START_Y,
        gapfiller3_walkable, "nitro:/maps/gapfiller3.rgb555.z", gapfiller3_places, GAPFILLER3_PLACE_COUNT,
        gapfiller3_map_changes, GAPFILLER3_MAP_CHANGE_COUNT,
    },
    {
        "wild4", WILD4_WIDTH, WILD4_HEIGHT, WILD4_START_X, WILD4_START_Y,
        wild4_walkable, "nitro:/maps/wild4.rgb555.z", wild4_places, WILD4_PLACE_COUNT,
        wild4_map_changes, WILD4_MAP_CHANGE_COUNT,
    },
    {
        "wild0", WILD0_WIDTH, WILD0_HEIGHT, WILD0_START_X, WILD0_START_Y,
        wild0_walkable, "nitro:/maps/wild0.rgb555.z", wild0_places, WILD0_PLACE_COUNT,
        wild0_map_changes, WILD0_MAP_CHANGE_COUNT,
    },
    {
        "wild3", WILD3_WIDTH, WILD3_HEIGHT, WILD3_START_X, WILD3_START_Y,
        wild3_walkable, "nitro:/maps/wild3.rgb555.z", wild3_places, WILD3_PLACE_COUNT,
        wild3_map_changes, WILD3_MAP_CHANGE_COUNT,
    },
    {
        "snakecave1", SNAKECAVE1_WIDTH, SNAKECAVE1_HEIGHT, SNAKECAVE1_START_X, SNAKECAVE1_START_Y,
        snakecave1_walkable, "nitro:/maps/snakecave1.rgb555.z", snakecave1_places, SNAKECAVE1_PLACE_COUNT,
        snakecave1_map_changes, SNAKECAVE1_MAP_CHANGE_COUNT,
    },
    {
        "wild5", WILD5_WIDTH, WILD5_HEIGHT, WILD5_START_X, WILD5_START_Y,
        wild5_walkable, "nitro:/maps/wild5.rgb555.z", wild5_places, WILD5_PLACE_COUNT,
        wild5_map_changes, WILD5_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill6", BWMFILL6_WIDTH, BWMFILL6_HEIGHT, BWMFILL6_START_X, BWMFILL6_START_Y,
        bwmfill6_walkable, "nitro:/maps/bwmfill6.rgb555.z", bwmfill6_places, BWMFILL6_PLACE_COUNT,
        bwmfill6_map_changes, BWMFILL6_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill7", BWMFILL7_WIDTH, BWMFILL7_HEIGHT, BWMFILL7_START_X, BWMFILL7_START_Y,
        bwmfill7_walkable, "nitro:/maps/bwmfill7.rgb555.z", bwmfill7_places, BWMFILL7_PLACE_COUNT,
        bwmfill7_map_changes, BWMFILL7_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze3", RATDOM_MAZE3_WIDTH, RATDOM_MAZE3_HEIGHT, RATDOM_MAZE3_START_X, RATDOM_MAZE3_START_Y,
        ratdom_maze3_walkable, "nitro:/maps/ratdom_maze3.rgb555.z", ratdom_maze3_places, RATDOM_MAZE3_PLACE_COUNT,
        ratdom_maze3_map_changes, RATDOM_MAZE3_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill3", BWMFILL3_WIDTH, BWMFILL3_HEIGHT, BWMFILL3_START_X, BWMFILL3_START_Y,
        bwmfill3_walkable, "nitro:/maps/bwmfill3.rgb555.z", bwmfill3_places, BWMFILL3_PLACE_COUNT,
        bwmfill3_map_changes, BWMFILL3_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill2", BWMFILL2_WIDTH, BWMFILL2_HEIGHT, BWMFILL2_START_X, BWMFILL2_START_Y,
        bwmfill2_walkable, "nitro:/maps/bwmfill2.rgb555.z", bwmfill2_places, BWMFILL2_PLACE_COUNT,
        bwmfill2_map_changes, BWMFILL2_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze2", RATDOM_MAZE2_WIDTH, RATDOM_MAZE2_HEIGHT, RATDOM_MAZE2_START_X, RATDOM_MAZE2_START_Y,
        ratdom_maze2_walkable, "nitro:/maps/ratdom_maze2.rgb555.z", ratdom_maze2_places, RATDOM_MAZE2_PLACE_COUNT,
        ratdom_maze2_map_changes, RATDOM_MAZE2_MAP_CHANGE_COUNT,
    },
    {
        "hauntedhouse1", HAUNTEDHOUSE1_WIDTH, HAUNTEDHOUSE1_HEIGHT, HAUNTEDHOUSE1_START_X, HAUNTEDHOUSE1_START_Y,
        hauntedhouse1_walkable, "nitro:/maps/hauntedhouse1.rgb555.z", hauntedhouse1_places, HAUNTEDHOUSE1_PLACE_COUNT,
        hauntedhouse1_map_changes, HAUNTEDHOUSE1_MAP_CHANGE_COUNT,
    },
    {
        "crossroads", CROSSROADS_WIDTH, CROSSROADS_HEIGHT, CROSSROADS_START_X, CROSSROADS_START_Y,
        crossroads_walkable, "nitro:/maps/crossroads.rgb555.z", crossroads_places, CROSSROADS_PLACE_COUNT,
        crossroads_map_changes, CROSSROADS_MAP_CHANGE_COUNT,
    },
    {
        "woodcave1", WOODCAVE1_WIDTH, WOODCAVE1_HEIGHT, WOODCAVE1_START_X, WOODCAVE1_START_Y,
        woodcave1_walkable, "nitro:/maps/woodcave1.rgb555.z", woodcave1_places, WOODCAVE1_PLACE_COUNT,
        woodcave1_map_changes, WOODCAVE1_MAP_CHANGE_COUNT,
    },
    {
        "woodcave0", WOODCAVE0_WIDTH, WOODCAVE0_HEIGHT, WOODCAVE0_START_X, WOODCAVE0_START_Y,
        woodcave0_walkable, "nitro:/maps/woodcave0.rgb555.z", woodcave0_places, WOODCAVE0_PLACE_COUNT,
        woodcave0_map_changes, WOODCAVE0_MAP_CHANGE_COUNT,
    },
    {
        "gapfiller4", GAPFILLER4_WIDTH, GAPFILLER4_HEIGHT, GAPFILLER4_START_X, GAPFILLER4_START_Y,
        gapfiller4_walkable, "nitro:/maps/gapfiller4.rgb555.z", gapfiller4_places, GAPFILLER4_PLACE_COUNT,
        gapfiller4_map_changes, GAPFILLER4_MAP_CHANGE_COUNT,
    },
    {
        "jan_pitcave1", JAN_PITCAVE1_WIDTH, JAN_PITCAVE1_HEIGHT, JAN_PITCAVE1_START_X, JAN_PITCAVE1_START_Y,
        jan_pitcave1_walkable, "nitro:/maps/jan_pitcave1.rgb555.z", jan_pitcave1_places, JAN_PITCAVE1_PLACE_COUNT,
        jan_pitcave1_map_changes, JAN_PITCAVE1_MAP_CHANGE_COUNT,
    },
    {
        "gapfiller2", GAPFILLER2_WIDTH, GAPFILLER2_HEIGHT, GAPFILLER2_START_X, GAPFILLER2_START_Y,
        gapfiller2_walkable, "nitro:/maps/gapfiller2.rgb555.z", gapfiller2_places, GAPFILLER2_PLACE_COUNT,
        gapfiller2_map_changes, GAPFILLER2_MAP_CHANGE_COUNT,
    },
    {
        "snakecave2", SNAKECAVE2_WIDTH, SNAKECAVE2_HEIGHT, SNAKECAVE2_START_X, SNAKECAVE2_START_Y,
        snakecave2_walkable, "nitro:/maps/snakecave2.rgb555.z", snakecave2_places, SNAKECAVE2_PLACE_COUNT,
        snakecave2_map_changes, SNAKECAVE2_MAP_CHANGE_COUNT,
    },
    {
        "wild6", WILD6_WIDTH, WILD6_HEIGHT, WILD6_START_X, WILD6_START_Y,
        wild6_walkable, "nitro:/maps/wild6.rgb555.z", wild6_places, WILD6_PLACE_COUNT,
        wild6_map_changes, WILD6_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill5", BWMFILL5_WIDTH, BWMFILL5_HEIGHT, BWMFILL5_START_X, BWMFILL5_START_Y,
        bwmfill5_walkable, "nitro:/maps/bwmfill5.rgb555.z", bwmfill5_places, BWMFILL5_PLACE_COUNT,
        bwmfill5_map_changes, BWMFILL5_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain30", BLACKWATER_MOUNTAIN30_WIDTH, BLACKWATER_MOUNTAIN30_HEIGHT, BLACKWATER_MOUNTAIN30_START_X, BLACKWATER_MOUNTAIN30_START_Y,
        blackwater_mountain30_walkable, "nitro:/maps/blackwater_mountain30.rgb555.z", blackwater_mountain30_places, BLACKWATER_MOUNTAIN30_PLACE_COUNT,
        blackwater_mountain30_map_changes, BLACKWATER_MOUNTAIN30_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain16", BLACKWATER_MOUNTAIN16_WIDTH, BLACKWATER_MOUNTAIN16_HEIGHT, BLACKWATER_MOUNTAIN16_START_X, BLACKWATER_MOUNTAIN16_START_Y,
        blackwater_mountain16_walkable, "nitro:/maps/blackwater_mountain16.rgb555.z", blackwater_mountain16_places, BLACKWATER_MOUNTAIN16_PLACE_COUNT,
        blackwater_mountain16_map_changes, BLACKWATER_MOUNTAIN16_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain56", BLACKWATER_MOUNTAIN56_WIDTH, BLACKWATER_MOUNTAIN56_HEIGHT, BLACKWATER_MOUNTAIN56_START_X, BLACKWATER_MOUNTAIN56_START_Y,
        blackwater_mountain56_walkable, "nitro:/maps/blackwater_mountain56.rgb555.z", blackwater_mountain56_places, BLACKWATER_MOUNTAIN56_PLACE_COUNT,
        blackwater_mountain56_map_changes, BLACKWATER_MOUNTAIN56_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill4", BWMFILL4_WIDTH, BWMFILL4_HEIGHT, BWMFILL4_START_X, BWMFILL4_START_Y,
        bwmfill4_walkable, "nitro:/maps/bwmfill4.rgb555.z", bwmfill4_places, BWMFILL4_PLACE_COUNT,
        bwmfill4_map_changes, BWMFILL4_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill_tunlon", BWMFILL_TUNLON_WIDTH, BWMFILL_TUNLON_HEIGHT, BWMFILL_TUNLON_START_X, BWMFILL_TUNLON_START_Y,
        bwmfill_tunlon_walkable, "nitro:/maps/bwmfill_tunlon.rgb555.z", bwmfill_tunlon_places, BWMFILL_TUNLON_PLACE_COUNT,
        bwmfill_tunlon_map_changes, BWMFILL_TUNLON_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain54", BLACKWATER_MOUNTAIN54_WIDTH, BLACKWATER_MOUNTAIN54_HEIGHT, BLACKWATER_MOUNTAIN54_START_X, BLACKWATER_MOUNTAIN54_START_Y,
        blackwater_mountain54_walkable, "nitro:/maps/blackwater_mountain54.rgb555.z", blackwater_mountain54_places, BLACKWATER_MOUNTAIN54_PLACE_COUNT,
        blackwater_mountain54_map_changes, BLACKWATER_MOUNTAIN54_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill1", BWMFILL1_WIDTH, BWMFILL1_HEIGHT, BWMFILL1_START_X, BWMFILL1_START_Y,
        bwmfill1_walkable, "nitro:/maps/bwmfill1.rgb555.z", bwmfill1_places, BWMFILL1_PLACE_COUNT,
        bwmfill1_map_changes, BWMFILL1_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_448", RATDOM_MAZE_448_WIDTH, RATDOM_MAZE_448_HEIGHT, RATDOM_MAZE_448_START_X, RATDOM_MAZE_448_START_Y,
        ratdom_maze_448_walkable, "nitro:/maps/ratdom_maze_448.rgb555.z", ratdom_maze_448_places, RATDOM_MAZE_448_PLACE_COUNT,
        ratdom_maze_448_map_changes, RATDOM_MAZE_448_MAP_CHANGE_COUNT,
    },
    {
        "hauntedhouse2", HAUNTEDHOUSE2_WIDTH, HAUNTEDHOUSE2_HEIGHT, HAUNTEDHOUSE2_START_X, HAUNTEDHOUSE2_START_Y,
        hauntedhouse2_walkable, "nitro:/maps/hauntedhouse2.rgb555.z", hauntedhouse2_places, HAUNTEDHOUSE2_PLACE_COUNT,
        hauntedhouse2_map_changes, HAUNTEDHOUSE2_MAP_CHANGE_COUNT,
    },
    {
        "loneford1", LONEFORD1_WIDTH, LONEFORD1_HEIGHT, LONEFORD1_START_X, LONEFORD1_START_Y,
        loneford1_walkable, "nitro:/maps/loneford1.rgb555.z", loneford1_places, LONEFORD1_PLACE_COUNT,
        loneford1_map_changes, LONEFORD1_MAP_CHANGE_COUNT,
    },
    {
        "roadbeforecrossroads", ROADBEFORECROSSROADS_WIDTH, ROADBEFORECROSSROADS_HEIGHT, ROADBEFORECROSSROADS_START_X, ROADBEFORECROSSROADS_START_Y,
        roadbeforecrossroads_walkable, "nitro:/maps/roadbeforecrossroads.rgb555.z", roadbeforecrossroads_places, ROADBEFORECROSSROADS_PLACE_COUNT,
        roadbeforecrossroads_map_changes, ROADBEFORECROSSROADS_MAP_CHANGE_COUNT,
    },
    {
        "fields0", FIELDS0_WIDTH, FIELDS0_HEIGHT, FIELDS0_START_X, FIELDS0_START_Y,
        fields0_walkable, "nitro:/maps/fields0.rgb555.z", fields0_places, FIELDS0_PLACE_COUNT,
        fields0_map_changes, FIELDS0_MAP_CHANGE_COUNT,
    },
    {
        "roadtocarntower0", ROADTOCARNTOWER0_WIDTH, ROADTOCARNTOWER0_HEIGHT, ROADTOCARNTOWER0_START_X, ROADTOCARNTOWER0_START_Y,
        roadtocarntower0_walkable, "nitro:/maps/roadtocarntower0.rgb555.z", roadtocarntower0_places, ROADTOCARNTOWER0_PLACE_COUNT,
        roadtocarntower0_map_changes, ROADTOCARNTOWER0_MAP_CHANGE_COUNT,
    },
    {
        "houseatcrossroads0", HOUSEATCROSSROADS0_WIDTH, HOUSEATCROSSROADS0_HEIGHT, HOUSEATCROSSROADS0_START_X, HOUSEATCROSSROADS0_START_Y,
        houseatcrossroads0_walkable, "nitro:/maps/houseatcrossroads0.rgb555.z", houseatcrossroads0_places, HOUSEATCROSSROADS0_PLACE_COUNT,
        houseatcrossroads0_map_changes, HOUSEATCROSSROADS0_MAP_CHANGE_COUNT,
    },
    {
        "crackshot_hideout1", CRACKSHOT_HIDEOUT1_WIDTH, CRACKSHOT_HIDEOUT1_HEIGHT, CRACKSHOT_HIDEOUT1_START_X, CRACKSHOT_HIDEOUT1_START_Y,
        crackshot_hideout1_walkable, "nitro:/maps/crackshot_hideout1.rgb555.z", crackshot_hideout1_places, CRACKSHOT_HIDEOUT1_PLACE_COUNT,
        crackshot_hideout1_map_changes, CRACKSHOT_HIDEOUT1_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_nw", FALLHAVEN_NW_WIDTH, FALLHAVEN_NW_HEIGHT, FALLHAVEN_NW_START_X, FALLHAVEN_NW_START_Y,
        fallhaven_nw_walkable, "nitro:/maps/fallhaven_nw.rgb555.z", fallhaven_nw_places, FALLHAVEN_NW_PLACE_COUNT,
        fallhaven_nw_map_changes, FALLHAVEN_NW_MAP_CHANGE_COUNT,
    },
    {
        "jan_pitcave2", JAN_PITCAVE2_WIDTH, JAN_PITCAVE2_HEIGHT, JAN_PITCAVE2_START_X, JAN_PITCAVE2_START_Y,
        jan_pitcave2_walkable, "nitro:/maps/jan_pitcave2.rgb555.z", jan_pitcave2_places, JAN_PITCAVE2_PLACE_COUNT,
        jan_pitcave2_map_changes, JAN_PITCAVE2_MAP_CHANGE_COUNT,
    },
    {
        "wild9", WILD9_WIDTH, WILD9_HEIGHT, WILD9_START_X, WILD9_START_Y,
        wild9_walkable, "nitro:/maps/wild9.rgb555.z", wild9_places, WILD9_PLACE_COUNT,
        wild9_map_changes, WILD9_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_sw", FALLHAVEN_SW_WIDTH, FALLHAVEN_SW_HEIGHT, FALLHAVEN_SW_START_X, FALLHAVEN_SW_START_Y,
        fallhaven_sw_walkable, "nitro:/maps/fallhaven_sw.rgb555.z", fallhaven_sw_places, FALLHAVEN_SW_PLACE_COUNT,
        fallhaven_sw_map_changes, FALLHAVEN_SW_MAP_CHANGE_COUNT,
    },
    {
        "white_house", WHITE_HOUSE_WIDTH, WHITE_HOUSE_HEIGHT, WHITE_HOUSE_START_X, WHITE_HOUSE_START_Y,
        white_house_walkable, "nitro:/maps/white_house.rgb555.z", white_house_places, WHITE_HOUSE_PLACE_COUNT,
        white_house_map_changes, WHITE_HOUSE_MAP_CHANGE_COUNT,
    },
    {
        "snakecave3", SNAKECAVE3_WIDTH, SNAKECAVE3_HEIGHT, SNAKECAVE3_START_X, SNAKECAVE3_START_Y,
        snakecave3_walkable, "nitro:/maps/snakecave3.rgb555.z", snakecave3_places, SNAKECAVE3_PLACE_COUNT,
        snakecave3_map_changes, SNAKECAVE3_MAP_CHANGE_COUNT,
    },
    {
        "wild7", WILD7_WIDTH, WILD7_HEIGHT, WILD7_START_X, WILD7_START_Y,
        wild7_walkable, "nitro:/maps/wild7.rgb555.z", wild7_places, WILD7_PLACE_COUNT,
        wild7_map_changes, WILD7_MAP_CHANGE_COUNT,
    },
    {
        "wild6_house", WILD6_HOUSE_WIDTH, WILD6_HOUSE_HEIGHT, WILD6_HOUSE_START_X, WILD6_HOUSE_START_Y,
        wild6_house_walkable, "nitro:/maps/wild6_house.rgb555.z", wild6_house_places, WILD6_HOUSE_PLACE_COUNT,
        wild6_house_map_changes, WILD6_HOUSE_MAP_CHANGE_COUNT,
    },
    {
        "bwmfill8", BWMFILL8_WIDTH, BWMFILL8_HEIGHT, BWMFILL8_START_X, BWMFILL8_START_Y,
        bwmfill8_walkable, "nitro:/maps/bwmfill8.rgb555.z", bwmfill8_places, BWMFILL8_PLACE_COUNT,
        bwmfill8_map_changes, BWMFILL8_MAP_CHANGE_COUNT,
    },
    {
        "thieves_vault", THIEVES_VAULT_WIDTH, THIEVES_VAULT_HEIGHT, THIEVES_VAULT_START_X, THIEVES_VAULT_START_Y,
        thieves_vault_walkable, "nitro:/maps/thieves_vault.rgb555.z", thieves_vault_places, THIEVES_VAULT_PLACE_COUNT,
        thieves_vault_map_changes, THIEVES_VAULT_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain39", BLACKWATER_MOUNTAIN39_WIDTH, BLACKWATER_MOUNTAIN39_HEIGHT, BLACKWATER_MOUNTAIN39_START_X, BLACKWATER_MOUNTAIN39_START_Y,
        blackwater_mountain39_walkable, "nitro:/maps/blackwater_mountain39.rgb555.z", blackwater_mountain39_places, BLACKWATER_MOUNTAIN39_PLACE_COUNT,
        blackwater_mountain39_map_changes, BLACKWATER_MOUNTAIN39_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain32", BLACKWATER_MOUNTAIN32_WIDTH, BLACKWATER_MOUNTAIN32_HEIGHT, BLACKWATER_MOUNTAIN32_START_X, BLACKWATER_MOUNTAIN32_START_Y,
        blackwater_mountain32_walkable, "nitro:/maps/blackwater_mountain32.rgb555.z", blackwater_mountain32_places, BLACKWATER_MOUNTAIN32_PLACE_COUNT,
        blackwater_mountain32_map_changes, BLACKWATER_MOUNTAIN32_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain31", BLACKWATER_MOUNTAIN31_WIDTH, BLACKWATER_MOUNTAIN31_HEIGHT, BLACKWATER_MOUNTAIN31_START_X, BLACKWATER_MOUNTAIN31_START_Y,
        blackwater_mountain31_walkable, "nitro:/maps/blackwater_mountain31.rgb555.z", blackwater_mountain31_places, BLACKWATER_MOUNTAIN31_PLACE_COUNT,
        blackwater_mountain31_map_changes, BLACKWATER_MOUNTAIN31_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain15", BLACKWATER_MOUNTAIN15_WIDTH, BLACKWATER_MOUNTAIN15_HEIGHT, BLACKWATER_MOUNTAIN15_START_X, BLACKWATER_MOUNTAIN15_START_Y,
        blackwater_mountain15_walkable, "nitro:/maps/blackwater_mountain15.rgb555.z", blackwater_mountain15_places, BLACKWATER_MOUNTAIN15_PLACE_COUNT,
        blackwater_mountain15_map_changes, BLACKWATER_MOUNTAIN15_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain53", BLACKWATER_MOUNTAIN53_WIDTH, BLACKWATER_MOUNTAIN53_HEIGHT, BLACKWATER_MOUNTAIN53_START_X, BLACKWATER_MOUNTAIN53_START_Y,
        blackwater_mountain53_walkable, "nitro:/maps/blackwater_mountain53.rgb555.z", blackwater_mountain53_places, BLACKWATER_MOUNTAIN53_PLACE_COUNT,
        blackwater_mountain53_map_changes, BLACKWATER_MOUNTAIN53_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain55", BLACKWATER_MOUNTAIN55_WIDTH, BLACKWATER_MOUNTAIN55_HEIGHT, BLACKWATER_MOUNTAIN55_START_X, BLACKWATER_MOUNTAIN55_START_Y,
        blackwater_mountain55_walkable, "nitro:/maps/blackwater_mountain55.rgb555.z", blackwater_mountain55_places, BLACKWATER_MOUNTAIN55_PLACE_COUNT,
        blackwater_mountain55_map_changes, BLACKWATER_MOUNTAIN55_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_458", RATDOM_MAZE_458_WIDTH, RATDOM_MAZE_458_HEIGHT, RATDOM_MAZE_458_START_X, RATDOM_MAZE_458_START_Y,
        ratdom_maze_458_walkable, "nitro:/maps/ratdom_maze_458.rgb555.z", ratdom_maze_458_places, RATDOM_MAZE_458_PLACE_COUNT,
        ratdom_maze_458_map_changes, RATDOM_MAZE_458_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_438", RATDOM_MAZE_438_WIDTH, RATDOM_MAZE_438_HEIGHT, RATDOM_MAZE_438_START_X, RATDOM_MAZE_438_START_Y,
        ratdom_maze_438_walkable, "nitro:/maps/ratdom_maze_438.rgb555.z", ratdom_maze_438_places, RATDOM_MAZE_438_PLACE_COUNT,
        ratdom_maze_438_map_changes, RATDOM_MAZE_438_MAP_CHANGE_COUNT,
    },
    {
        "hauntedhouse3", HAUNTEDHOUSE3_WIDTH, HAUNTEDHOUSE3_HEIGHT, HAUNTEDHOUSE3_START_X, HAUNTEDHOUSE3_START_Y,
        hauntedhouse3_walkable, "nitro:/maps/hauntedhouse3.rgb555.z", hauntedhouse3_places, HAUNTEDHOUSE3_PLACE_COUNT,
        hauntedhouse3_map_changes, HAUNTEDHOUSE3_MAP_CHANGE_COUNT,
    },
    {
        "loneford13", LONEFORD13_WIDTH, LONEFORD13_HEIGHT, LONEFORD13_START_X, LONEFORD13_START_Y,
        loneford13_walkable, "nitro:/maps/loneford13.rgb555.z", loneford13_places, LONEFORD13_PLACE_COUNT,
        loneford13_map_changes, LONEFORD13_MAP_CHANGE_COUNT,
    },
    {
        "fields1", FIELDS1_WIDTH, FIELDS1_HEIGHT, FIELDS1_START_X, FIELDS1_START_Y,
        fields1_walkable, "nitro:/maps/fields1.rgb555.z", fields1_places, FIELDS1_PLACE_COUNT,
        fields1_map_changes, FIELDS1_MAP_CHANGE_COUNT,
    },
    {
        "fields4", FIELDS4_WIDTH, FIELDS4_HEIGHT, FIELDS4_START_X, FIELDS4_START_Y,
        fields4_walkable, "nitro:/maps/fields4.rgb555.z", fields4_places, FIELDS4_PLACE_COUNT,
        fields4_map_changes, FIELDS4_MAP_CHANGE_COUNT,
    },
    {
        "loneford12", LONEFORD12_WIDTH, LONEFORD12_HEIGHT, LONEFORD12_START_X, LONEFORD12_START_Y,
        loneford12_walkable, "nitro:/maps/loneford12.rgb555.z", loneford12_places, LONEFORD12_PLACE_COUNT,
        loneford12_map_changes, LONEFORD12_MAP_CHANGE_COUNT,
    },
    {
        "roadbeforecrossroads1", ROADBEFORECROSSROADS1_WIDTH, ROADBEFORECROSSROADS1_HEIGHT, ROADBEFORECROSSROADS1_START_X, ROADBEFORECROSSROADS1_START_Y,
        roadbeforecrossroads1_walkable, "nitro:/maps/roadbeforecrossroads1.rgb555.z", roadbeforecrossroads1_places, ROADBEFORECROSSROADS1_PLACE_COUNT,
        roadbeforecrossroads1_map_changes, ROADBEFORECROSSROADS1_MAP_CHANGE_COUNT,
    },
    {
        "fields8", FIELDS8_WIDTH, FIELDS8_HEIGHT, FIELDS8_START_X, FIELDS8_START_Y,
        fields8_walkable, "nitro:/maps/fields8.rgb555.z", fields8_places, FIELDS8_PLACE_COUNT,
        fields8_map_changes, FIELDS8_MAP_CHANGE_COUNT,
    },
    {
        "roadtocarntower1", ROADTOCARNTOWER1_WIDTH, ROADTOCARNTOWER1_HEIGHT, ROADTOCARNTOWER1_START_X, ROADTOCARNTOWER1_START_Y,
        roadtocarntower1_walkable, "nitro:/maps/roadtocarntower1.rgb555.z", roadtocarntower1_places, ROADTOCARNTOWER1_PLACE_COUNT,
        roadtocarntower1_map_changes, ROADTOCARNTOWER1_MAP_CHANGE_COUNT,
    },
    {
        "houseatcrossroads2", HOUSEATCROSSROADS2_WIDTH, HOUSEATCROSSROADS2_HEIGHT, HOUSEATCROSSROADS2_START_X, HOUSEATCROSSROADS2_START_Y,
        houseatcrossroads2_walkable, "nitro:/maps/houseatcrossroads2.rgb555.z", houseatcrossroads2_places, HOUSEATCROSSROADS2_PLACE_COUNT,
        houseatcrossroads2_map_changes, HOUSEATCROSSROADS2_MAP_CHANGE_COUNT,
    },
    {
        "houseatcrossroads1", HOUSEATCROSSROADS1_WIDTH, HOUSEATCROSSROADS1_HEIGHT, HOUSEATCROSSROADS1_START_X, HOUSEATCROSSROADS1_START_Y,
        houseatcrossroads1_walkable, "nitro:/maps/houseatcrossroads1.rgb555.z", houseatcrossroads1_places, HOUSEATCROSSROADS1_PLACE_COUNT,
        houseatcrossroads1_map_changes, HOUSEATCROSSROADS1_MAP_CHANGE_COUNT,
    },
    {
        "crackshot_hideout2", CRACKSHOT_HIDEOUT2_WIDTH, CRACKSHOT_HIDEOUT2_HEIGHT, CRACKSHOT_HIDEOUT2_START_X, CRACKSHOT_HIDEOUT2_START_Y,
        crackshot_hideout2_walkable, "nitro:/maps/crackshot_hideout2.rgb555.z", crackshot_hideout2_places, CRACKSHOT_HIDEOUT2_PLACE_COUNT,
        crackshot_hideout2_map_changes, CRACKSHOT_HIDEOUT2_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_ne", FALLHAVEN_NE_WIDTH, FALLHAVEN_NE_HEIGHT, FALLHAVEN_NE_START_X, FALLHAVEN_NE_START_Y,
        fallhaven_ne_walkable, "nitro:/maps/fallhaven_ne.rgb555.z", fallhaven_ne_places, FALLHAVEN_NE_PLACE_COUNT,
        fallhaven_ne_map_changes, FALLHAVEN_NE_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_rigmor", FALLHAVEN_RIGMOR_WIDTH, FALLHAVEN_RIGMOR_HEIGHT, FALLHAVEN_RIGMOR_START_X, FALLHAVEN_RIGMOR_START_Y,
        fallhaven_rigmor_walkable, "nitro:/maps/fallhaven_rigmor.rgb555.z", fallhaven_rigmor_places, FALLHAVEN_RIGMOR_PLACE_COUNT,
        fallhaven_rigmor_map_changes, FALLHAVEN_RIGMOR_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_church", FALLHAVEN_CHURCH_WIDTH, FALLHAVEN_CHURCH_HEIGHT, FALLHAVEN_CHURCH_START_X, FALLHAVEN_CHURCH_START_Y,
        fallhaven_church_walkable, "nitro:/maps/fallhaven_church.rgb555.z", fallhaven_church_places, FALLHAVEN_CHURCH_PLACE_COUNT,
        fallhaven_church_map_changes, FALLHAVEN_CHURCH_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_tavern", FALLHAVEN_TAVERN_WIDTH, FALLHAVEN_TAVERN_HEIGHT, FALLHAVEN_TAVERN_START_X, FALLHAVEN_TAVERN_START_Y,
        fallhaven_tavern_walkable, "nitro:/maps/fallhaven_tavern.rgb555.z", fallhaven_tavern_places, FALLHAVEN_TAVERN_PLACE_COUNT,
        fallhaven_tavern_map_changes, FALLHAVEN_TAVERN_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_prison", FALLHAVEN_PRISON_WIDTH, FALLHAVEN_PRISON_HEIGHT, FALLHAVEN_PRISON_START_X, FALLHAVEN_PRISON_START_Y,
        fallhaven_prison_walkable, "nitro:/maps/fallhaven_prison.rgb555.z", fallhaven_prison_places, FALLHAVEN_PRISON_PLACE_COUNT,
        fallhaven_prison_map_changes, FALLHAVEN_PRISON_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_derelict", FALLHAVEN_DERELICT_WIDTH, FALLHAVEN_DERELICT_HEIGHT, FALLHAVEN_DERELICT_START_X, FALLHAVEN_DERELICT_START_Y,
        fallhaven_derelict_walkable, "nitro:/maps/fallhaven_derelict.rgb555.z", fallhaven_derelict_places, FALLHAVEN_DERELICT_PLACE_COUNT,
        fallhaven_derelict_map_changes, FALLHAVEN_DERELICT_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_arcir", FALLHAVEN_ARCIR_WIDTH, FALLHAVEN_ARCIR_HEIGHT, FALLHAVEN_ARCIR_START_X, FALLHAVEN_ARCIR_START_Y,
        fallhaven_arcir_walkable, "nitro:/maps/fallhaven_arcir.rgb555.z", fallhaven_arcir_places, FALLHAVEN_ARCIR_PLACE_COUNT,
        fallhaven_arcir_map_changes, FALLHAVEN_ARCIR_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_athamyr", FALLHAVEN_ATHAMYR_WIDTH, FALLHAVEN_ATHAMYR_HEIGHT, FALLHAVEN_ATHAMYR_START_X, FALLHAVEN_ATHAMYR_START_Y,
        fallhaven_athamyr_walkable, "nitro:/maps/fallhaven_athamyr.rgb555.z", fallhaven_athamyr_places, FALLHAVEN_ATHAMYR_PLACE_COUNT,
        fallhaven_athamyr_map_changes, FALLHAVEN_ATHAMYR_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_nocmar", FALLHAVEN_NOCMAR_WIDTH, FALLHAVEN_NOCMAR_HEIGHT, FALLHAVEN_NOCMAR_START_X, FALLHAVEN_NOCMAR_START_Y,
        fallhaven_nocmar_walkable, "nitro:/maps/fallhaven_nocmar.rgb555.z", fallhaven_nocmar_places, FALLHAVEN_NOCMAR_PLACE_COUNT,
        fallhaven_nocmar_map_changes, FALLHAVEN_NOCMAR_MAP_CHANGE_COUNT,
    },
    {
        "jan_pitcave3", JAN_PITCAVE3_WIDTH, JAN_PITCAVE3_HEIGHT, JAN_PITCAVE3_START_X, JAN_PITCAVE3_START_Y,
        jan_pitcave3_walkable, "nitro:/maps/jan_pitcave3.rgb555.z", jan_pitcave3_places, JAN_PITCAVE3_PLACE_COUNT,
        jan_pitcave3_map_changes, JAN_PITCAVE3_MAP_CHANGE_COUNT,
    },
    {
        "wild10", WILD10_WIDTH, WILD10_HEIGHT, WILD10_START_X, WILD10_START_Y,
        wild10_walkable, "nitro:/maps/wild10.rgb555.z", wild10_places, WILD10_PLACE_COUNT,
        wild10_map_changes, WILD10_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_alaun", FALLHAVEN_ALAUN_WIDTH, FALLHAVEN_ALAUN_HEIGHT, FALLHAVEN_ALAUN_START_X, FALLHAVEN_ALAUN_START_Y,
        fallhaven_alaun_walkable, "nitro:/maps/fallhaven_alaun.rgb555.z", fallhaven_alaun_places, FALLHAVEN_ALAUN_PLACE_COUNT,
        fallhaven_alaun_map_changes, FALLHAVEN_ALAUN_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_lumberjack", FALLHAVEN_LUMBERJACK_WIDTH, FALLHAVEN_LUMBERJACK_HEIGHT, FALLHAVEN_LUMBERJACK_START_X, FALLHAVEN_LUMBERJACK_START_Y,
        fallhaven_lumberjack_walkable, "nitro:/maps/fallhaven_lumberjack.rgb555.z", fallhaven_lumberjack_places, FALLHAVEN_LUMBERJACK_PLACE_COUNT,
        fallhaven_lumberjack_map_changes, FALLHAVEN_LUMBERJACK_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_se", FALLHAVEN_SE_WIDTH, FALLHAVEN_SE_HEIGHT, FALLHAVEN_SE_START_X, FALLHAVEN_SE_START_Y,
        fallhaven_se_walkable, "nitro:/maps/fallhaven_se.rgb555.z", fallhaven_se_places, FALLHAVEN_SE_PLACE_COUNT,
        fallhaven_se_map_changes, FALLHAVEN_SE_MAP_CHANGE_COUNT,
    },
    {
        "white_house_basement", WHITE_HOUSE_BASEMENT_WIDTH, WHITE_HOUSE_BASEMENT_HEIGHT, WHITE_HOUSE_BASEMENT_START_X, WHITE_HOUSE_BASEMENT_START_Y,
        white_house_basement_walkable, "nitro:/maps/white_house_basement.rgb555.z", white_house_basement_places, WHITE_HOUSE_BASEMENT_PLACE_COUNT,
        white_house_basement_map_changes, WHITE_HOUSE_BASEMENT_MAP_CHANGE_COUNT,
    },
    {
        "wild8", WILD8_WIDTH, WILD8_HEIGHT, WILD8_START_X, WILD8_START_Y,
        wild8_walkable, "nitro:/maps/wild8.rgb555.z", wild8_places, WILD8_PLACE_COUNT,
        wild8_map_changes, WILD8_MAP_CHANGE_COUNT,
    },
    {
        "mywild18", MYWILD18_WIDTH, MYWILD18_HEIGHT, MYWILD18_START_X, MYWILD18_START_Y,
        mywild18_walkable, "nitro:/maps/mywild18.rgb555.z", mywild18_places, MYWILD18_PLACE_COUNT,
        mywild18_map_changes, MYWILD18_MAP_CHANGE_COUNT,
    },
    {
        "lake_shore_road_0", LAKE_SHORE_ROAD_0_WIDTH, LAKE_SHORE_ROAD_0_HEIGHT, LAKE_SHORE_ROAD_0_START_X, LAKE_SHORE_ROAD_0_START_Y,
        lake_shore_road_0_walkable, "nitro:/maps/lake_shore_road_0.rgb555.z", lake_shore_road_0_places, LAKE_SHORE_ROAD_0_PLACE_COUNT,
        lake_shore_road_0_map_changes, LAKE_SHORE_ROAD_0_MAP_CHANGE_COUNT,
    },
    {
        "wild6_house_basement", WILD6_HOUSE_BASEMENT_WIDTH, WILD6_HOUSE_BASEMENT_HEIGHT, WILD6_HOUSE_BASEMENT_START_X, WILD6_HOUSE_BASEMENT_START_Y,
        wild6_house_basement_walkable, "nitro:/maps/wild6_house_basement.rgb555.z", wild6_house_basement_places, WILD6_HOUSE_BASEMENT_PLACE_COUNT,
        wild6_house_basement_map_changes, WILD6_HOUSE_BASEMENT_MAP_CHANGE_COUNT,
    },
    {
        "thieves_vault_tunnel", THIEVES_VAULT_TUNNEL_WIDTH, THIEVES_VAULT_TUNNEL_HEIGHT, THIEVES_VAULT_TUNNEL_START_X, THIEVES_VAULT_TUNNEL_START_Y,
        thieves_vault_tunnel_walkable, "nitro:/maps/thieves_vault_tunnel.rgb555.z", thieves_vault_tunnel_places, THIEVES_VAULT_TUNNEL_PLACE_COUNT,
        thieves_vault_tunnel_map_changes, THIEVES_VAULT_TUNNEL_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain20", BLACKWATER_MOUNTAIN20_WIDTH, BLACKWATER_MOUNTAIN20_HEIGHT, BLACKWATER_MOUNTAIN20_START_X, BLACKWATER_MOUNTAIN20_START_Y,
        blackwater_mountain20_walkable, "nitro:/maps/blackwater_mountain20.rgb555.z", blackwater_mountain20_places, BLACKWATER_MOUNTAIN20_PLACE_COUNT,
        blackwater_mountain20_map_changes, BLACKWATER_MOUNTAIN20_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain36", BLACKWATER_MOUNTAIN36_WIDTH, BLACKWATER_MOUNTAIN36_HEIGHT, BLACKWATER_MOUNTAIN36_START_X, BLACKWATER_MOUNTAIN36_START_Y,
        blackwater_mountain36_walkable, "nitro:/maps/blackwater_mountain36.rgb555.z", blackwater_mountain36_places, BLACKWATER_MOUNTAIN36_PLACE_COUNT,
        blackwater_mountain36_map_changes, BLACKWATER_MOUNTAIN36_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain51", BLACKWATER_MOUNTAIN51_WIDTH, BLACKWATER_MOUNTAIN51_HEIGHT, BLACKWATER_MOUNTAIN51_START_X, BLACKWATER_MOUNTAIN51_START_Y,
        blackwater_mountain51_walkable, "nitro:/maps/blackwater_mountain51.rgb555.z", blackwater_mountain51_places, BLACKWATER_MOUNTAIN51_PLACE_COUNT,
        blackwater_mountain51_map_changes, BLACKWATER_MOUNTAIN51_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain14", BLACKWATER_MOUNTAIN14_WIDTH, BLACKWATER_MOUNTAIN14_HEIGHT, BLACKWATER_MOUNTAIN14_START_X, BLACKWATER_MOUNTAIN14_START_Y,
        blackwater_mountain14_walkable, "nitro:/maps/blackwater_mountain14.rgb555.z", blackwater_mountain14_places, BLACKWATER_MOUNTAIN14_PLACE_COUNT,
        blackwater_mountain14_map_changes, BLACKWATER_MOUNTAIN14_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain17", BLACKWATER_MOUNTAIN17_WIDTH, BLACKWATER_MOUNTAIN17_HEIGHT, BLACKWATER_MOUNTAIN17_START_X, BLACKWATER_MOUNTAIN17_START_Y,
        blackwater_mountain17_walkable, "nitro:/maps/blackwater_mountain17.rgb555.z", blackwater_mountain17_places, BLACKWATER_MOUNTAIN17_PLACE_COUNT,
        blackwater_mountain17_map_changes, BLACKWATER_MOUNTAIN17_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain70", BLACKWATER_MOUNTAIN70_WIDTH, BLACKWATER_MOUNTAIN70_HEIGHT, BLACKWATER_MOUNTAIN70_START_X, BLACKWATER_MOUNTAIN70_START_Y,
        blackwater_mountain70_walkable, "nitro:/maps/blackwater_mountain70.rgb555.z", blackwater_mountain70_places, BLACKWATER_MOUNTAIN70_PLACE_COUNT,
        blackwater_mountain70_map_changes, BLACKWATER_MOUNTAIN70_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_455a", RATDOM_MAZE_455A_WIDTH, RATDOM_MAZE_455A_HEIGHT, RATDOM_MAZE_455A_START_X, RATDOM_MAZE_455A_START_Y,
        ratdom_maze_455a_walkable, "nitro:/maps/ratdom_maze_455a.rgb555.z", ratdom_maze_455a_places, RATDOM_MAZE_455A_PLACE_COUNT,
        ratdom_maze_455a_map_changes, RATDOM_MAZE_455A_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_568", RATDOM_MAZE_568_WIDTH, RATDOM_MAZE_568_HEIGHT, RATDOM_MAZE_568_START_X, RATDOM_MAZE_568_START_Y,
        ratdom_maze_568_walkable, "nitro:/maps/ratdom_maze_568.rgb555.z", ratdom_maze_568_places, RATDOM_MAZE_568_PLACE_COUNT,
        ratdom_maze_568_map_changes, RATDOM_MAZE_568_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_467", RATDOM_MAZE_467_WIDTH, RATDOM_MAZE_467_HEIGHT, RATDOM_MAZE_467_START_X, RATDOM_MAZE_467_START_Y,
        ratdom_maze_467_walkable, "nitro:/maps/ratdom_maze_467.rgb555.z", ratdom_maze_467_places, RATDOM_MAZE_467_PLACE_COUNT,
        ratdom_maze_467_map_changes, RATDOM_MAZE_467_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_447", RATDOM_MAZE_447_WIDTH, RATDOM_MAZE_447_HEIGHT, RATDOM_MAZE_447_START_X, RATDOM_MAZE_447_START_Y,
        ratdom_maze_447_walkable, "nitro:/maps/ratdom_maze_447.rgb555.z", ratdom_maze_447_places, RATDOM_MAZE_447_PLACE_COUNT,
        ratdom_maze_447_map_changes, RATDOM_MAZE_447_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_428", RATDOM_MAZE_428_WIDTH, RATDOM_MAZE_428_HEIGHT, RATDOM_MAZE_428_START_X, RATDOM_MAZE_428_START_Y,
        ratdom_maze_428_walkable, "nitro:/maps/ratdom_maze_428.rgb555.z", ratdom_maze_428_places, RATDOM_MAZE_428_PLACE_COUNT,
        ratdom_maze_428_map_changes, RATDOM_MAZE_428_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_427", RATDOM_MAZE_427_WIDTH, RATDOM_MAZE_427_HEIGHT, RATDOM_MAZE_427_START_X, RATDOM_MAZE_427_START_Y,
        ratdom_maze_427_walkable, "nitro:/maps/ratdom_maze_427.rgb555.z", ratdom_maze_427_places, RATDOM_MAZE_427_PLACE_COUNT,
        ratdom_maze_427_map_changes, RATDOM_MAZE_427_MAP_CHANGE_COUNT,
    },
    {
        "hauntedhouse4", HAUNTEDHOUSE4_WIDTH, HAUNTEDHOUSE4_HEIGHT, HAUNTEDHOUSE4_START_X, HAUNTEDHOUSE4_START_Y,
        hauntedhouse4_walkable, "nitro:/maps/hauntedhouse4.rgb555.z", hauntedhouse4_places, HAUNTEDHOUSE4_PLACE_COUNT,
        hauntedhouse4_map_changes, HAUNTEDHOUSE4_MAP_CHANGE_COUNT,
    },
    {
        "lodar0", LODAR0_WIDTH, LODAR0_HEIGHT, LODAR0_START_X, LODAR0_START_Y,
        lodar0_walkable, "nitro:/maps/lodar0.rgb555.z", lodar0_places, LODAR0_PLACE_COUNT,
        lodar0_map_changes, LODAR0_MAP_CHANGE_COUNT,
    },
    {
        "loneford14", LONEFORD14_WIDTH, LONEFORD14_HEIGHT, LONEFORD14_START_X, LONEFORD14_START_Y,
        loneford14_walkable, "nitro:/maps/loneford14.rgb555.z", loneford14_places, LONEFORD14_PLACE_COUNT,
        loneford14_map_changes, LONEFORD14_MAP_CHANGE_COUNT,
    },
    {
        "loneford2", LONEFORD2_WIDTH, LONEFORD2_HEIGHT, LONEFORD2_START_X, LONEFORD2_START_Y,
        loneford2_walkable, "nitro:/maps/loneford2.rgb555.z", loneford2_places, LONEFORD2_PLACE_COUNT,
        loneford2_map_changes, LONEFORD2_MAP_CHANGE_COUNT,
    },
    {
        "loneford16", LONEFORD16_WIDTH, LONEFORD16_HEIGHT, LONEFORD16_START_X, LONEFORD16_START_Y,
        loneford16_walkable, "nitro:/maps/loneford16.rgb555.z", loneford16_places, LONEFORD16_PLACE_COUNT,
        loneford16_map_changes, LONEFORD16_MAP_CHANGE_COUNT,
    },
    {
        "loneford17", LONEFORD17_WIDTH, LONEFORD17_HEIGHT, LONEFORD17_START_X, LONEFORD17_START_Y,
        loneford17_walkable, "nitro:/maps/loneford17.rgb555.z", loneford17_places, LONEFORD17_PLACE_COUNT,
        loneford17_map_changes, LONEFORD17_MAP_CHANGE_COUNT,
    },
    {
        "fields2", FIELDS2_WIDTH, FIELDS2_HEIGHT, FIELDS2_START_X, FIELDS2_START_Y,
        fields2_walkable, "nitro:/maps/fields2.rgb555.z", fields2_places, FIELDS2_PLACE_COUNT,
        fields2_map_changes, FIELDS2_MAP_CHANGE_COUNT,
    },
    {
        "fields6", FIELDS6_WIDTH, FIELDS6_HEIGHT, FIELDS6_START_X, FIELDS6_START_Y,
        fields6_walkable, "nitro:/maps/fields6.rgb555.z", fields6_places, FIELDS6_PLACE_COUNT,
        fields6_map_changes, FIELDS6_MAP_CHANGE_COUNT,
    },
    {
        "fields7", FIELDS7_WIDTH, FIELDS7_HEIGHT, FIELDS7_START_X, FIELDS7_START_Y,
        fields7_walkable, "nitro:/maps/fields7.rgb555.z", fields7_places, FIELDS7_PLACE_COUNT,
        fields7_map_changes, FIELDS7_MAP_CHANGE_COUNT,
    },
    {
        "roadbeforecrossroads2", ROADBEFORECROSSROADS2_WIDTH, ROADBEFORECROSSROADS2_HEIGHT, ROADBEFORECROSSROADS2_START_X, ROADBEFORECROSSROADS2_START_Y,
        roadbeforecrossroads2_walkable, "nitro:/maps/roadbeforecrossroads2.rgb555.z", roadbeforecrossroads2_places, ROADBEFORECROSSROADS2_PLACE_COUNT,
        roadbeforecrossroads2_map_changes, ROADBEFORECROSSROADS2_MAP_CHANGE_COUNT,
    },
    {
        "roadcave0", ROADCAVE0_WIDTH, ROADCAVE0_HEIGHT, ROADCAVE0_START_X, ROADCAVE0_START_Y,
        roadcave0_walkable, "nitro:/maps/roadcave0.rgb555.z", roadcave0_places, ROADCAVE0_PLACE_COUNT,
        roadcave0_map_changes, ROADCAVE0_MAP_CHANGE_COUNT,
    },
    {
        "fields9", FIELDS9_WIDTH, FIELDS9_HEIGHT, FIELDS9_START_X, FIELDS9_START_Y,
        fields9_walkable, "nitro:/maps/fields9.rgb555.z", fields9_places, FIELDS9_PLACE_COUNT,
        fields9_map_changes, FIELDS9_MAP_CHANGE_COUNT,
    },
    {
        "roadtocarntower2", ROADTOCARNTOWER2_WIDTH, ROADTOCARNTOWER2_HEIGHT, ROADTOCARNTOWER2_START_X, ROADTOCARNTOWER2_START_Y,
        roadtocarntower2_walkable, "nitro:/maps/roadtocarntower2.rgb555.z", roadtocarntower2_places, ROADTOCARNTOWER2_PLACE_COUNT,
        roadtocarntower2_map_changes, ROADTOCARNTOWER2_MAP_CHANGE_COUNT,
    },
    {
        "houseatcrossroads3", HOUSEATCROSSROADS3_WIDTH, HOUSEATCROSSROADS3_HEIGHT, HOUSEATCROSSROADS3_START_X, HOUSEATCROSSROADS3_START_Y,
        houseatcrossroads3_walkable, "nitro:/maps/houseatcrossroads3.rgb555.z", houseatcrossroads3_places, HOUSEATCROSSROADS3_PLACE_COUNT,
        houseatcrossroads3_map_changes, HOUSEATCROSSROADS3_MAP_CHANGE_COUNT,
    },
    {
        "houseatcrossroads5", HOUSEATCROSSROADS5_WIDTH, HOUSEATCROSSROADS5_HEIGHT, HOUSEATCROSSROADS5_START_X, HOUSEATCROSSROADS5_START_Y,
        houseatcrossroads5_walkable, "nitro:/maps/houseatcrossroads5.rgb555.z", houseatcrossroads5_places, HOUSEATCROSSROADS5_PLACE_COUNT,
        houseatcrossroads5_map_changes, HOUSEATCROSSROADS5_MAP_CHANGE_COUNT,
    },
    {
        "crackshot_hideout3", CRACKSHOT_HIDEOUT3_WIDTH, CRACKSHOT_HIDEOUT3_HEIGHT, CRACKSHOT_HIDEOUT3_START_X, CRACKSHOT_HIDEOUT3_START_Y,
        crackshot_hideout3_walkable, "nitro:/maps/crackshot_hideout3.rgb555.z", crackshot_hideout3_places, CRACKSHOT_HIDEOUT3_PLACE_COUNT,
        crackshot_hideout3_map_changes, CRACKSHOT_HIDEOUT3_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_clothes", FALLHAVEN_CLOTHES_WIDTH, FALLHAVEN_CLOTHES_HEIGHT, FALLHAVEN_CLOTHES_START_X, FALLHAVEN_CLOTHES_START_Y,
        fallhaven_clothes_walkable, "nitro:/maps/fallhaven_clothes.rgb555.z", fallhaven_clothes_places, FALLHAVEN_CLOTHES_PLACE_COUNT,
        fallhaven_clothes_map_changes, FALLHAVEN_CLOTHES_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_barn", FALLHAVEN_BARN_WIDTH, FALLHAVEN_BARN_HEIGHT, FALLHAVEN_BARN_START_X, FALLHAVEN_BARN_START_Y,
        fallhaven_barn_walkable, "nitro:/maps/fallhaven_barn.rgb555.z", fallhaven_barn_places, FALLHAVEN_BARN_PLACE_COUNT,
        fallhaven_barn_map_changes, FALLHAVEN_BARN_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_potions", FALLHAVEN_POTIONS_WIDTH, FALLHAVEN_POTIONS_HEIGHT, FALLHAVEN_POTIONS_START_X, FALLHAVEN_POTIONS_START_Y,
        fallhaven_potions_walkable, "nitro:/maps/fallhaven_potions.rgb555.z", fallhaven_potions_places, FALLHAVEN_POTIONS_PLACE_COUNT,
        fallhaven_potions_map_changes, FALLHAVEN_POTIONS_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_gravedigger", FALLHAVEN_GRAVEDIGGER_WIDTH, FALLHAVEN_GRAVEDIGGER_HEIGHT, FALLHAVEN_GRAVEDIGGER_START_X, FALLHAVEN_GRAVEDIGGER_START_Y,
        fallhaven_gravedigger_walkable, "nitro:/maps/fallhaven_gravedigger.rgb555.z", fallhaven_gravedigger_places, FALLHAVEN_GRAVEDIGGER_PLACE_COUNT,
        fallhaven_gravedigger_map_changes, FALLHAVEN_GRAVEDIGGER_MAP_CHANGE_COUNT,
    },
    {
        "catacombs1", CATACOMBS1_WIDTH, CATACOMBS1_HEIGHT, CATACOMBS1_START_X, CATACOMBS1_START_Y,
        catacombs1_walkable, "nitro:/maps/catacombs1.rgb555.z", catacombs1_places, CATACOMBS1_PLACE_COUNT,
        catacombs1_map_changes, CATACOMBS1_MAP_CHANGE_COUNT,
    },
    {
        "roadbeforecrossroads5", ROADBEFORECROSSROADS5_WIDTH, ROADBEFORECROSSROADS5_HEIGHT, ROADBEFORECROSSROADS5_START_X, ROADBEFORECROSSROADS5_START_Y,
        roadbeforecrossroads5_walkable, "nitro:/maps/roadbeforecrossroads5.rgb555.z", roadbeforecrossroads5_places, ROADBEFORECROSSROADS5_PLACE_COUNT,
        roadbeforecrossroads5_map_changes, ROADBEFORECROSSROADS5_MAP_CHANGE_COUNT,
    },
    {
        "roadbeforecrossroads4", ROADBEFORECROSSROADS4_WIDTH, ROADBEFORECROSSROADS4_HEIGHT, ROADBEFORECROSSROADS4_START_X, ROADBEFORECROSSROADS4_START_Y,
        roadbeforecrossroads4_walkable, "nitro:/maps/roadbeforecrossroads4.rgb555.z", roadbeforecrossroads4_places, ROADBEFORECROSSROADS4_PLACE_COUNT,
        roadbeforecrossroads4_map_changes, ROADBEFORECROSSROADS4_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_derelict2", FALLHAVEN_DERELICT2_WIDTH, FALLHAVEN_DERELICT2_HEIGHT, FALLHAVEN_DERELICT2_START_X, FALLHAVEN_DERELICT2_START_Y,
        fallhaven_derelict2_walkable, "nitro:/maps/fallhaven_derelict2.rgb555.z", fallhaven_derelict2_places, FALLHAVEN_DERELICT2_PLACE_COUNT,
        fallhaven_derelict2_map_changes, FALLHAVEN_DERELICT2_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_arcir_basement", FALLHAVEN_ARCIR_BASEMENT_WIDTH, FALLHAVEN_ARCIR_BASEMENT_HEIGHT, FALLHAVEN_ARCIR_BASEMENT_START_X, FALLHAVEN_ARCIR_BASEMENT_START_Y,
        fallhaven_arcir_basement_walkable, "nitro:/maps/fallhaven_arcir_basement.rgb555.z", fallhaven_arcir_basement_places, FALLHAVEN_ARCIR_BASEMENT_PLACE_COUNT,
        fallhaven_arcir_basement_map_changes, FALLHAVEN_ARCIR_BASEMENT_MAP_CHANGE_COUNT,
    },
    {
        "wild11", WILD11_WIDTH, WILD11_HEIGHT, WILD11_START_X, WILD11_START_Y,
        wild11_walkable, "nitro:/maps/wild11.rgb555.z", wild11_places, WILD11_PLACE_COUNT,
        wild11_map_changes, WILD11_MAP_CHANGE_COUNT,
    },
    {
        "mywild20", MYWILD20_WIDTH, MYWILD20_HEIGHT, MYWILD20_START_X, MYWILD20_START_Y,
        mywild20_walkable, "nitro:/maps/mywild20.rgb555.z", mywild20_places, MYWILD20_PLACE_COUNT,
        mywild20_map_changes, MYWILD20_MAP_CHANGE_COUNT,
    },
    {
        "wild12", WILD12_WIDTH, WILD12_HEIGHT, WILD12_START_X, WILD12_START_Y,
        wild12_walkable, "nitro:/maps/wild12.rgb555.z", wild12_places, WILD12_PLACE_COUNT,
        wild12_map_changes, WILD12_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_farmer", FALLHAVEN_FARMER_WIDTH, FALLHAVEN_FARMER_HEIGHT, FALLHAVEN_FARMER_START_X, FALLHAVEN_FARMER_START_Y,
        fallhaven_farmer_walkable, "nitro:/maps/fallhaven_farmer.rgb555.z", fallhaven_farmer_places, FALLHAVEN_FARMER_PLACE_COUNT,
        fallhaven_farmer_map_changes, FALLHAVEN_FARMER_MAP_CHANGE_COUNT,
    },
    {
        "fallhaven_storage", FALLHAVEN_STORAGE_WIDTH, FALLHAVEN_STORAGE_HEIGHT, FALLHAVEN_STORAGE_START_X, FALLHAVEN_STORAGE_START_Y,
        fallhaven_storage_walkable, "nitro:/maps/fallhaven_storage.rgb555.z", fallhaven_storage_places, FALLHAVEN_STORAGE_PLACE_COUNT,
        fallhaven_storage_map_changes, FALLHAVEN_STORAGE_MAP_CHANGE_COUNT,
    },
    {
        "flagstone0", FLAGSTONE0_WIDTH, FLAGSTONE0_HEIGHT, FLAGSTONE0_START_X, FLAGSTONE0_START_Y,
        flagstone0_walkable, "nitro:/maps/flagstone0.rgb555.z", flagstone0_places, FLAGSTONE0_PLACE_COUNT,
        flagstone0_map_changes, FLAGSTONE0_MAP_CHANGE_COUNT,
    },
    {
        "mywild19", MYWILD19_WIDTH, MYWILD19_HEIGHT, MYWILD19_START_X, MYWILD19_START_Y,
        mywild19_walkable, "nitro:/maps/mywild19.rgb555.z", mywild19_places, MYWILD19_PLACE_COUNT,
        mywild19_map_changes, MYWILD19_MAP_CHANGE_COUNT,
    },
    {
        "lake_shore_road_1", LAKE_SHORE_ROAD_1_WIDTH, LAKE_SHORE_ROAD_1_HEIGHT, LAKE_SHORE_ROAD_1_START_X, LAKE_SHORE_ROAD_1_START_Y,
        lake_shore_road_1_walkable, "nitro:/maps/lake_shore_road_1.rgb555.z", lake_shore_road_1_places, LAKE_SHORE_ROAD_1_PLACE_COUNT,
        lake_shore_road_1_map_changes, LAKE_SHORE_ROAD_1_MAP_CHANGE_COUNT,
    },
    {
        "lake_shore_road_2", LAKE_SHORE_ROAD_2_WIDTH, LAKE_SHORE_ROAD_2_HEIGHT, LAKE_SHORE_ROAD_2_START_X, LAKE_SHORE_ROAD_2_START_Y,
        lake_shore_road_2_walkable, "nitro:/maps/lake_shore_road_2.rgb555.z", lake_shore_road_2_places, LAKE_SHORE_ROAD_2_PLACE_COUNT,
        lake_shore_road_2_map_changes, LAKE_SHORE_ROAD_2_MAP_CHANGE_COUNT,
    },
    {
        "flagstone_filler_east_1", FLAGSTONE_FILLER_EAST_1_WIDTH, FLAGSTONE_FILLER_EAST_1_HEIGHT, FLAGSTONE_FILLER_EAST_1_START_X, FLAGSTONE_FILLER_EAST_1_START_Y,
        flagstone_filler_east_1_walkable, "nitro:/maps/flagstone_filler_east_1.rgb555.z", flagstone_filler_east_1_places, FLAGSTONE_FILLER_EAST_1_PLACE_COUNT,
        flagstone_filler_east_1_map_changes, FLAGSTONE_FILLER_EAST_1_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain19", BLACKWATER_MOUNTAIN19_WIDTH, BLACKWATER_MOUNTAIN19_HEIGHT, BLACKWATER_MOUNTAIN19_START_X, BLACKWATER_MOUNTAIN19_START_Y,
        blackwater_mountain19_walkable, "nitro:/maps/blackwater_mountain19.rgb555.z", blackwater_mountain19_places, BLACKWATER_MOUNTAIN19_PLACE_COUNT,
        blackwater_mountain19_map_changes, BLACKWATER_MOUNTAIN19_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain37", BLACKWATER_MOUNTAIN37_WIDTH, BLACKWATER_MOUNTAIN37_HEIGHT, BLACKWATER_MOUNTAIN37_START_X, BLACKWATER_MOUNTAIN37_START_Y,
        blackwater_mountain37_walkable, "nitro:/maps/blackwater_mountain37.rgb555.z", blackwater_mountain37_places, BLACKWATER_MOUNTAIN37_PLACE_COUNT,
        blackwater_mountain37_map_changes, BLACKWATER_MOUNTAIN37_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain52", BLACKWATER_MOUNTAIN52_WIDTH, BLACKWATER_MOUNTAIN52_HEIGHT, BLACKWATER_MOUNTAIN52_START_X, BLACKWATER_MOUNTAIN52_START_Y,
        blackwater_mountain52_walkable, "nitro:/maps/blackwater_mountain52.rgb555.z", blackwater_mountain52_places, BLACKWATER_MOUNTAIN52_PLACE_COUNT,
        blackwater_mountain52_map_changes, BLACKWATER_MOUNTAIN52_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain10", BLACKWATER_MOUNTAIN10_WIDTH, BLACKWATER_MOUNTAIN10_HEIGHT, BLACKWATER_MOUNTAIN10_START_X, BLACKWATER_MOUNTAIN10_START_Y,
        blackwater_mountain10_walkable, "nitro:/maps/blackwater_mountain10.rgb555.z", blackwater_mountain10_places, BLACKWATER_MOUNTAIN10_PLACE_COUNT,
        blackwater_mountain10_map_changes, BLACKWATER_MOUNTAIN10_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain40", BLACKWATER_MOUNTAIN40_WIDTH, BLACKWATER_MOUNTAIN40_HEIGHT, BLACKWATER_MOUNTAIN40_START_X, BLACKWATER_MOUNTAIN40_START_Y,
        blackwater_mountain40_walkable, "nitro:/maps/blackwater_mountain40.rgb555.z", blackwater_mountain40_places, BLACKWATER_MOUNTAIN40_PLACE_COUNT,
        blackwater_mountain40_map_changes, BLACKWATER_MOUNTAIN40_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain18", BLACKWATER_MOUNTAIN18_WIDTH, BLACKWATER_MOUNTAIN18_HEIGHT, BLACKWATER_MOUNTAIN18_START_X, BLACKWATER_MOUNTAIN18_START_Y,
        blackwater_mountain18_walkable, "nitro:/maps/blackwater_mountain18.rgb555.z", blackwater_mountain18_places, BLACKWATER_MOUNTAIN18_PLACE_COUNT,
        blackwater_mountain18_map_changes, BLACKWATER_MOUNTAIN18_MAP_CHANGE_COUNT,
    },
    {
        "blackwater_mountain71", BLACKWATER_MOUNTAIN71_WIDTH, BLACKWATER_MOUNTAIN71_HEIGHT, BLACKWATER_MOUNTAIN71_START_X, BLACKWATER_MOUNTAIN71_START_Y,
        blackwater_mountain71_walkable, "nitro:/maps/blackwater_mountain71.rgb555.z", blackwater_mountain71_places, BLACKWATER_MOUNTAIN71_PLACE_COUNT,
        blackwater_mountain71_map_changes, BLACKWATER_MOUNTAIN71_MAP_CHANGE_COUNT,
    },
    {
        "ratdom_maze_455", RATDOM_MAZE_455_WIDTH, RATDOM_MAZE_455_HEIGHT, RATDOM_MAZE_455_START_X, RATDOM_MAZE_455_START_Y,
        ratdom_maze_455_walkable, "nitro:/maps/ratdom_maze_455.rgb555.z", ratdom_maze_455_places, RATDOM_MAZE_455_PLACE_COUNT,
        ratdom_maze_455_map_changes, RATDOM_MAZE_455_MAP_CHANGE_COUNT,
    },
};

#endif
