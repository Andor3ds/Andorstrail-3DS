#include "fallhaven_lumberjack_map.h"

const MapPlace fallhaven_lumberjack_places[] = {
    {"entrance", MAP_PLACE_MAPCHANGE, 9, 7, 1, 1, "entrance", "", "", 0, 0, ""}
};
const MapChangeEvent fallhaven_lumberjack_map_changes[] = {
    {9, 7, 1, 1, "fallhaven_sw", "lumberjack"}
};
