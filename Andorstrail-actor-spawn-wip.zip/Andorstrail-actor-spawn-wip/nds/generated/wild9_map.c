#include "wild9_map.h"

const MapPlace wild9_places[] = {
    {"west", MAP_PLACE_MAPCHANGE, 0, 17, 1, 3, "west", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 15, 1, 2, "east", "", "", 0, 0, ""},
    {"north3", MAP_PLACE_MAPCHANGE, 27, 0, 2, 1, "north3", "", "", 0, 0, ""},
    {"west2", MAP_PLACE_MAPCHANGE, 0, 11, 1, 2, "west2", "", "", 0, 0, ""},
    {"west3", MAP_PLACE_MAPCHANGE, 0, 4, 1, 4, "west3", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 11, 1, 2, "east2", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 29, 3, 1, 1, "east3", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 18, 0, 1, 1, "north2", "", "", 0, 0, ""},
    {"north1", MAP_PLACE_MAPCHANGE, 3, 0, 3, 1, "north1", "", "", 0, 0, ""},
    {"fct_bandit1", MAP_PLACE_SCRIPT, 2, 15, 27, 5, "fct_bandit1", "", "", 0, 0, ""},
    {"grownfood01", MAP_PLACE_SCRIPT, 20, 4, 1, 1, "grownfood01", "", "", 0, 0, ""},
    {"grownfood02", MAP_PLACE_SCRIPT, 20, 1, 1, 1, "grownfood02", "", "", 0, 0, ""},
    {"grownfood03", MAP_PLACE_SCRIPT, 24, 3, 1, 1, "grownfood03", "", "", 0, 0, ""},
    {"chk_wild_berry", MAP_PLACE_SCRIPT, 0, 4, 1, 16, "chk_wild_berry", "", "", 0, 0, ""},
    {"bandit1", MAP_PLACE_SPAWN, 2, 16, 26, 3, "bandit1", "", "", 0, 0, ""},
    {"fallhaven_bandit", MAP_PLACE_SPAWN, 13, 9, 1, 1, "fallhaven_bandit", "", "", 0, 0, ""},
    {"forestwasp2", MAP_PLACE_SPAWN, 5, 11, 23, 11, "forestwasp2", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 4, 10, 23, 11, "forestwolf1", "", "", 0, 0, ""},
    {"forestwolf1_1", MAP_PLACE_SPAWN, 13, 2, 11, 7, "forestwolf1_1", "", "", 0, 0, ""},
    {"forestant", MAP_PLACE_SPAWN, 25, 2, 3, 7, "forestant", "", "", 0, 0, ""},
    {"forestwasp2_1", MAP_PLACE_SPAWN, 2, 2, 8, 7, "forestwasp2_1", "", "", 0, 0, ""},
    {"wild_berry", MAP_PLACE_SPAWN, 7, 6, 18, 7, "wild_berry", "", "", 0, 0, ""},
    {"wild_berry2", MAP_PLACE_SPAWN, 3, 20, 23, 2, "wild_berry2", "", "", 0, 0, ""}
};
const MapChangeEvent wild9_map_changes[] = {
    {0, 17, 1, 3, "wild6", "east"},
    {29, 15, 1, 2, "wild10", "west"},
    {27, 0, 2, 1, "fallhaven_sw", "south2"},
    {0, 11, 1, 2, "wild6", "east2"},
    {0, 4, 1, 4, "wild6", "east3"},
    {29, 11, 1, 2, "wild10", "west2"},
    {29, 3, 1, 1, "wild10", "west3"},
    {18, 0, 1, 1, "gapfiller2", "south2"},
    {3, 0, 3, 1, "gapfiller2", "south1"}
};
