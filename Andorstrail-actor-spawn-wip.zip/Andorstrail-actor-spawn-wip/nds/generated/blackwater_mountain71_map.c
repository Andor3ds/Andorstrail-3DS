#include "blackwater_mountain71_map.h"

const MapPlace blackwater_mountain71_places[] = {
    {"up", MAP_PLACE_MAPCHANGE, 2, 0, 1, 1, "up", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 7, 1, 2, "west", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 6, 19, 2, 1, "south", "", "", 0, 0, ""},
    {"bwm_fish", MAP_PLACE_CONTAINER, 4, 15, 1, 1, "bwm_fish", "", "", 0, 0, ""},
    {"bwm73_drop", MAP_PLACE_CONTAINER, 10, 15, 1, 1, "bwm73_drop", "", "", 0, 0, ""},
    {"bwm71_monster1", MAP_PLACE_SPAWN, 3, 9, 4, 7, "bwm71_monster1", "", "", 0, 0, ""},
    {"bwm71_monster2", MAP_PLACE_SPAWN, 1, 4, 4, 4, "bwm71_monster2", "", "", 0, 0, ""},
    {"bwm71_monster3", MAP_PLACE_SPAWN, 7, 12, 4, 5, "bwm71_monster3", "", "", 0, 0, ""},
    {"bwm71_monster4", MAP_PLACE_SPAWN, 5, 16, 2, 2, "bwm71_monster4", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain71_map_changes[] = {
    {2, 0, 1, 1, "blackwater_mountain70", "hole"},
    {0, 7, 1, 2, "blackwater_mountain72", "east"},
    {6, 19, 2, 1, "blackwater_mountain73", "north"}
};
