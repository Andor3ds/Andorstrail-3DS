#include "fields4_map.h"

const MapPlace fields4_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 1, 23, 25, 1, "south", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 1, 1, 23, "west", "", "", 0, 0, ""},
    {"north", MAP_PLACE_MAPCHANGE, 0, 0, 20, 1, "north", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 26, 12, 1, 1, "east", "", "", 0, 0, ""},
    {"fieldcritter_2", MAP_PLACE_SPAWN, 2, 15, 24, 7, "fieldcritter_2", "", "", 0, 0, ""},
    {"fieldcritter_1", MAP_PLACE_SPAWN, 2, 2, 18, 10, "fieldcritter_1", "", "", 0, 0, ""}
};
const MapChangeEvent fields4_map_changes[] = {
    {1, 23, 25, 1, "loneford1", "northnorthwest"},
    {0, 1, 1, 23, "fields1", "east"},
    {0, 0, 20, 1, "fields7", "south"},
    {26, 12, 1, 1, "loneford2", "west"}
};
