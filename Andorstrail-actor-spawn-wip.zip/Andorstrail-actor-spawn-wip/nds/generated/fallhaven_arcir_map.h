#ifndef ANDOR_FALLHAVEN_ARCIR_MAP_H
#define ANDOR_FALLHAVEN_ARCIR_MAP_H
#include "map_data.h"

#define FALLHAVEN_ARCIR_WIDTH 15
#define FALLHAVEN_ARCIR_HEIGHT 10
#define FALLHAVEN_ARCIR_PIXEL_WIDTH (FALLHAVEN_ARCIR_WIDTH * 32)
#define FALLHAVEN_ARCIR_PIXEL_HEIGHT (FALLHAVEN_ARCIR_HEIGHT * 32)
#define FALLHAVEN_ARCIR_START_X 11
#define FALLHAVEN_ARCIR_START_Y 9
#define FALLHAVEN_ARCIR_PLACE_COUNT 3
#define FALLHAVEN_ARCIR_MAP_CHANGE_COUNT 2

static const unsigned char fallhaven_arcir_walkable[FALLHAVEN_ARCIR_WIDTH * FALLHAVEN_ARCIR_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0
};

extern const MapPlace fallhaven_arcir_places[];
extern const unsigned int fallhaven_arcir_place_count;
extern const MapChangeEvent fallhaven_arcir_map_changes[];
extern const unsigned int fallhaven_arcir_map_change_count;

#endif
