#include "blackwater_mountain31_map.h"

const MapPlace blackwater_mountain31_places[] = {
    {"south", MAP_PLACE_MAPCHANGE, 5, 7, 1, 1, "south", "", "", 0, 0, ""},
    {"rest", MAP_PLACE_REST, 1, 4, 1, 1, "rest", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 8, 6, 1, 1, "east", "", "", 0, 0, ""},
    {"sign_bwm31", MAP_PLACE_SIGN, 4, 4, 1, 1, "sign_bwm31", "", "", 0, 0, ""},
    {"ortholion_guard_wounded", MAP_PLACE_SPAWN, 2, 6, 1, 1, "ortholion_guard_wounded", "", "", 0, 0, ""}
};
const MapChangeEvent blackwater_mountain31_map_changes[] = {
    {5, 7, 1, 1, "blackwater_mountain30", "east"},
    {8, 6, 1, 1, "blackwater_mountain51", "east"}
};
