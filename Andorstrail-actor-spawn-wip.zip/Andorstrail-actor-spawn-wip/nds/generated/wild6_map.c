#include "wild6_map.h"

const MapPlace wild6_places[] = {
    {"north", MAP_PLACE_MAPCHANGE, 8, 0, 2, 1, "north", "", "", 0, 0, ""},
    {"east", MAP_PLACE_MAPCHANGE, 29, 23, 1, 3, "east", "", "", 0, 0, ""},
    {"south", MAP_PLACE_MAPCHANGE, 3, 29, 3, 1, "south", "", "", 0, 0, ""},
    {"house", MAP_PLACE_MAPCHANGE, 22, 21, 1, 1, "house", "", "", 0, 0, ""},
    {"sign_wild6", MAP_PLACE_SIGN, 8, 21, 1, 1, "sign_wild6", "", "", 0, 0, ""},
    {"east2", MAP_PLACE_MAPCHANGE, 29, 17, 1, 2, "east2", "", "", 0, 0, ""},
    {"east3", MAP_PLACE_MAPCHANGE, 29, 10, 1, 4, "east3", "", "", 0, 0, ""},
    {"north2", MAP_PLACE_MAPCHANGE, 19, 0, 1, 1, "north2", "", "", 0, 0, ""},
    {"sign_wild6_stump", MAP_PLACE_SIGN, 18, 20, 1, 1, "sign_wild6_stump", "", "", 0, 0, ""},
    {"brv_patrol_check_stop_hero", MAP_PLACE_SCRIPT, 4, 15, 14, 10, "brv_patrol_check_stop_hero", "", "", 0, 0, "enter"},
    {"north3", MAP_PLACE_MAPCHANGE, 1, 0, 2, 1, "north3", "", "", 0, 0, ""},
    {"west", MAP_PLACE_MAPCHANGE, 0, 2, 1, 13, "west", "", "", 0, 0, ""},
    {"down", MAP_PLACE_MAPCHANGE, 21, 11, 1, 1, "down", "", "", 0, 0, ""},
    {"forestboar2", MAP_PLACE_SPAWN, 6, 3, 15, 8, "forestboar2", "", "", 0, 0, ""},
    {"forestbeetle", MAP_PLACE_SPAWN, 12, 7, 16, 11, "forestbeetle", "", "", 0, 0, ""},
    {"forestwasp", MAP_PLACE_SPAWN, 5, 11, 10, 9, "forestwasp", "", "", 0, 0, ""},
    {"fox2", MAP_PLACE_SPAWN, 3, 16, 8, 10, "fox2", "", "", 0, 0, ""},
    {"forestwolf1", MAP_PLACE_SPAWN, 11, 20, 16, 8, "forestwolf1", "", "", 0, 0, ""},
    {"unzel", MAP_PLACE_SPAWN, 28, 2, 1, 1, "unzel", "", "", 0, 0, ""},
    {"knights", MAP_PLACE_SPAWN, 3, 14, 16, 12, "knights", "", "", 0, 0, ""},
    {"stop_hero", MAP_PLACE_KEY, 3, 14, 16, 12, "brv_wait_patrol", "questProgress", "brv_nondisplay", 140, 1, ""}
};
const MapChangeEvent wild6_map_changes[] = {
    {8, 0, 2, 1, "wild5", "south"},
    {29, 23, 1, 3, "wild9", "west"},
    {3, 29, 3, 1, "wild7", "north"},
    {22, 21, 1, 1, "wild6_house", "entrance"},
    {29, 17, 1, 2, "wild9", "west2"},
    {29, 10, 1, 4, "wild9", "west3"},
    {19, 0, 1, 1, "wild5", "south2"},
    {1, 0, 2, 1, "bwmfill7", "south2"},
    {0, 2, 1, 13, "bwmfill8", "east"},
    {21, 11, 1, 1, "thieves_vault", "up"}
};
