#ifndef ANDOR_BLACKWATER_MOUNTAIN19_MAP_H
#define ANDOR_BLACKWATER_MOUNTAIN19_MAP_H
#include "map_data.h"

#define BLACKWATER_MOUNTAIN19_WIDTH 10
#define BLACKWATER_MOUNTAIN19_HEIGHT 10
#define BLACKWATER_MOUNTAIN19_PIXEL_WIDTH (BLACKWATER_MOUNTAIN19_WIDTH * 32)
#define BLACKWATER_MOUNTAIN19_PIXEL_HEIGHT (BLACKWATER_MOUNTAIN19_HEIGHT * 32)
#define BLACKWATER_MOUNTAIN19_START_X 7
#define BLACKWATER_MOUNTAIN19_START_Y 2
#define BLACKWATER_MOUNTAIN19_PLACE_COUNT 3
#define BLACKWATER_MOUNTAIN19_MAP_CHANGE_COUNT 2

static const unsigned char blackwater_mountain19_walkable[BLACKWATER_MOUNTAIN19_WIDTH * BLACKWATER_MOUNTAIN19_HEIGHT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

extern const MapPlace blackwater_mountain19_places[];
extern const unsigned int blackwater_mountain19_place_count;
extern const MapChangeEvent blackwater_mountain19_map_changes[];
extern const unsigned int blackwater_mountain19_map_change_count;

#endif
