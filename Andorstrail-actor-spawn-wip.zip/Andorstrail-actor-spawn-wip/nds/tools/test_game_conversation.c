#include "game_conversation.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    assert(argc == 2);
    GameResources resources;
    assert(game_resources_init(&resources, argv[1]));
    GameRuntimeState state;
    game_runtime_state_init(&state, "Hero", "home", 1, 4);
    GameConversationSession conversation;
    char message[256];

    assert(game_conversation_start(
        &conversation, &resources, &state.player, &state.world,
        "mikhail", "mikhail_start_select", message, sizeof(message)
    ));
    assert(strcmp(message, "Oh good, you are awake.") == 0);
    assert(!game_player_has_quest_progress(&state.player, "andor", 1));

    assert(game_conversation_continue(
        &conversation, &resources, &state.player, &state.world,
        message, sizeof(message)
    ));
    assert(strcmp(message,
        "I can't seem to find your brother Andor anywhere. He hasn't been back since he left yesterday."
    ) == 0);
    assert(game_player_has_quest_progress(&state.player, "andor", 1));

    assert(game_conversation_continue(
        &conversation, &resources, &state.player, &state.world,
        message, sizeof(message)
    ));
    assert(strcmp(message, "Never mind, he will probably be back soon.") == 0);

    game_conversation_end(&conversation);
    game_runtime_state_dispose(&state);
    game_resources_dispose(&resources);
    puts("game conversation tests passed");
    return 0;
}