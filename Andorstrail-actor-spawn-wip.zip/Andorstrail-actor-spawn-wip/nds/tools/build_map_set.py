#!/usr/bin/env python3
"""Build the opening-region maps used by the Nintendo DS port."""

from pathlib import Path
from collections import deque
import json
import xml.etree.ElementTree as ET

from PIL import Image

from tmx2nds import (
    load_map_data,
    render_background,
    write_map_data_c,
    write_header,
    write_rgb555_binary,
)
from build_game_data import build_game_data


ROOT = Path(__file__).resolve().parents[2]


def upstream_root() -> Path:
    candidates = (
        ROOT / "upstream/AndorsTrail/AndorsTrail",
        ROOT / "upstream/AndorsTrail",
        ROOT / "upstream",
    )
    for candidate in candidates:
        if (candidate / "res" / "xml").exists() and (candidate / "res" / "drawable" / "char_hero.png").exists():
            return candidate
    return candidates[0]


UPSTREAM = upstream_root()
SOURCE_MAPS = UPSTREAM / "res" / "xml"
GENERATED = ROOT / "nds/generated"
NITROFS = GENERATED / "nitrofs"
SEED_MAPS = (
    ("home", "rest", "rest"),
    ("crossglen", "home", "mapchange"),
    ("crossglen_cave", "entrance", "mapchange"),
    ("crossglen_hall", "entrance", "mapchange"),
    ("crossglen_farmhouse", "entrance", "mapchange"),
    ("crossglen_smith", "entrance", "mapchange"),
    ("wild1", "west", "mapchange"),
    ("wild2", "north", "mapchange"),
    ("ratdom_bwm1", "east1", "mapchange"),
)
MAX_MAP_HOPS = 5


def discover_map_set() -> tuple[tuple[str, str, str], ...]:
    maps = list(SEED_MAPS)
    names = {name for name, _, _ in maps}
    queue = deque((name, 0) for name, _, _ in SEED_MAPS)
    while queue:
        source_name, depth = queue.popleft()
        if depth >= MAX_MAP_HOPS:
            continue
        root = ET.parse(SOURCE_MAPS / f"{source_name}.tmx").getroot()
        for group in root.findall("objectgroup"):
            for obj in group.findall("object"):
                if obj.attrib.get("type", "").lower() != "mapchange":
                    continue
                properties = {
                    prop.attrib.get("name", "").lower(): prop.attrib.get("value", "")
                    for prop in obj.findall("./properties/property")
                }
                target_map = properties.get("map", "")
                target_place = properties.get("place", "")
                if not target_map or target_map in names or not target_place:
                    continue
                if not (SOURCE_MAPS / f"{target_map}.tmx").is_file():
                    continue
                maps.append((target_map, target_place, "mapchange"))
                names.add(target_map)
                queue.append((target_map, depth + 1))
    return tuple(maps)


MAP_SET = discover_map_set()


def write_registry() -> None:
    lines = ["#ifndef ANDOR_MAP_REGISTRY_H", "#define ANDOR_MAP_REGISTRY_H", ""]
    lines.extend(f'#include "{name}_map.h"' for name, _, _ in MAP_SET)
    lines.extend(["", "static const GameMap maps[] = {"])
    for name, _, _ in MAP_SET:
        prefix = name.upper()
        lines.extend(
            [
                "    {",
                f'        "{name}", {prefix}_WIDTH, {prefix}_HEIGHT, {prefix}_START_X, {prefix}_START_Y,',
                f'        {name}_walkable, "nitro:/maps/{name}.rgb555.z", {name}_places, {prefix}_PLACE_COUNT,',
                f"        {name}_map_changes, {prefix}_MAP_CHANGE_COUNT,",
                "    },",
            ]
        )
    lines.extend(["};", "", "#endif", ""])
    (GENERATED / "map_registry.h").write_text("\n".join(lines), encoding="ascii")


def discover_spawn_areas() -> tuple[tuple[str, str, int, int, int, int, str, int, int, int, int], ...]:
    result = []
    for map_name, _, _ in MAP_SET:
        root = ET.parse(SOURCE_MAPS / f"{map_name}.tmx").getroot()
        tile_width = int(root.attrib["tilewidth"])
        tile_height = int(root.attrib["tileheight"])
        for group in root.findall("objectgroup"):
            for obj in group.findall("object"):
                if obj.attrib.get("type", "").lower() != "spawn":
                    continue
                properties = {
                    prop.attrib.get("name", "").lower(): prop.attrib.get("value", "")
                    for prop in obj.findall("./properties/property")
                }
                x_px = int(float(obj.attrib["x"]))
                y_px = int(float(obj.attrib["y"]))
                width_px = int(float(obj.attrib["width"]))
                height_px = int(float(obj.attrib["height"]))
                x = (x_px + tile_width // 2) // tile_width
                y = (y_px + tile_height // 2) // tile_height
                width = (width_px + tile_width // 2) // tile_width
                height = (height_px + tile_height // 2) // tile_height
                quantity = int(properties.get("quantity", "1"))
                respawn_speed = int(properties.get("respawnspeed", "10"))
                active = properties.get("active", "true").lower() in {"1", "true", "yes"}
                ignore_areas = properties.get("ignoreareas", "false").lower() in {"1", "true", "yes"}
                result.append((
                    map_name,
                    obj.attrib.get("name", ""),
                    x,
                    y,
                    width,
                    height,
                    properties.get("spawngroup", obj.attrib.get("name", "")),
                    quantity,
                    respawn_speed,
                    int(active),
                    int(ignore_areas),
                ))
    return tuple(result)


def write_spawn_registry() -> None:
    areas = discover_spawn_areas()
    header = "\n".join((
        "#ifndef ANDOR_MAP_SPAWN_REGISTRY_H",
        "#define ANDOR_MAP_SPAWN_REGISTRY_H",
        "#include \"map_data.h\"",
        "extern const MapSpawnArea map_spawn_areas[];",
        "extern const unsigned int map_spawn_area_count;",
        "#endif",
        "",
    ))
    rows = [
        "    {%s, %s, %d, %d, %d, %d, %s, %d, %d, %d, %d}," % (
            json.dumps(map_name), json.dumps(name), x, y, width, height,
            json.dumps(spawn_group), quantity, respawn_speed, active, ignore_areas
        )
        for map_name, name, x, y, width, height, spawn_group, quantity,
        respawn_speed, active, ignore_areas in areas
    ] or ['    {"", "", 0, 0, 0, 0, "", 0, 0, 0, 0},']
    source = "\n".join((
        '#include "map_spawn_registry.h"',
        "const MapSpawnArea map_spawn_areas[] = {",
        *rows,
        "};",
        "const unsigned int map_spawn_area_count =",
        "    sizeof(map_spawn_areas) / sizeof(map_spawn_areas[0]);",
        "",
    ))
    (GENERATED / "map_spawn_registry.h").write_text(header, encoding="ascii")
    (GENERATED / "map_spawn_registry.c").write_text(source, encoding="ascii")


def _marker_run(image: Image.Image, horizontal: bool, edge: int) -> tuple[int, int]:
    marker = (0, 0, 0, 255)
    limit = image.width if horizontal else image.height
    points = [
        point
        for point in range(1, limit - 1)
        if image.getpixel((point, edge) if horizontal else (edge, point)) == marker
    ]
    if not points or points != list(range(points[0], points[-1] + 1)):
        raise ValueError("Android nine-patch needs one contiguous black marker run per edge")
    return points[0], points[-1] + 1


def _load_ninepatch(source: Path):
    image = Image.open(source).convert("RGBA")
    stretch_x = _marker_run(image, True, 0)
    stretch_y = _marker_run(image, False, 0)
    content_x = _marker_run(image, True, image.height - 1)
    content_y = _marker_run(image, False, image.width - 1)
    pixels = image.crop((1, 1, image.width - 1, image.height - 1))
    rgb555 = []
    for red, green, blue, alpha in pixels.getdata():
        if alpha < 128:
            rgb555.append(0)
        else:
            rgb555.append((red >> 3) | ((green >> 3) << 5) | ((blue >> 3) << 10) | 0x8000)

    width, height = pixels.size
    return {
        "width": width,
        "height": height,
        "stretch_x": (stretch_x[0] - 1, stretch_x[1] - 1),
        "stretch_y": (stretch_y[0] - 1, stretch_y[1] - 1),
        "padding": (
            content_x[0] - 1,
            content_y[0] - 1,
            width - (content_x[1] - 1),
            height - (content_y[1] - 1),
        ),
        "pixels": rgb555,
    }


def write_dialog_art_header(source_dir: Path, destination: Path) -> None:
    assets = (
        ("std_frame", "ui_blue_stdframe.9.png"),
        ("button_unpressed", "ui_blue_textbutton_enabled_unpressed.9.png"),
        ("button_pressed", "ui_blue_textbutton_enabled_pressed.9.png"),
    )
    lines = ["#ifndef ANDOR_DIALOG_ART_H", "#define ANDOR_DIALOG_ART_H", ""]
    for name, filename in assets:
        asset = _load_ninepatch(source_dir / filename)
        upper = name.upper()
        for field in ("width", "height"):
            lines.append(f"#define DIALOG_{upper}_{field.upper()} {asset[field]}")
        for field in ("stretch_x", "stretch_y"):
            lines.append(f"#define DIALOG_{upper}_{field.upper()}_START {asset[field][0]}")
            lines.append(f"#define DIALOG_{upper}_{field.upper()}_END {asset[field][1]}")
        for field, value in zip(("LEFT", "TOP", "RIGHT", "BOTTOM"), asset["padding"]):
            lines.append(f"#define DIALOG_{upper}_PADDING_{field} {value}")
        lines.append(f"static const unsigned short dialog_{name}_pixels[] = {{")
        for offset in range(0, len(asset["pixels"]), 12):
            values = ", ".join(f"0x{value:04x}" for value in asset["pixels"][offset:offset + 12])
            lines.append(f"    {values},")
        lines.extend(["};", ""])
    lines.extend(["#endif", ""])
    destination.write_text("\n".join(lines), encoding="ascii")


def build_map_set() -> None:
    for obsolete_asset in NITROFS.rglob("*.rgb555") if NITROFS.exists() else ():
        obsolete_asset.unlink()

    hero_path = UPSTREAM / "res" / "drawable" / "char_hero.png"
    hero = Image.open(hero_path).convert("RGBA")
    if hero.size != (32, 32):
        raise ValueError(f"expected 32x32 hero sprite, got {hero.width}x{hero.height}")
    write_rgb555_binary(NITROFS / "hero.rgb555.z", hero, preserve_transparency=True)

    for name, spawn_name, spawn_type in MAP_SET:
        source = SOURCE_MAPS / f"{name}.tmx"
        header = GENERATED / f"{name}_map.h"
        background_source = GENERATED / f"{name}_map.c"
        width, height, gids, spawn, places, map_changes = load_map_data(source, spawn_name, spawn_type)
        write_header(header, name, width, height, gids, spawn, places, map_changes)
        background = render_background(source)
        write_rgb555_binary(NITROFS / "maps" / f"{name}.rgb555.z", background)
        write_map_data_c(background_source, name, places, map_changes)
        print(f"{name}: {width}x{height}, spawn {spawn_name} at {spawn[0]},{spawn[1]}, {len(map_changes)} exits")

    write_registry()
    write_spawn_registry()
    write_dialog_art_header(UPSTREAM / "res" / "drawable", GENERATED / "dialog_art.h")
    resource_count, packed_size = build_game_data(UPSTREAM, GENERATED)
    print(f"Wrote {resource_count} core JSON resources ({packed_size} compressed bytes)")
    print(f"Wrote registry for {len(MAP_SET)} maps")


if __name__ == "__main__":
    build_map_set()