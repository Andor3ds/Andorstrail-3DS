#!/usr/bin/env python3
"""Export the first game's TMX walkability layer for the NDS runtime."""

import argparse
import base64
import gzip
import json
import re
import struct
import xml.etree.ElementTree as ET
import zlib
from pathlib import Path

from PIL import Image

VISUAL_LAYER_NAMES = {"base", "ground", "objects", "above", "top"}
GID_MASK = 0x1FFFFFFF
FLIP_HORIZONTAL = 0x80000000
FLIP_VERTICAL = 0x40000000
FLIP_DIAGONAL = 0x20000000


def load_map_data(source: Path, spawn_name: str, spawn_type: str):
    root = ET.parse(source).getroot()
    width = int(root.attrib["width"])
    height = int(root.attrib["height"])
    tile_width = int(root.attrib["tilewidth"])
    tile_height = int(root.attrib["tileheight"])
    if (tile_width, tile_height) != (32, 32):
        raise ValueError(f"expected 32x32 tiles, got {tile_width}x{tile_height}")

    layer = next(
        (node for node in root.findall("layer") if node.attrib["name"].lower() == "walkable"),
        None,
    )
    if layer is None:
        raise ValueError("map has no Walkable layer")
    data = layer.find("data")
    if data is None or data.attrib.get("encoding") != "base64":
        raise ValueError("Walkable layer is not base64 encoded")

    compressed = base64.b64decode("".join(data.itertext()))
    compression = data.attrib.get("compression", "").lower()
    if compression == "zlib":
        raw = zlib.decompress(compressed)
    elif compression == "gzip":
        raw = gzip.decompress(compressed)
    else:
        raise ValueError(f"unsupported TMX compression: {compression!r}")

    tile_count = width * height
    if len(raw) != tile_count * 4:
        raise ValueError(f"Walkable layer has {len(raw)} bytes; expected {tile_count * 4}")
    gids = [value[0] for value in struct.iter_unpack("<I", raw)]

    spawn = None
    places = []
    map_changes = []
    for group in root.findall("objectgroup"):
        for obj in group.findall("object"):
            object_type = obj.attrib.get("type", "").lower()
            recognized_types = {"rest", "mapchange", "sign", "script", "key", "container", "spawn"}
            if object_type not in recognized_types:
                continue
            object_name = obj.attrib.get("name", "")
            x_px = int(obj.attrib["x"])
            y_px = int(obj.attrib["y"])
            width_px = int(obj.attrib["width"])
            height_px = int(obj.attrib["height"])
            x = (x_px + tile_width // 2) // tile_width
            y = (y_px + tile_height // 2) // tile_height
            place_width = (width_px + tile_width // 2) // tile_width
            place_height = (height_px + tile_height // 2) // tile_height
            if object_type == "rest":
                place_type = "MAP_PLACE_REST"
            elif object_type == "mapchange":
                place_type = "MAP_PLACE_MAPCHANGE"
            elif object_type == "sign":
                place_type = "MAP_PLACE_SIGN"
            elif object_type == "script":
                place_type = "MAP_PLACE_SCRIPT"
            elif object_type == "key":
                place_type = "MAP_PLACE_KEY"
            elif object_type == "container":
                place_type = "MAP_PLACE_CONTAINER"
            elif object_type == "spawn":
                place_type = "MAP_PLACE_SPAWN"
            else:
                continue

            properties = {
                prop.attrib.get("name", "").lower(): prop.attrib.get("value", "")
                for prop in obj.findall("./properties/property")
            }
            phrase_id = properties.get("phrase", object_name)
            require_type = properties.get("requiretype", "")
            require_id = properties.get("requireid", "")
            require_value = int(properties.get("requirevalue", "0")) if properties.get("requirevalue") else 0
            require_negation = 1 if properties.get("requirenegation", "false").lower() in {"1", "true", "yes"} else 0
            trigger_when = properties.get("when", "")
            places.append((
                object_name,
                place_type,
                x,
                y,
                place_width,
                place_height,
                phrase_id,
                require_type,
                require_id,
                require_value,
                require_negation,
                trigger_when,
            ))

            if object_name == spawn_name and object_type == spawn_type:
                spawn = (x, y)
            if object_type == "mapchange":
                if properties.get("map") and properties.get("place"):
                    map_changes.append((x, y, place_width, place_height, properties["map"], properties["place"]))
    if spawn is None:
        raise ValueError(f"map has no {spawn_type} place named {spawn_name!r}")
    spawn_x, spawn_y = spawn
    if not (0 <= spawn_x < width and 0 <= spawn_y < height):
        raise ValueError("rest spawn is outside the map")
    if gids[spawn_y * width + spawn_x] != 0:
        fallback = next((place for place in places if place[1] == "MAP_PLACE_MAPCHANGE"), None)
        if fallback is None:
            raise ValueError("blocked spawn has no map-change fallback")
        spawn = fallback[2], fallback[3]

    return width, height, gids, spawn, places, map_changes


def load_home_map(source: Path) -> tuple[int, int, list[int], tuple[int, int]]:
    width, height, gids, spawn, _, _ = load_map_data(source, "rest", "rest")
    return width, height, gids, spawn


def map_change_destination(event, destination_place, player_position: tuple[int, int]) -> tuple[int, int]:
    offset_x = player_position[0] - event[0]
    offset_y = player_position[1] - event[1]
    return (
        destination_place[2] + min(offset_x, destination_place[4] - 1),
        destination_place[3] + min(offset_y, destination_place[5] - 1),
    )


def write_header(
    destination: Path,
    prefix: str,
    width: int,
    height: int,
    gids: list[int],
    spawn: tuple[int, int],
    places,
    map_changes,
) -> None:
    if not re.fullmatch(r"[a-z][a-z0-9_]*", prefix):
        raise ValueError(f"map name cannot be used as a C identifier: {prefix!r}")
    upper = prefix.upper()
    walkable = [int(gid == 0) for gid in gids]
    values = []
    for row in range(height):
        start = row * width
        values.append("    " + ", ".join(str(value) for value in walkable[start : start + width]))

    text = "\n".join(
        [
            f"#ifndef ANDOR_{upper}_MAP_H",
            f"#define ANDOR_{upper}_MAP_H",
            "#include \"map_data.h\"",
            "",
            f"#define {upper}_WIDTH {width}",
            f"#define {upper}_HEIGHT {height}",
            f"#define {upper}_PIXEL_WIDTH ({upper}_WIDTH * 32)",
            f"#define {upper}_PIXEL_HEIGHT ({upper}_HEIGHT * 32)",
            f"#define {upper}_START_X {spawn[0]}",
            f"#define {upper}_START_Y {spawn[1]}",
            f"#define {upper}_PLACE_COUNT {len(places)}",
            f"#define {upper}_MAP_CHANGE_COUNT {len(map_changes)}",
            "",
            f"static const unsigned char {prefix}_walkable[{upper}_WIDTH * {upper}_HEIGHT] = {{",
            ",\n".join(values),
            "};",
            "",
            f"extern const MapPlace {prefix}_places[];",
            f"extern const unsigned int {prefix}_place_count;",
            f"extern const MapChangeEvent {prefix}_map_changes[];",
            f"extern const unsigned int {prefix}_map_change_count;",
            "",
            "#endif",
            "",
        ]
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="ascii")


def write_rgb555_binary(destination: Path, image: Image.Image, preserve_transparency: bool = False) -> None:
    raw = bytearray()
    rgba_image = image.convert("RGBA")
    for red, green, blue, alpha in rgba_image.getdata():
        if preserve_transparency and alpha < 128:
            pixel = 0
        else:
            pixel = (red >> 3) | ((green >> 3) << 5) | ((blue >> 3) << 10) | 0x8000
        raw.extend((pixel & 0xFF, pixel >> 8))
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(zlib.compress(raw, level=9))


def write_map_data_c(destination: Path, prefix: str, places, map_changes) -> None:
    place_rows = [
        f"    {{{json.dumps(name)}, {kind}, {x}, {y}, {width}, {height}, {json.dumps(phrase_id)}, {json.dumps(require_type)}, {json.dumps(require_id)}, {require_value}, {require_negation}, {json.dumps(trigger_when)}}}"
        for name, kind, x, y, width, height, phrase_id, require_type, require_id, require_value, require_negation, trigger_when in places
    ] or ['    {"", 0, 0, 0, 0, 0, "", "", "", 0, 0, ""}']
    change_rows = [
        f"    {{{x}, {y}, {width}, {height}, {json.dumps(target_map)}, {json.dumps(target_place)}}}"
        for x, y, width, height, target_map, target_place in map_changes
    ] or ['    {0, 0, 0, 0, "", ""}']
    text = "\n".join(
        [
            f'#include "{prefix}_map.h"',
            "",
            f"const MapPlace {prefix}_places[] = {{",
            ",\n".join(place_rows),
            "};",
            f"const MapChangeEvent {prefix}_map_changes[] = {{",
            ",\n".join(change_rows),
            "};",
            "",
        ]
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="ascii")


def render_background(source: Path) -> Image.Image:
    root = ET.parse(source).getroot()
    width = int(root.attrib["width"])
    height = int(root.attrib["height"])
    tile_width = int(root.attrib["tilewidth"])
    tile_height = int(root.attrib["tileheight"])
    background = Image.new("RGBA", (width * tile_width, height * tile_height), (0, 0, 0, 255))
    tilesets = sorted(root.findall("tileset"), key=lambda item: int(item.attrib["firstgid"]))
    images: dict[Path, Image.Image] = {}

    for layer in root.findall("layer"):
        if layer.attrib["name"].lower() not in VISUAL_LAYER_NAMES:
            continue
        data = layer.find("data")
        if data is None or data.attrib.get("encoding") != "base64":
            raise ValueError(f"layer {layer.attrib.get('name')!r} is not base64 encoded")
        compressed = base64.b64decode("".join(data.itertext()))
        compression = data.attrib.get("compression", "").lower()
        if compression == "zlib":
            raw = zlib.decompress(compressed)
        elif compression == "gzip":
            raw = gzip.decompress(compressed)
        else:
            raise ValueError(f"unsupported TMX compression: {compression!r}")
        gids = [value[0] for value in struct.iter_unpack("<I", raw)]
        if len(gids) != width * height:
            raise ValueError(f"layer {layer.attrib.get('name')!r} has invalid dimensions")

        for index, raw_gid in enumerate(gids):
            gid = raw_gid & GID_MASK
            if gid == 0:
                continue
            tileset = next((item for item in reversed(tilesets) if int(item.attrib["firstgid"]) <= gid), None)
            if tileset is None:
                raise ValueError(f"no tileset contains global tile id {gid}")
            image_node = tileset.find("image")
            if image_node is None:
                raise ValueError(f"tileset {tileset.attrib.get('name')!r} has no image")
            image_path = (source.parent / image_node.attrib["source"]).resolve()
            if image_path not in images:
                images[image_path] = Image.open(image_path).convert("RGBA")
            image = images[image_path]

            first_gid = int(tileset.attrib["firstgid"])
            local_id = gid - first_gid
            columns = int(tileset.attrib.get("columns", image.width // tile_width))
            tile_x = local_id % columns * tile_width
            tile_y = local_id // columns * tile_height
            tile = image.crop((tile_x, tile_y, tile_x + tile_width, tile_y + tile_height))
            if raw_gid & FLIP_DIAGONAL:
                tile = tile.transpose(Image.Transpose.TRANSPOSE)
            if raw_gid & FLIP_HORIZONTAL:
                tile = tile.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            if raw_gid & FLIP_VERTICAL:
                tile = tile.transpose(Image.Transpose.FLIP_TOP_BOTTOM)

            x = index % width * tile_width
            y = index // width * tile_height
            background.alpha_composite(tile, (x, y))

    return background.convert("RGB")


def write_background_c(
    destination: Path,
    background: Image.Image,
    hero: Image.Image,
    prefix: str = "home",
    places=(),
    map_changes=(),
) -> None:
    def write_pixels(image: Image.Image, opaque_transparency: bool) -> str:
        rgba_image = image.convert("RGBA")
        rows = []
        for y in range(image.height):
            values = []
            for x in range(image.width):
                red, green, blue, alpha = rgba_image.getpixel((x, y))
                if opaque_transparency and alpha < 128:
                    values.append("0x0000")
                else:
                    value = (red >> 3) | ((green >> 3) << 5) | ((blue >> 3) << 10) | 0x8000
                    values.append(f"0x{value:04x}")
            rows.append("    " + ", ".join(values))
        return ",\n".join(rows)

    place_rows = [
        f"    {{{json.dumps(name)}, {kind}, {x}, {y}, {width}, {height}}}"
        for name, kind, x, y, width, height in places
    ] or ['    {"", 0, 0, 0, 0, 0}']
    change_rows = [
        f"    {{{x}, {y}, {width}, {height}, {json.dumps(target_map)}, {json.dumps(target_place)}}}"
        for x, y, width, height, target_map, target_place in map_changes
    ] or ['    {0, 0, 0, 0, "", ""}']

    text = "\n".join(
        [
            f'#include "{prefix}_map.h"',
            "",
            f"const unsigned short {prefix}_background[{prefix.upper()}_PIXEL_WIDTH * {prefix.upper()}_PIXEL_HEIGHT] = {{",
            write_pixels(background, False),
            "};",
            "",
            f"const unsigned short {prefix}_hero[32 * 32] = {{",
            write_pixels(hero, True),
            "};",
            "",
            f"const MapPlace {prefix}_places[] = {{",
            ",\n".join(place_rows),
            "};",
            f"const unsigned int {prefix}_place_count = {len(places)};",
            "",
            f"const MapChangeEvent {prefix}_map_changes[] = {{",
            ",\n".join(change_rows),
            "};",
            f"const unsigned int {prefix}_map_change_count = {len(map_changes)};",
            "",
        ]
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="ascii")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--spawn-name", default="rest")
    parser.add_argument("--spawn-type", choices=("rest", "mapchange"), default="rest")
    parser.add_argument("--background-source", type=Path)
    parser.add_argument("--preview", type=Path)
    args = parser.parse_args()

    prefix = args.source.stem
    width, height, gids, spawn, places, map_changes = load_map_data(args.source, args.spawn_name, args.spawn_type)
    write_header(args.destination, prefix, width, height, gids, spawn, places, map_changes)
    background = render_background(args.source)
    hero_path = args.source.parent.parent / "drawable" / "char_hero.png"
    hero = Image.open(hero_path).convert("RGBA")
    if hero.size != (32, 32):
        raise ValueError(f"expected 32x32 hero sprite, got {hero.width}x{hero.height}")
    background_source = args.background_source or args.destination.with_suffix(".c")
    write_background_c(background_source, background, hero, prefix, places, map_changes)
    if args.preview:
        args.preview.parent.mkdir(parents=True, exist_ok=True)
        background.save(args.preview)
    print(f"Exported {width}x{height} {prefix} map; {args.spawn_name} spawn at {spawn[0]},{spawn[1]}")
    print(f"Exported {background.width}x{background.height} RGB555 map art to {background_source}")


if __name__ == "__main__":
    main()