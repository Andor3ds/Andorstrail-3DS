#include "game_state.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static uint32_t old_hash_slot(const char *name)
{
    uint32_t hash = 2166136261u;
    while (*name != '\0') {
        hash ^= (unsigned char)*name++;
        hash *= 16777619u;
    }
    return hash % 64;
}

int main(void)
{
    GameRuntimeState state;
    game_runtime_state_init(&state, "Hero", "home", 1, 4);
    assert(state.player.hp.current == 25 && state.player.hp.maximum == 25);
    assert(state.player.ap.current == 10 && state.player.ap.maximum == 10);
    assert(state.player.level == 1 && state.player.total_experience == 1);
    assert(strcmp(state.player.player_id, "player") == 0);
    assert(state.player.saved_version == 1);
    assert(state.player.level_experience.current == 1);
    assert(state.player.level_experience.maximum == 55);
    assert(strcmp(state.player.map_id, "home") == 0);
    assert(strcmp(state.world.current_map_id, "home") == 0);
    assert(game_player_add_gold(&state.player, 12) && state.player.gold == 12);
    assert(!game_player_add_gold(&state.player, -1) && state.player.gold == 12);
    assert(game_player_add_item(&state.player, "club1", 1));
    assert(game_player_add_item(&state.player, "club1", 2));
    assert(game_player_item_quantity(&state.player, "club1") == 3);
    assert(game_player_equip(&state.player, "weapon", "club1"));
    assert(game_player_equip(&state.player, "weapon", "sword1"));
    assert(state.player.equipment_count == 1);
    assert(game_player_unequip(&state.player, "weapon"));
    assert(game_player_remove_item(&state.player, "club1", 3));
    assert(game_player_item_quantity(&state.player, "club1") == 0);
    assert(game_player_set_condition(&state.player, "poison", 2, 3));
    assert(game_player_set_condition(&state.player, "poison", 1, 2));
    assert(state.player.condition_count == 1);
    assert(game_player_remove_condition(&state.player, "poison"));

    char first[32] = "";
    char second[32] = "";
    int found_collision = 0;
    for (int first_index = 0; first_index < 256 && !found_collision; ++first_index) {
        snprintf(first, sizeof(first), "state_%d", first_index);
        for (int second_index = first_index + 1; second_index < 512; ++second_index) {
            snprintf(second, sizeof(second), "state_%d", second_index);
            if (old_hash_slot(first) == old_hash_slot(second)) {
                found_collision = 1;
                break;
            }
        }
    }
    assert(found_collision);
    assert(strcmp(first, second) != 0);
    GameNamedValues flags = {0};
    assert(game_named_values_set(&flags, first, 11));
    assert(game_named_values_set(&flags, second, 29));
    int64_t value = 0;
    assert(game_named_values_get(&flags, first, &value) && value == 11);
    assert(game_named_values_get(&flags, second, &value) && value == 29);
    assert(game_named_values_set(&flags, first, 17));
    assert(game_named_values_get(&flags, first, &value) && value == 17);
    assert(flags.count == 2);
    game_named_values_dispose(&flags);

    assert(game_player_add_quest_progress(&state.player, "andor", 10));
    assert(game_player_add_quest_progress(&state.player, "andor", 1));
    assert(game_player_add_quest_progress(&state.player, "andor", 10));
    assert(game_player_has_quest_progress(&state.player, "andor", 1));
    assert(!game_player_has_quest_progress(&state.player, "andor", 5));
    assert(game_player_latest_quest_progress(&state.player, "andor") == 10);
    assert(game_player_is_latest_quest_progress(&state.player, "andor", 10));
    assert(!game_player_is_latest_quest_progress(&state.player, "andor", 1));

    GameMapState *map = game_world_map_state(&state.world, "crossglen", true);
    assert(map != NULL);
    map->visited = true;
    map->last_visit_tick = 42;
    assert(game_world_map_state(&state.world, "crossglen", false)->last_visit_tick == 42);
    GameObjectState *event = game_world_object_state(
        &state.world, "crossglen", "sign_wild1", 3, 4, 16, true
    );
    assert(event != NULL && event->active && !event->triggered);
    event->triggered = true;
    assert(game_world_object_state(
        &state.world, "crossglen", "sign_wild1", 3, 4, 16, false
    )->triggered);
    assert(game_world_set_timer(&state.world, "intro_timer"));
    assert(!game_world_timer_elapsed(&state.world, "intro_timer", 1));
    game_world_tick(&state.world, 1);
    assert(game_world_timer_elapsed(&state.world, "intro_timer", 1));

    game_runtime_state_dispose(&state);
    puts("game state tests passed");
    return 0;
}