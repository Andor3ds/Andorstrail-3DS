import subprocess
import sys
import tempfile
import unittest
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_game_data import build_game_data


ROOT = Path(__file__).resolve().parents[2]


class GameResourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary_directory = tempfile.TemporaryDirectory()
        temporary_path = Path(cls.temporary_directory.name)
        cls.executables = {}
        tests = {
            "state": [
                str(ROOT / "nds/source/game_state.c"),
                str(ROOT / "nds/tools/test_game_state.c"),
            ],
            "json": [
                str(ROOT / "nds/source/game_json.c"),
                str(ROOT / "nds/tools/test_game_json.c"),
            ],
            "requirements": [
                str(ROOT / "nds/source/game_state.c"),
                str(ROOT / "nds/source/game_requirements.c"),
                str(ROOT / "nds/tools/test_game_requirements.c"),
            ],
            "conversation": [
                str(ROOT / "nds/source/game_json.c"),
                str(ROOT / "nds/source/game_state.c"),
                str(ROOT / "nds/source/game_requirements.c"),
                str(ROOT / "nds/source/game_resources.c"),
                str(ROOT / "nds/source/game_conversation.c"),
                str(ROOT / "nds/generated/game_resource_index.c"),
                str(ROOT / "nds/tools/test_game_conversation.c"),
                "-lz",
            ],
            "actors": [
                str(ROOT / "nds/source/game_json.c"),
                str(ROOT / "nds/source/game_state.c"),
                str(ROOT / "nds/source/game_resources.c"),
                str(ROOT / "nds/source/game_actor_system.c"),
                str(ROOT / "nds/generated/game_resource_index.c"),
                str(ROOT / "nds/generated/map_spawn_registry.c"),
                str(ROOT / "nds/tools/test_game_actor_system.c"),
                "-lz",
            ],
            "resources": [
                str(ROOT / "nds/source/game_json.c"),
                str(ROOT / "nds/source/game_state.c"),
                str(ROOT / "nds/source/game_resources.c"),
                str(ROOT / "nds/generated/game_resource_index.c"),
                str(ROOT / "nds/tools/test_game_resources.c"),
                "-lz",
            ],
        }
        for test_name, sources in tests.items():
            executable = temporary_path / f"test_game_{test_name}"
            subprocess.run(
                [
                    "gcc",
                    "-std=c11",
                    "-Wall",
                    "-Wextra",
                    "-Werror",
                    "-I",
                    str(ROOT / "nds/source"),
                    "-I",
                    str(ROOT / "nds/generated"),
                    *sources,
                    "-o",
                    str(executable),
                ],
                check=True,
                cwd=ROOT,
            )
            cls.executables[test_name] = executable

    @classmethod
    def tearDownClass(cls):
        cls.temporary_directory.cleanup()

    def test_pinned_original_resource_lookups(self):
        subprocess.run(
            [
                str(self.executables["resources"]),
                str(ROOT / "nds/generated/nitrofs/game_data.pack"),
            ],
            check=True,
            cwd=ROOT,
        )

    def test_structured_state_and_json_parser(self):
        for test_name in ("state", "json", "requirements"):
            subprocess.run([str(self.executables[test_name])], check=True, cwd=ROOT)

    def test_original_mikhail_conversation_flow(self):
        subprocess.run(
            [
                str(self.executables["conversation"]),
                str(ROOT / "nds/generated/nitrofs/game_data.pack"),
            ],
            check=True,
            cwd=ROOT,
        )

    def test_original_home_actor_spawn(self):
        subprocess.run(
            [
                str(self.executables["actors"]),
                str(ROOT / "nds/generated/nitrofs/game_data.pack"),
            ],
            check=True,
            cwd=ROOT,
        )

    def test_pack_builder_with_original_shaped_lists(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            raw = root / "source/res/raw"
            raw.mkdir(parents=True)
            (raw / "itemlist_fixture.json").write_text(
                '[{"id":"z_item","name":"Second"},{"id":"a_item","name":"First"}]',
                encoding="utf-8",
            )
            (raw / "questlist_fixture.json").write_text(
                '[{"id":"quest","stages":[{"progress":1}]}]', encoding="utf-8"
            )
            output = root / "generated"
            count, packed_size = build_game_data(root / "source", output)
            packed = (output / "nitrofs/game_data.pack").read_bytes()
            index = (output / "game_resource_index.c").read_text(encoding="ascii")

            self.assertEqual(count, 2)
            self.assertEqual(packed_size, len(packed))
            self.assertIn('"a_item"', index)
            self.assertIn('"quest"', index)
            self.assertIn(b'"z_item"', zlib.decompress(packed))


if __name__ == "__main__":
    unittest.main()
