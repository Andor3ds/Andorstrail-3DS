#include "game_actor_system.h"
#include "map_spawn_registry.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    assert(argc == 2);
    GameResources resources;
    assert(game_resources_init(&resources, argv[1]));
    GameRuntimeState state;
    game_runtime_state_init(&state, "Hero", "home", 1, 4);
    unsigned char walkable[12 * 10];
    memset(walkable, 1, sizeof(walkable));

    assert(game_actor_spawn_map(
        &resources, &state, "home", 12, 10, walkable, 1, 4,
        NULL, 0, map_spawn_areas, map_spawn_area_count
    ));
    assert(state.world.actor_count == 1);
    GameActorState *mikhail = game_world_actor_at(&state.world, "home", 9, 4);
    assert(mikhail != NULL);
    assert(strcmp(mikhail->monster_type_id, "mikhail") == 0);
    assert(strcmp(mikhail->phrase_id, "mikhail_start_select") == 0);
    assert(strcmp(mikhail->name, "Mikhail") == 0);
    assert(!mikhail->is_hostile && mikhail->hp > 0 && mikhail->max_hp > 0);

    game_runtime_state_dispose(&state);
    game_resources_dispose(&resources);
    puts("game actor system tests passed");
    return 0;
}