#include "game_resources.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

static GameJsonRef find_record(GameResources *resources, GameResourceType type, const char *id,
    GameJsonDocument *document)
{
    size_t matches = 0;
    const GameResourceRecordEntry *record = game_resources_find(type, id, &matches);
    assert(record != NULL && matches >= 1);
    GameJsonRef value = {NULL, GAME_JSON_NO_NODE};
    assert(game_resources_open_record(resources, record, document, &value));
    return value;
}

static void test_item(GameResources *resources)
{
    GameJsonDocument document;
    GameJsonRef raw = find_record(resources, GAME_RESOURCE_ITEM, "club1", &document);
    GameItemDefinition item;
    assert(game_resource_item_view(raw, &item));
    int64_t cost = 0;
    assert(game_json_integer(game_json_object_get(raw, "baseMarketCost"), &cost));
    assert(cost == 7 && item.base_market_cost == 7);
    assert(game_json_string_equals(item.name, "Wooden club"));
    assert(game_json_string_equals(item.category, "club"));
    assert(item.equip_effect.node != GAME_JSON_NO_NODE);
    game_json_dispose(&document);
}

static void test_monster(GameResources *resources)
{
    GameJsonDocument document;
    GameJsonRef raw = find_record(resources, GAME_RESOURCE_MONSTER, "mikhail", &document);
    GameMonsterDefinition monster;
    assert(game_resource_monster_view(raw, &monster));
    assert(game_json_string_equals(monster.name, "Mikhail"));
    assert(game_json_string_equals(monster.spawn_group, "mikhail"));
    assert(monster.max_hp >= 1 && monster.max_ap == 10);
    game_json_dispose(&document);

    size_t group_size = 0;
    const GameResourceRecordEntry *group_record = game_resources_find_spawn_group(
        "mikhail", 0, &group_size
    );
    assert(group_record != NULL && group_size == 1);
    raw = (GameJsonRef){NULL, GAME_JSON_NO_NODE};
    assert(game_resources_open_record(resources, group_record, &document, &raw));
    assert(game_resource_monster_view(raw, &monster));
    assert(game_json_string_equals(monster.id, "mikhail"));
    game_json_dispose(&document);

    raw = find_record(resources, GAME_RESOURCE_MONSTER, "brightport_lizard00", &document);
    assert(game_resource_monster_view(raw, &monster));
    assert(monster.critical_skill == 15 && monster.critical_multiplier == 1.5);
    game_json_dispose(&document);
}

static void test_quest(GameResources *resources)
{
    GameJsonDocument document;
    GameJsonRef raw = find_record(resources, GAME_RESOURCE_QUEST, "andor", &document);
    GameQuestDefinition quest;
    assert(game_resource_quest_view(raw, &quest));
    assert(game_json_string_equals(quest.name, "Search for Andor"));
    assert(quest.show_in_log && game_json_array_size(quest.stages) > 1);
    game_json_dispose(&document);
}

static void test_conversation_requirements_and_effects(GameResources *resources)
{
    GameJsonDocument document;
    GameJsonRef raw = find_record(
        resources, GAME_RESOURCE_CONVERSATION, "agthor", &document
    );
    GameConversationDefinition conversation;
    assert(game_resource_conversation_view(raw, &conversation));
    GameJsonRef first_reply = game_json_array_get(conversation.replies, 0);
    GameJsonRef requirements = game_json_object_get(first_reply, "requires");
    GameRequirement requirement;
    assert(game_resource_requirement_view(game_json_array_get(requirements, 0), &requirement));
    assert(game_json_string_equals(requirement.type, "questProgress"));
    assert(game_json_string_equals(requirement.id, "feygard_shipment"));

    game_json_dispose(&document);
    raw = find_record(resources, GAME_RESOURCE_CONVERSATION,
        "passive_achievement_grant_1", &document);
    assert(game_resource_conversation_view(raw, &conversation));
    GameEffect effect;
    assert(game_resource_effect_view(game_json_array_get(conversation.rewards, 0), &effect));
    assert(game_json_string_equals(effect.type, "questProgress"));
    assert(game_json_string_equals(effect.id, "achievements"));
    game_json_dispose(&document);
}

static void test_condition(GameResources *resources)
{
    GameJsonDocument document;
    GameJsonRef raw = find_record(resources, GAME_RESOURCE_CONDITION, "crushed", &document);
    GameConditionDefinition condition;
    assert(game_resource_condition_view(raw, &condition));
    assert(game_json_string_equals(condition.name, "Crushed"));
    assert(condition.round_effect.node != GAME_JSON_NO_NODE);
    assert(condition.ability_effect.node != GAME_JSON_NO_NODE);
    game_json_dispose(&document);
}

static void test_drop_list_and_category(GameResources *resources)
{
    GameJsonDocument document;
    GameJsonRef raw = find_record(resources, GAME_RESOURCE_DROP_LIST, "startitems", &document);
    GameDropListDefinition drop_list;
    assert(game_resource_drop_list_view(raw, &drop_list));
    assert(game_json_array_size(drop_list.items) > 1);
    game_json_dispose(&document);

    raw = find_record(resources, GAME_RESOURCE_ITEM_CATEGORY, "dagger", &document);
    GameItemCategoryDefinition category;
    assert(game_resource_item_category_view(raw, &category));
    assert(game_json_string_equals(category.action_type, "equip"));
    assert(game_json_string_equals(category.inventory_slot, "weapon"));
    game_json_dispose(&document);

    raw = find_record(resources, GAME_RESOURCE_ITEM_FILTER, "debug_any", &document);
    GameItemFilterDefinition filter;
    assert(game_resource_item_filter_view(raw, &filter));
    assert(game_json_array_size(filter.include_tags) > 0);
    game_json_dispose(&document);
}

static void test_container_loot_generation(GameResources *resources)
{
    GameWorldState world;
    game_world_init(&world, "home");
    assert(game_resources_generate_drop_list(
        resources, &world, "startitems2", "home", "startitems2", 10, 8, true
    ));
    GameWorldLootBag *bag = game_world_loot_bag(
        &world, "home", "startitems2", 10, 8, true, false
    );
    assert(bag != NULL && bag->is_container);
    assert(bag->gold == 12);
    assert(bag->item_count == 2);
    GamePlayer player;
    game_player_init(&player, "Hero", "home", 1, 4);
    assert(game_player_add_gold(&player, bag->gold));
    for (size_t index = 0; index < bag->item_count; ++index) {
        assert(game_player_add_item(&player, bag->items[index].item_id, bag->items[index].quantity));
    }
    assert(player.gold == 12);
    assert(game_player_item_quantity(&player, "kids_shirt") == 1);
    assert(game_player_item_quantity(&player, "kids_gloves") == 1);
    game_player_dispose(&player);
    assert(game_resources_generate_drop_list(
        resources, &world, "startitems2", "home", "startitems2", 10, 8, true
    ));
    assert(bag->gold == 12 && bag->item_count == 2);
    assert(game_world_clear_loot_bag(bag));
    assert(game_resources_generate_drop_list(
        resources, &world, "startitems2", "home", "startitems2", 10, 8, true
    ));
    assert(bag->gold == 0 && bag->item_count == 0);
    game_world_dispose(&world);
}

int main(int argc, char **argv)
{
    assert(argc == 2);
    GameResources resources;
    assert(game_resources_init(&resources, argv[1]));
    test_item(&resources);
    test_monster(&resources);
    test_quest(&resources);
    test_conversation_requirements_and_effects(&resources);
    test_condition(&resources);
    test_drop_list_and_category(&resources);
    test_container_loot_generation(&resources);
    assert(game_resources_find(GAME_RESOURCE_ITEM, "no_such_item", NULL) == NULL);
    game_resources_dispose(&resources);
    puts("game resource tests passed");
    return 0;
}