#include "game_requirements.h"

#include <assert.h>
#include <stdio.h>

static bool satisfied(
    const GamePlayer *player,
    const GameWorldState *world,
    const char *type,
    const char *id,
    int64_t value,
    bool negated
)
{
    const GameRequirementState requirement = {type, id, value, negated};
    return game_requirement_is_satisfied(player, world, &requirement);
}

int main(void)
{
    GameRuntimeState state;
    game_runtime_state_init(&state, "Hero", "home", 1, 4);

    assert(game_player_add_quest_progress(&state.player, "andor", 1));
    assert(game_player_add_quest_progress(&state.player, "andor", 10));
    assert(satisfied(&state.player, &state.world, "questProgress", "andor", 1, false));
    assert(!satisfied(&state.player, &state.world, "questProgress", "andor", 2, false));
    assert(satisfied(&state.player, &state.world, "questLatestProgress", "andor", 10, false));
    assert(!satisfied(&state.player, &state.world, "questLatestProgress", "andor", 1, false));

    assert(game_player_add_item(&state.player, "ratdom_torch", 1));
    assert(game_player_equip(&state.player, "weapon", "ratdom_torch"));
    assert(satisfied(&state.player, &state.world, "wear", "ratdom_torch", 1, false));
    assert(satisfied(&state.player, &state.world, "wear", "missing_item", 0, false));
    assert(satisfied(&state.player, &state.world, "inventoryKeep", "ratdom_torch", 1, false));
    assert(satisfied(&state.player, &state.world, "inventoryKeep", "ratdom_torch", 1, true) == false);

    assert(game_player_add_gold(&state.player, 12));
    assert(satisfied(&state.player, &state.world, "inventoryKeep", "gold", 10, false));
    assert(game_named_values_set(&state.player.alignments, "ThievesGuild", 1000));
    assert(satisfied(&state.player, &state.world, "factionScore", "ThievesGuild", 999, false));
    assert(!satisfied(&state.player, &state.world, "factionScoreEquals", "ThievesGuild", 999, false));
    assert(game_world_set_timer(&state.world, "key_area_timer"));
    game_world_tick(&state.world, 4);
    assert(satisfied(&state.player, &state.world, "timerElapsed", "key_area_timer", 4, false));

    const GameRequirementState remove_gold = {"inventoryRemove", "gold", 5, false};
    assert(game_requirement_is_satisfied(&state.player, &state.world, &remove_gold));
    assert(game_requirement_fulfill(&state.player, &remove_gold));
    assert(state.player.gold == 7);
    const GameRequirementState remove_torch = {"inventoryRemove", "ratdom_torch", 1, false};
    assert(game_requirement_fulfill(&state.player, &remove_torch));
    assert(game_player_item_quantity(&state.player, "ratdom_torch") == 0);
    const GameRequirementState remove_worn = {"wearRemove", "ratdom_torch", 1, false};
    assert(game_requirement_fulfill(&state.player, &remove_worn));
    assert(game_player_equipped_quantity(&state.player, "ratdom_torch") == 0);

    game_runtime_state_dispose(&state);
    puts("game requirement tests passed");
    return 0;
}