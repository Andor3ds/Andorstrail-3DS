import unittest
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import zlib

from PIL import Image

from build_map_set import (
    MAP_SET,
    UPSTREAM as MAP_SET_UPSTREAM,
    discover_spawn_areas,
    write_dialog_art_header,
)
from tmx2nds import (
    load_home_map,
    load_map_data,
    map_change_destination,
    render_background,
    write_background_c,
    write_rgb555_binary,
)


ROOT = Path(__file__).resolve().parents[2]


def upstream_root() -> Path:
    for candidate in (
        ROOT / "upstream/AndorsTrail/AndorsTrail",
        ROOT / "upstream/AndorsTrail",
        ROOT / "upstream",
    ):
        if (candidate / "res" / "xml" / "home.tmx").exists():
            return candidate
    return ROOT / "upstream/AndorsTrail/AndorsTrail"


UPSTREAM = upstream_root()
HOME_MAP = UPSTREAM / "res" / "xml" / "home.tmx"
CROSSGLEN_MAP = UPSTREAM / "res" / "xml" / "crossglen.tmx"


class HomeMapConversionTests(unittest.TestCase):
    def test_map_set_discovers_five_transition_hops(self):
        names = {name for name, _, _ in MAP_SET}

        self.assertEqual(len(MAP_SET), 152)
        self.assertIn("crossroads", names)
        self.assertIn("hauntedhouse1", names)
        self.assertIn("blackwater_mountain56", names)
        self.assertIn("fallhaven_nw", names)
        self.assertIn("thieves_vault", names)
        self.assertIn("fallhaven_ne", names)

    def test_spawn_registry_preserves_original_area_settings(self):
        spawn_areas = discover_spawn_areas()
        mikhail = next(area for area in spawn_areas if area[:2] == ("home", "mikhail"))
        self.assertEqual(mikhail, ("home", "mikhail", 9, 4, 1, 1, "mikhail", 1, 10, 1, 0))
        inactive_spawn = next(area for area in spawn_areas if area[0] == "home" and area[1] == "crossglen_valentina_spawn")
        self.assertEqual(inactive_spawn[9], 0)
        self.assertEqual(len(spawn_areas), 654)

    def test_non_aligned_tmx_event_uses_source_rounding(self):
        wild9 = UPSTREAM / "res" / "xml" / "wild9.tmx"
        _, _, _, _, places, _ = load_map_data(wild9, "north2", "mapchange")

        west = next(place for place in places if place[0] == "west")
        self.assertEqual(west[2:], (0, 17, 1, 3, "west", "", "", 0, 0, ""))

    def test_blocked_map_entry_uses_first_map_change_fallback(self):
        maze = UPSTREAM / "res" / "xml" / "ratdom_maze_438.tmx"
        width, _, gids, spawn, places, _ = load_map_data(maze, "south2", "mapchange")
        fallback = next(place for place in places if place[1] == "MAP_PLACE_MAPCHANGE")
        requested = next(place for place in places if place[0] == "south2")

        self.assertEqual(spawn, fallback[2:4])
        self.assertGreater(gids[requested[3] * width + requested[2]], 0)

    def test_original_spawn_is_walkable(self):
        width, height, gids, spawn = load_home_map(HOME_MAP)

        self.assertEqual((width, height), (12, 10))
        self.assertEqual(spawn, (1, 4))
        self.assertEqual(gids[spawn[1] * width + spawn[0]], 0)

    def test_visible_tilesets_compose_to_full_map_image(self):
        background = render_background(HOME_MAP)

        self.assertEqual(background.size, (384, 320))
        self.assertGreater(len(background.getcolors(background.width * background.height)), 16)

    def test_crossglen_tilesets_compose_to_full_map_image(self):
        background = render_background(CROSSGLEN_MAP)

        self.assertEqual(background.size, (960, 960))
        self.assertGreater(len(background.getcolors(background.width * background.height)), 16)

    def test_hero_export_preserves_transparent_pixels(self):
        background = Image.new("RGB", (1, 1), (255, 0, 0))
        hero = Image.new("RGBA", (1, 1), (0, 0, 255, 0))

        with TemporaryDirectory() as directory:
            output = Path(directory) / "map.c"
            write_background_c(output, background, hero)
            generated = output.read_text(encoding="ascii")

        self.assertIn("0x801f", generated)
        self.assertIn("0x0000", generated)

    def test_home_and_crossglen_transitions_match_original_maps(self):
        _, _, home_gids, _, home_places, home_changes = load_map_data(HOME_MAP, "rest", "rest")
        crossglen_path = UPSTREAM / "res" / "xml" / "crossglen.tmx"
        width, _, crossglen_gids, _, crossglen_places, crossglen_changes = load_map_data(
            crossglen_path, "home", "mapchange"
        )

        self.assertIn(("entrance", "MAP_PLACE_MAPCHANGE", 5, 9, 1, 1, "entrance", "", "", 0, 0, ""), home_places)
        self.assertIn((5, 9, 1, 1, "crossglen", "home"), home_changes)
        self.assertEqual(home_gids[9 * 12 + 5], 0)
        self.assertIn(("home", "MAP_PLACE_MAPCHANGE", 5, 5, 1, 1, "home", "", "", 0, 0, ""), crossglen_places)
        self.assertIn((5, 5, 1, 1, "home", "entrance"), crossglen_changes)
        self.assertEqual(crossglen_gids[5 * width + 5], 0)

    def test_multi_tile_transition_preserves_player_offset(self):
        crossglen = UPSTREAM / "res" / "xml" / "crossglen.tmx"
        _, _, _, _, _, crossglen_events = load_map_data(crossglen, "home", "mapchange")
        event = next(item for item in crossglen_events if item[4:6] == ("wild1", "west"))
        wild1 = UPSTREAM / "res" / "xml" / "wild1.tmx"
        _, _, _, _, wild1_places, _ = load_map_data(wild1, "west", "mapchange")
        destination = next(item for item in wild1_places if item[:2] == ("west", "MAP_PLACE_MAPCHANGE"))

        self.assertEqual(map_change_destination(event, destination, (event[0], event[1] + 1)), (destination[2], destination[3] + 1))

    def test_every_map_uses_requested_or_original_fallback_spawn(self):
        for name, spawn_name, spawn_type in MAP_SET:
            with self.subTest(map=name):
                width, _, gids, spawn, places, _ = load_map_data(
                    UPSTREAM / "res" / "xml" / f"{name}.tmx", spawn_name, spawn_type
                )
                requested = next(place for place in places if place[:2] == (spawn_name, f"MAP_PLACE_{spawn_type.upper()}"))
                requested_position = requested[2], requested[3]
                requested_is_walkable = gids[requested_position[1] * width + requested_position[0]] == 0
                expected = requested_position if requested_is_walkable else next(
                    (place[2], place[3]) for place in places if place[1] == "MAP_PLACE_MAPCHANGE"
                )
                self.assertEqual(spawn, expected)

    def test_interaction_objects_are_preserved_for_runtime_use(self):
        _, _, _, _, places, _ = load_map_data(UPSTREAM / "res" / "xml" / "wild1.tmx", "west", "mapchange")

        sign = next(place for place in places if place[0] == "sign_wild1")
        self.assertEqual(sign[1], "MAP_PLACE_SIGN")
        self.assertEqual(sign[2:], (4, 16, 1, 1, "sign_wild1", "", "", 0, 0, ""))

        generated = (ROOT / "nds/generated/wild1_map.c").read_text(encoding="ascii")
        self.assertIn(
            '{"sign_wild1", MAP_PLACE_SIGN, 4, 16, 1, 1, "sign_wild1", "", "", 0, 0, ""}',
            generated,
        )

        sign_messages = json.loads((UPSTREAM / "res/raw/conversationlist_signs_pre067.json").read_text(encoding="utf-8"))
        message = next(item["message"] for item in sign_messages if item["id"] == "sign_wild1")
        self.assertEqual(message, "West: Crossglen\nSouth: Fallhaven\nNorth: Feygard")

        runtime = (ROOT / "nds/source/main.c").read_text(encoding="ascii")
        self.assertIn("set_sign_message(event_phrase_id(place));", runtime)
        self.assertIn("sign_dialog_draw();", runtime)
        self.assertIn("process_step_events(int previous_x, int previous_y)", runtime)
        self.assertIn("position_is_in_place(place, previous_x, previous_y)", runtime)
        interaction = runtime[runtime.index("static int process_interaction"):runtime.index("static int should_trigger_place_on_step")]
        self.assertNotIn("MAP_PLACE_SIGN,", interaction)

        dialog = (ROOT / "nds/source/sign_dialog.c").read_text(encoding="ascii")
        self.assertIn('button_labels[] = {"Next", "Leave"}', dialog)
        self.assertNotIn("DIALOG_DURATION_FRAMES", dialog)

    def test_dialog_art_matches_original_android_ninepatch_assets(self):
        with TemporaryDirectory() as directory:
            generated = Path(directory) / "dialog_art.h"
            write_dialog_art_header(
                MAP_SET_UPSTREAM / "res" / "drawable",
                generated,
            )

            expected = (ROOT / "nds/generated/dialog_art.h").read_bytes()
            self.assertEqual(generated.read_bytes(), expected)

        art = expected.decode("ascii")
        self.assertIn("DIALOG_STD_FRAME_WIDTH 20", art)
        self.assertIn("DIALOG_STD_FRAME_PADDING_LEFT 4", art)
        self.assertIn("DIALOG_BUTTON_UNPRESSED_STRETCH_X_START 8", art)
        self.assertIn("dialog_std_frame_pixels", art)
        self.assertIn("dialog_button_unpressed_pixels", art)
        self.assertIn("dialog_button_pressed_pixels", art)

        dialog_source = (ROOT / "nds/source/sign_dialog.c").read_text(encoding="ascii")
        self.assertIn("#define DIALOG_FRAME_X 28", dialog_source)
        self.assertIn("#define DIALOG_FRAME_WIDTH 200", dialog_source)
        self.assertIn("#define DIALOG_MESSAGE_HEIGHT 70", dialog_source)
        self.assertIn("#define DIALOG_BUTTONS_HEIGHT 35", dialog_source)
        self.assertIn("#define DIALOG_BUTTON_HEIGHT 27", dialog_source)

    def test_key_requirements_and_phrase_text_are_preserved_for_runtime_use(self):
        _, _, _, _, places, _ = load_map_data(UPSTREAM / "res" / "xml" / "brightport_school1.tmx", "class1", "mapchange")

        key = next(place for place in places if place[0] == "Object")
        self.assertEqual(key[1], "MAP_PLACE_KEY")
        self.assertEqual(key[2:], (3, 1, 1, 1, "brightport_lectureroom", "questProgress", "brightport_nondisplay", 228, 0, ""))

    def test_spawn_areas_are_preserved_for_runtime_use(self):
        _, _, _, _, places, _ = load_map_data(UPSTREAM / "res" / "xml" / "crackshot_hideout2.tmx", "North", "mapchange")

        spawn = next(place for place in places if place[0] == "g03_deadpatrol_1")
        self.assertEqual(spawn[1], "MAP_PLACE_SPAWN")
        self.assertEqual(spawn[2:], (6, 18, 1, 1, "g03_deadpatrol_1", "", "", 0, 0, ""))

    def test_nitrofs_rgb555_bytes_preserve_transparency(self):
        image = Image.new("RGBA", (2, 1))
        image.putpixel((0, 0), (255, 0, 0, 255))
        image.putpixel((1, 0), (0, 0, 255, 0))

        with TemporaryDirectory() as directory:
            output = Path(directory) / "test.rgb555.z"
            write_rgb555_binary(output, image, preserve_transparency=True)

            self.assertEqual(zlib.decompress(output.read_bytes()), b"\x1f\x80\x00\x00")

    def test_nitrofs_map_files_match_source_dimensions(self):
        registry = (ROOT / "nds/generated/map_registry.h").read_text(encoding="ascii")
        hero = ROOT / "nds/generated/nitrofs/hero.rgb555.z"
        runtime = (ROOT / "nds/source/main.c").read_text(encoding="ascii")
        self.assertTrue(hero.is_file())
        self.assertEqual(len(zlib.decompress(hero.read_bytes())), 32 * 32 * 2)
        self.assertIn('load_rgb555("nitro:/hero.rgb555.z"', runtime)

        for name, spawn_name, spawn_type in MAP_SET:
            with self.subTest(map=name):
                source = UPSTREAM / "res" / "xml" / f"{name}.tmx"
                width, height, _, _, _, _ = load_map_data(source, spawn_name, spawn_type)
                packed = ROOT / f"nds/generated/nitrofs/maps/{name}.rgb555.z"
                self.assertEqual(len(zlib.decompress(packed.read_bytes())), width * height * 32 * 32 * 2)
                self.assertIn(f'"{name}"', registry)
                self.assertIn(f'"nitro:/maps/{name}.rgb555.z"', registry)


if __name__ == "__main__":
    unittest.main()