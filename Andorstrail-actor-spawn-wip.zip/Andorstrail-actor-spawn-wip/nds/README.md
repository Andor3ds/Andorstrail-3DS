# Andor's Trail DS port scaffold

`source/main.c` currently loads 152 maps reachable within five map-change hops of
the opening area. It follows source-defined transitions and loads one map's art
from NitroFS at a time. Multi-tile exits preserve the player's relative position
at the destination. Both DS displays show different, vertically adjacent
viewports of the same world; the bottom viewport begins exactly 192 world pixels
below the top. Scripted interactions, combat, dialogue, inventory, quests, save
data, and maps beyond this connected region still need to be ported.

Regenerate all map tables and NitroFS assets from the downloaded source with
host Python:

```sh
/usr/bin/python3 nds/tools/build_map_set.py
```

This also generates `nds/generated/nitrofs/game_data.pack` and its record index
from the pinned Android source commit `0dfa1f63ea6d944df2c6d34e641000c09d3e917e`.
The pack contains 449 original raw JSON documents compressed to about 1.25 MB;
the runtime inflates one document at a time. Typed views cover items, monsters,
quests, conversations, actor conditions, requirements, and effects. Loading
these definitions does not implement their gameplay systems.

To regenerate only this JSON pack:

```sh
/usr/bin/python3 nds/tools/build_game_data.py --source upstream/AndorsTrail
```

This asset step requires Pillow (`sudo apt install python3-pil` on Ubuntu).
Run the conversion tests with:

```sh
/usr/bin/python3 -m unittest discover -s nds/tools -v
```

The official `devkitpro/devkitarm` Docker image provides devkitARM and libnds.
From the repository root, build the ROM with:

```sh
docker run --rm \
  -v "$PWD/nds:/work" -w /work \
  -e DEVKITPRO=/opt/devkitpro \
  -e DEVKITARM=/opt/devkitpro/devkitARM \
  -e LIBNDS=/opt/devkitpro/libnds \
  -e PATH=/opt/devkitpro/devkitARM/bin:/opt/devkitpro/tools/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  devkitpro/devkitarm make
```

The output is `nds/andorstrail-ds.nds`. Map graphics are packaged as RGB555
NitroFS files and loaded on demand; walkability, places, and map-change events
are compiled into the runtime. The upstream project documents separate content
and graphics licenses.

The host state/resource tests compile with GCC and require zlib.

## Test it

Open [andorstrail-ds.nds](andorstrail-ds.nds) in a desktop Nintendo DS emulator
such as DeSmuME or melonDS. Both screens show distinct sections of the same
map; moving the player scrolls their coordinated viewports together. Use the
D-pad to move. Walk right eight tiles to Mikhail at (9,4), press A and advance
through the opening exchange to start the original Andor quest. Press B to leave,
then walk left four tiles and down five tiles to reach Crossglen. Press A while
standing on a container to collect its original drop-list contents. Press A on
a rest point to set a checkpoint; Start respawns there. Exits beyond the included
152-map area are not loaded yet; this is not the complete game.

If startup data loading fails, the ROM now shows a named boot-failure stage
instead of silently returning to the launcher. Press Start to exit and note
whether it reports NitroFS initialization, hero sprite loading, or Home map
loading.