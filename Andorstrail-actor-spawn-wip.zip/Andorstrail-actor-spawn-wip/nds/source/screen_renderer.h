#ifndef ANDOR_SCREEN_RENDERER_H
#define ANDOR_SCREEN_RENDERER_H

void screen_renderer_init(void);
void screen_renderer_draw(
    const unsigned short *background,
    int map_width,
    int map_height,
    const unsigned short *hero,
    int player_x,
    int player_y
);

#endif