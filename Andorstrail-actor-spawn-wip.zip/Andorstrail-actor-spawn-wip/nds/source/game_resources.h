#ifndef ANDOR_GAME_RESOURCES_H
#define ANDOR_GAME_RESOURCES_H

#include "game_json.h"
#include "game_state.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define GAME_RESOURCE_ID_CAPACITY 128

typedef enum {
    GAME_RESOURCE_ITEM,
    GAME_RESOURCE_MONSTER,
    GAME_RESOURCE_QUEST,
    GAME_RESOURCE_CONVERSATION,
    GAME_RESOURCE_CONDITION,
    GAME_RESOURCE_DROP_LIST,
    GAME_RESOURCE_ITEM_CATEGORY,
    GAME_RESOURCE_ITEM_FILTER
} GameResourceType;

typedef struct {
    const char *name;
    GameResourceType type;
    uint32_t offset;
    uint32_t compressed_size;
    uint32_t source_size;
} GameResourceDocumentEntry;

typedef struct {
    const char *id;
    const char *spawn_group;
    uint16_t document_index;
    uint32_t record_index;
    GameResourceType type;
} GameResourceRecordEntry;

typedef struct {
    const char *spawn_group;
    const GameResourceRecordEntry *record;
} GameResourceSpawnGroupEntry;

typedef struct {
    FILE *pack;
} GameResources;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef name;
    GameJsonRef description;
    GameJsonRef icon_id;
    GameJsonRef category;
    GameJsonRef equip_effect;
    GameJsonRef use_effect;
    GameJsonRef hit_effect;
    GameJsonRef miss_effect;
    GameJsonRef kill_effect;
    GameJsonRef hit_received_effect;
    GameJsonRef miss_received_effect;
    int base_market_cost;
    bool has_manual_price;
} GameItemDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef name;
    GameJsonRef icon_id;
    GameJsonRef spawn_group;
    GameJsonRef phrase_id;
    GameJsonRef attack_damage;
    GameJsonRef drop_list_id;
    GameJsonRef movement_aggression;
    GameJsonRef monster_class;
    GameJsonRef faction;
    bool is_unique;
    int critical_skill;
    double critical_multiplier;
    int block_chance;
    int damage_resistance;
    int max_hp;
    int max_ap;
    int move_cost;
    int attack_cost;
    int attack_chance;
} GameMonsterDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef name;
    GameJsonRef stages;
    bool show_in_log;
} GameQuestDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef message;
    GameJsonRef replies;
    GameJsonRef rewards;
    GameJsonRef switch_to_npc;
} GameConversationDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef name;
    GameJsonRef description;
    GameJsonRef icon_id;
    GameJsonRef category;
    GameJsonRef round_effect;
    GameJsonRef ability_effect;
    bool is_stacking;
    bool is_positive;
} GameConditionDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef items;
} GameDropListDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef name;
    GameJsonRef action_type;
    GameJsonRef size;
    GameJsonRef inventory_slot;
} GameItemCategoryDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef id;
    GameJsonRef include_tags;
    GameJsonRef exclude_tags;
} GameItemFilterDefinition;

typedef struct {
    GameJsonRef raw;
    GameJsonRef type;
    GameJsonRef id;
    GameJsonRef value;
    GameJsonRef negate;
} GameRequirement;

typedef struct {
    GameJsonRef raw;
    GameJsonRef type;
    GameJsonRef id;
    GameJsonRef value;
    GameJsonRef map_name;
    GameJsonRef requirements;
} GameEffect;

extern const GameResourceDocumentEntry game_resource_documents[];
extern const size_t game_resource_document_count;
extern const GameResourceRecordEntry game_resource_records[];
extern const size_t game_resource_record_count;
extern const GameResourceSpawnGroupEntry game_resource_spawn_groups[];
extern const size_t game_resource_spawn_group_count;

bool game_resources_init(GameResources *resources, const char *pack_path);
void game_resources_dispose(GameResources *resources);
const GameResourceRecordEntry *game_resources_find(
    GameResourceType type,
    const char *id,
    size_t *matching_record_count
);
const GameResourceRecordEntry *game_resources_find_spawn_group(
    const char *spawn_group,
    size_t ordinal,
    size_t *group_size
);
bool game_resources_open_document(
    GameResources *resources,
    size_t document_index,
    GameJsonDocument *document
);
bool game_resources_open_record(
    GameResources *resources,
    const GameResourceRecordEntry *record,
    GameJsonDocument *document,
    GameJsonRef *value
);
bool game_resources_generate_drop_list(
    GameResources *resources,
    GameWorldState *world,
    const char *drop_list_id,
    const char *map_id,
    const char *object_id,
    int x,
    int y,
    bool is_container
);
bool game_resource_item_view(GameJsonRef raw, GameItemDefinition *definition);
bool game_resource_monster_view(GameJsonRef raw, GameMonsterDefinition *definition);
bool game_resource_quest_view(GameJsonRef raw, GameQuestDefinition *definition);
bool game_resource_conversation_view(GameJsonRef raw, GameConversationDefinition *definition);
bool game_resource_condition_view(GameJsonRef raw, GameConditionDefinition *definition);
bool game_resource_drop_list_view(GameJsonRef raw, GameDropListDefinition *definition);
bool game_resource_item_category_view(GameJsonRef raw, GameItemCategoryDefinition *definition);
bool game_resource_item_filter_view(GameJsonRef raw, GameItemFilterDefinition *definition);
bool game_resource_requirement_view(GameJsonRef raw, GameRequirement *requirement);
bool game_resource_effect_view(GameJsonRef raw, GameEffect *effect);

#endif