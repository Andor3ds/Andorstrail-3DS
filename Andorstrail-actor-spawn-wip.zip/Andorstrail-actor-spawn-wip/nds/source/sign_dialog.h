#ifndef ANDOR_SIGN_DIALOG_H
#define ANDOR_SIGN_DIALOG_H

void sign_dialog_show(const char *message);
int sign_dialog_handle_input(unsigned int keys);
int sign_dialog_is_active(void);
void sign_dialog_draw(void);

#endif