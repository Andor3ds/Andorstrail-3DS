#include "game_state.h"

#include <stdlib.h>
#include <string.h>

static char *copy_string(const char *text)
{
    if (text == NULL) return NULL;
    const size_t length = strlen(text) + 1;
    char *copy = malloc(length);
    if (copy != NULL) memcpy(copy, text, length);
    return copy;
}

static bool copy_identifier(char *destination, size_t capacity, const char *source)
{
    if (source == NULL) source = "";
    const size_t length = strlen(source);
    if (length >= capacity) return false;
    memcpy(destination, source, length + 1);
    return true;
}

static bool grow_array(void **items, size_t *capacity, size_t item_size, size_t minimum)
{
    if (*capacity >= minimum) return true;
    size_t new_capacity = *capacity == 0 ? 8 : *capacity;
    while (new_capacity < minimum) {
        if (new_capacity > SIZE_MAX / 2) return false;
        new_capacity *= 2;
    }
    if (item_size != 0 && new_capacity > SIZE_MAX / item_size) return false;
    void *resized = realloc(*items, new_capacity * item_size);
    if (resized == NULL) return false;
    *items = resized;
    *capacity = new_capacity;
    return true;
}

void game_player_init(GamePlayer *player, const char *name, const char *map_id, int x, int y)
{
    memset(player, 0, sizeof(*player));
    copy_identifier(player->name, sizeof(player->name), name);
    copy_identifier(player->player_id, sizeof(player->player_id), "player");
    copy_identifier(player->map_id, sizeof(player->map_id), map_id);
    copy_identifier(player->spawn_map_id, sizeof(player->spawn_map_id), map_id);
    copy_identifier(player->spawn_place_id, sizeof(player->spawn_place_id), "rest");
    player->x = x;
    player->y = y;
    player->level = 1;
    player->total_experience = 1;
    player->saved_version = 1;
    player->level_experience.current = 1;
    player->level_experience.maximum = 55;
    player->base_stats.max_hp = 25;
    player->base_stats.max_ap = 10;
    player->base_stats.move_cost = 6;
    player->base_stats.attack_cost = 10;
    player->base_stats.attack_chance = 60;
    player->base_stats.critical_multiplier = 1.0f;
    player->base_stats.min_damage = 1;
    player->base_stats.max_damage = 1;
    player->base_stats.block_chance = 9;
    player->base_stats.use_item_cost = 5;
    player->base_stats.reequip_cost = 5;
    player->hp.current = player->base_stats.max_hp;
    player->hp.maximum = player->base_stats.max_hp;
    player->ap.current = player->base_stats.max_ap;
    player->ap.maximum = player->base_stats.max_ap;
}

void game_player_dispose(GamePlayer *player)
{
    if (player == NULL) return;
    for (size_t index = 0; index < player->item_count; ++index) free(player->items[index].item_id);
    for (size_t index = 0; index < player->equipment_count; ++index) {
        free(player->equipment[index].slot_id);
        free(player->equipment[index].item_id);
    }
    for (size_t index = 0; index < player->condition_count; ++index) {
        free(player->conditions[index].condition_id);
    }
    for (size_t index = 0; index < player->quest_progress_count; ++index) {
        free(player->quest_progress[index].quest_id);
        free(player->quest_progress[index].stages);
    }
    free(player->items);
    free(player->equipment);
    free(player->conditions);
    free(player->quest_progress);
    game_named_values_dispose(&player->skill_levels);
    game_named_values_dispose(&player->alignments);
    game_named_values_dispose(&player->properties);
    memset(player, 0, sizeof(*player));
}

bool game_player_add_gold(GamePlayer *player, int amount)
{
    if (player == NULL || amount < 0 || player->gold > INT32_MAX - amount) return false;
    player->gold += amount;
    return true;
}

uint32_t game_player_item_quantity(const GamePlayer *player, const char *item_id)
{
    if (player == NULL || item_id == NULL) return 0;
    for (size_t index = 0; index < player->item_count; ++index) {
        if (strcmp(player->items[index].item_id, item_id) == 0) return player->items[index].quantity;
    }
    return 0;
}

bool game_player_add_item(GamePlayer *player, const char *item_id, uint32_t quantity)
{
    if (player == NULL || item_id == NULL || item_id[0] == '\0' || quantity == 0) return false;
    for (size_t index = 0; index < player->item_count; ++index) {
        GameInventoryItem *item = &player->items[index];
        if (strcmp(item->item_id, item_id) != 0) continue;
        if (UINT32_MAX - item->quantity < quantity) return false;
        item->quantity += quantity;
        return true;
    }
    if (!grow_array((void **)&player->items, &player->item_capacity,
            sizeof(*player->items), player->item_count + 1)) {
        return false;
    }
    char *owned_id = copy_string(item_id);
    if (owned_id == NULL) return false;
    GameInventoryItem *item = &player->items[player->item_count++];
    item->item_id = owned_id;
    item->quantity = quantity;
    return true;
}

bool game_player_remove_item(GamePlayer *player, const char *item_id, uint32_t quantity)
{
    if (player == NULL || item_id == NULL || quantity == 0) return false;
    for (size_t index = 0; index < player->item_count; ++index) {
        GameInventoryItem *item = &player->items[index];
        if (strcmp(item->item_id, item_id) != 0 || item->quantity < quantity) continue;
        item->quantity -= quantity;
        if (item->quantity != 0) return true;
        free(item->item_id);
        if (index + 1 < player->item_count) {
            memmove(item, item + 1, (player->item_count - index - 1) * sizeof(*item));
        }
        --player->item_count;
        return true;
    }
    return false;
}

bool game_player_equip(GamePlayer *player, const char *slot_id, const char *item_id)
{
    if (player == NULL || slot_id == NULL || slot_id[0] == '\0'
            || item_id == NULL || item_id[0] == '\0') return false;
    for (size_t index = 0; index < player->equipment_count; ++index) {
        GameEquippedItem *equipped = &player->equipment[index];
        if (strcmp(equipped->slot_id, slot_id) != 0) continue;
        char *replacement = copy_string(item_id);
        if (replacement == NULL) return false;
        free(equipped->item_id);
        equipped->item_id = replacement;
        return true;
    }
    if (!grow_array((void **)&player->equipment, &player->equipment_capacity,
            sizeof(*player->equipment), player->equipment_count + 1)) {
        return false;
    }
    char *owned_slot = copy_string(slot_id);
    char *owned_item = copy_string(item_id);
    if (owned_slot == NULL || owned_item == NULL) {
        free(owned_slot);
        free(owned_item);
        return false;
    }
    GameEquippedItem *equipped = &player->equipment[player->equipment_count++];
    equipped->slot_id = owned_slot;
    equipped->item_id = owned_item;
    return true;
}

bool game_player_unequip(GamePlayer *player, const char *slot_id)
{
    if (player == NULL || slot_id == NULL) return false;
    for (size_t index = 0; index < player->equipment_count; ++index) {
        GameEquippedItem *equipped = &player->equipment[index];
        if (strcmp(equipped->slot_id, slot_id) != 0) continue;
        free(equipped->slot_id);
        free(equipped->item_id);
        if (index + 1 < player->equipment_count) {
            memmove(equipped, equipped + 1,
                (player->equipment_count - index - 1) * sizeof(*equipped));
        }
        --player->equipment_count;
        return true;
    }
    return false;
}

uint32_t game_player_equipped_quantity(const GamePlayer *player, const char *item_id)
{
    uint32_t count = 0;
    if (player == NULL || item_id == NULL) return 0;
    for (size_t index = 0; index < player->equipment_count; ++index) {
        if (strcmp(player->equipment[index].item_id, item_id) == 0) ++count;
    }
    return count;
}

bool game_player_remove_equipped_item(GamePlayer *player, const char *item_id, uint32_t quantity)
{
    if (player == NULL || item_id == NULL || quantity == 0
            || game_player_equipped_quantity(player, item_id) < quantity) return false;
    uint32_t removed = 0;
    for (size_t index = player->equipment_count; index > 0 && removed < quantity; --index) {
        GameEquippedItem *item = &player->equipment[index - 1];
        if (strcmp(item->item_id, item_id) != 0) continue;
        game_player_unequip(player, item->slot_id);
        ++removed;
    }
    game_player_remove_item(player, item_id, quantity);
    return removed == quantity;
}

bool game_player_set_condition(
    GamePlayer *player,
    const char *condition_id,
    int magnitude,
    int remaining_duration
)
{
    if (player == NULL || condition_id == NULL || condition_id[0] == '\0') return false;
    for (size_t index = 0; index < player->condition_count; ++index) {
        GamePlayerCondition *condition = &player->conditions[index];
        if (strcmp(condition->condition_id, condition_id) != 0) continue;
        condition->magnitude = magnitude;
        condition->remaining_duration = remaining_duration;
        return true;
    }
    if (!grow_array((void **)&player->conditions, &player->condition_capacity,
            sizeof(*player->conditions), player->condition_count + 1)) {
        return false;
    }
    char *owned_id = copy_string(condition_id);
    if (owned_id == NULL) return false;
    GamePlayerCondition *condition = &player->conditions[player->condition_count++];
    condition->condition_id = owned_id;
    condition->magnitude = magnitude;
    condition->remaining_duration = remaining_duration;
    return true;
}

bool game_player_remove_condition(GamePlayer *player, const char *condition_id)
{
    if (player == NULL || condition_id == NULL) return false;
    for (size_t index = 0; index < player->condition_count; ++index) {
        GamePlayerCondition *condition = &player->conditions[index];
        if (strcmp(condition->condition_id, condition_id) != 0) continue;
        free(condition->condition_id);
        if (index + 1 < player->condition_count) {
            memmove(condition, condition + 1,
                (player->condition_count - index - 1) * sizeof(*condition));
        }
        --player->condition_count;
        return true;
    }
    return false;
}

static GameQuestProgress *find_quest_progress(GamePlayer *player, const char *quest_id)
{
    for (size_t index = 0; index < player->quest_progress_count; ++index) {
        if (strcmp(player->quest_progress[index].quest_id, quest_id) == 0) {
            return &player->quest_progress[index];
        }
    }
    return NULL;
}

bool game_player_add_quest_progress(GamePlayer *player, const char *quest_id, int stage)
{
    if (player == NULL || quest_id == NULL || quest_id[0] == '\0') return false;
    GameQuestProgress *progress = find_quest_progress(player, quest_id);
    if (progress == NULL) {
        if (!grow_array(
                (void **)&player->quest_progress,
                &player->quest_progress_capacity,
                sizeof(*player->quest_progress),
                player->quest_progress_count + 1)) {
            return false;
        }
        progress = &player->quest_progress[player->quest_progress_count];
        memset(progress, 0, sizeof(*progress));
        progress->quest_id = copy_string(quest_id);
        if (progress->quest_id == NULL) return false;
        ++player->quest_progress_count;
    }
    for (size_t index = 0; index < progress->stage_count; ++index) {
        if (progress->stages[index] == stage) return true;
    }
    if (!grow_array(
            (void **)&progress->stages,
            &progress->stage_capacity,
            sizeof(*progress->stages),
            progress->stage_count + 1)) {
        return false;
    }
    progress->stages[progress->stage_count++] = stage;
    return true;
}

bool game_player_has_quest_progress(const GamePlayer *player, const char *quest_id, int stage)
{
    if (player == NULL || quest_id == NULL) return false;
    for (size_t quest_index = 0; quest_index < player->quest_progress_count; ++quest_index) {
        const GameQuestProgress *progress = &player->quest_progress[quest_index];
        if (strcmp(progress->quest_id, quest_id) != 0) continue;
        for (size_t stage_index = 0; stage_index < progress->stage_count; ++stage_index) {
            if (progress->stages[stage_index] == stage) return true;
        }
        return false;
    }
    return false;
}

bool game_player_remove_quest_progress(GamePlayer *player, const char *quest_id, int stage)
{
    if (player == NULL || quest_id == NULL) return false;
    for (size_t quest_index = 0; quest_index < player->quest_progress_count; ++quest_index) {
        GameQuestProgress *progress = &player->quest_progress[quest_index];
        if (strcmp(progress->quest_id, quest_id) != 0) continue;
        for (size_t stage_index = 0; stage_index < progress->stage_count; ++stage_index) {
            if (progress->stages[stage_index] != stage) continue;
            if (stage_index + 1 < progress->stage_count) {
                memmove(&progress->stages[stage_index], &progress->stages[stage_index + 1],
                    (progress->stage_count - stage_index - 1) * sizeof(*progress->stages));
            }
            --progress->stage_count;
            if (progress->stage_count == 0) {
                free(progress->quest_id);
                free(progress->stages);
                if (quest_index + 1 < player->quest_progress_count) {
                    memmove(progress, progress + 1,
                        (player->quest_progress_count - quest_index - 1) * sizeof(*progress));
                }
                --player->quest_progress_count;
            }
            return true;
        }
        return false;
    }
    return false;
}

int game_player_latest_quest_progress(const GamePlayer *player, const char *quest_id)
{
    int latest = 0;
    if (player == NULL || quest_id == NULL) return latest;
    for (size_t quest_index = 0; quest_index < player->quest_progress_count; ++quest_index) {
        const GameQuestProgress *progress = &player->quest_progress[quest_index];
        if (strcmp(progress->quest_id, quest_id) != 0) continue;
        for (size_t stage_index = 0; stage_index < progress->stage_count; ++stage_index) {
            if (progress->stages[stage_index] > latest) latest = progress->stages[stage_index];
        }
        break;
    }
    return latest;
}

bool game_player_is_latest_quest_progress(const GamePlayer *player, const char *quest_id, int stage)
{
    return game_player_has_quest_progress(player, quest_id, stage)
        && game_player_latest_quest_progress(player, quest_id) == stage;
}

bool game_named_values_set(GameNamedValues *values, const char *name, int64_t value)
{
    if (values == NULL || name == NULL || name[0] == '\0') return false;
    for (size_t index = 0; index < values->count; ++index) {
        if (strcmp(values->values[index].name, name) == 0) {
            values->values[index].value = value;
            return true;
        }
    }
    if (!grow_array((void **)&values->values, &values->capacity,
            sizeof(*values->values), values->count + 1)) {
        return false;
    }
    char *owned_name = copy_string(name);
    if (owned_name == NULL) return false;
    values->values[values->count].name = owned_name;
    values->values[values->count].value = value;
    ++values->count;
    return true;
}

bool game_named_values_get(const GameNamedValues *values, const char *name, int64_t *value)
{
    if (values == NULL || name == NULL) return false;
    for (size_t index = 0; index < values->count; ++index) {
        if (strcmp(values->values[index].name, name) == 0) {
            if (value != NULL) *value = values->values[index].value;
            return true;
        }
    }
    return false;
}

bool game_named_values_remove(GameNamedValues *values, const char *name)
{
    if (values == NULL || name == NULL) return false;
    for (size_t index = 0; index < values->count; ++index) {
        if (strcmp(values->values[index].name, name) != 0) continue;
        free(values->values[index].name);
        if (index + 1 < values->count) {
            memmove(&values->values[index], &values->values[index + 1],
                (values->count - index - 1) * sizeof(*values->values));
        }
        --values->count;
        return true;
    }
    return false;
}

void game_named_values_dispose(GameNamedValues *values)
{
    if (values == NULL) return;
    for (size_t index = 0; index < values->count; ++index) free(values->values[index].name);
    free(values->values);
    memset(values, 0, sizeof(*values));
}

void game_world_init(GameWorldState *world, const char *map_id)
{
    memset(world, 0, sizeof(*world));
    copy_identifier(world->current_map_id, sizeof(world->current_map_id), map_id);
}

void game_world_dispose(GameWorldState *world)
{
    if (world == NULL) return;
    game_named_values_dispose(&world->flags);
    for (size_t index = 0; index < world->map_count; ++index) free(world->maps[index].map_id);
    for (size_t index = 0; index < world->object_count; ++index) {
        free(world->objects[index].map_id);
        free(world->objects[index].event_id);
    }
    for (size_t index = 0; index < world->timer_count; ++index) free(world->timers[index].name);
    for (size_t index = 0; index < world->loot_bag_count; ++index) {
        GameWorldLootBag *bag = &world->loot_bags[index];
        free(bag->map_id);
        free(bag->object_id);
        for (size_t item_index = 0; item_index < bag->item_count; ++item_index) {
            free(bag->items[item_index].item_id);
        }
        free(bag->items);
    }
    for (size_t index = 0; index < world->actor_count; ++index) {
        GameActorState *actor = &world->actors[index];
        free(actor->actor_id);
        free(actor->map_id);
        free(actor->spawn_area_id);
        free(actor->monster_type_id);
        free(actor->name);
        free(actor->phrase_id);
        free(actor->faction);
        free(actor->icon_id);
        free(actor->monster_class);
        free(actor->aggression_type);
    }
    free(world->maps);
    free(world->objects);
    free(world->timers);
    free(world->loot_bags);
    free(world->actors);
    memset(world, 0, sizeof(*world));
}

void game_world_tick(GameWorldState *world, uint64_t ticks)
{
    if (world != NULL && UINT64_MAX - world->world_time >= ticks) world->world_time += ticks;
}

GameMapState *game_world_map_state(GameWorldState *world, const char *map_id, bool create)
{
    if (world == NULL || map_id == NULL || map_id[0] == '\0') return NULL;
    for (size_t index = 0; index < world->map_count; ++index) {
        if (strcmp(world->maps[index].map_id, map_id) == 0) return &world->maps[index];
    }
    if (!create || !grow_array((void **)&world->maps, &world->map_capacity,
            sizeof(*world->maps), world->map_count + 1)) {
        return NULL;
    }
    char *owned_id = copy_string(map_id);
    if (owned_id == NULL) return NULL;
    GameMapState *map = &world->maps[world->map_count++];
    memset(map, 0, sizeof(*map));
    map->map_id = owned_id;
    return map;
}

GameObjectState *game_world_object_state(
    GameWorldState *world,
    const char *map_id,
    const char *event_id,
    uint8_t type,
    int x,
    int y,
    bool create
)
{
    if (world == NULL || map_id == NULL || event_id == NULL) return NULL;
    for (size_t index = 0; index < world->object_count; ++index) {
        GameObjectState *object = &world->objects[index];
        if (object->type == type && object->x == x && object->y == y
                && strcmp(object->map_id, map_id) == 0
                && strcmp(object->event_id, event_id) == 0) {
            return object;
        }
    }
    if (!create || !grow_array((void **)&world->objects, &world->object_capacity,
            sizeof(*world->objects), world->object_count + 1)) {
        return NULL;
    }
    char *owned_map_id = copy_string(map_id);
    char *owned_event_id = copy_string(event_id);
    if (owned_map_id == NULL || owned_event_id == NULL) {
        free(owned_map_id);
        free(owned_event_id);
        return NULL;
    }
    GameObjectState *object = &world->objects[world->object_count++];
    memset(object, 0, sizeof(*object));
    object->map_id = owned_map_id;
    object->event_id = owned_event_id;
    object->type = type;
    object->x = x;
    object->y = y;
    object->active = true;
    return object;
}

bool game_world_set_timer(GameWorldState *world, const char *name)
{
    if (world == NULL || name == NULL || name[0] == '\0') return false;
    for (size_t index = 0; index < world->timer_count; ++index) {
        if (strcmp(world->timers[index].name, name) == 0) {
            world->timers[index].started_at_tick = world->world_time;
            world->timers[index].active = true;
            return true;
        }
    }
    if (!grow_array((void **)&world->timers, &world->timer_capacity,
            sizeof(*world->timers), world->timer_count + 1)) {
        return false;
    }
    char *owned_name = copy_string(name);
    if (owned_name == NULL) return false;
    GameWorldTimer *timer = &world->timers[world->timer_count++];
    timer->name = owned_name;
    timer->started_at_tick = world->world_time;
    timer->active = true;
    return true;
}

bool game_world_timer_elapsed(const GameWorldState *world, const char *name, uint64_t duration)
{
    if (world == NULL || name == NULL) return false;
    for (size_t index = 0; index < world->timer_count; ++index) {
        const GameWorldTimer *timer = &world->timers[index];
        if (strcmp(timer->name, name) == 0) {
            return timer->active && world->world_time >= timer->started_at_tick
                && world->world_time - timer->started_at_tick >= duration;
        }
    }
    return false;
}

GameWorldLootBag *game_world_loot_bag(
    GameWorldState *world,
    const char *map_id,
    const char *object_id,
    int x,
    int y,
    bool is_container,
    bool create
)
{
    if (world == NULL || map_id == NULL || object_id == NULL) return NULL;
    for (size_t index = 0; index < world->loot_bag_count; ++index) {
        GameWorldLootBag *bag = &world->loot_bags[index];
        if (bag->x == x && bag->y == y
                && strcmp(bag->map_id, map_id) == 0
                && strcmp(bag->object_id, object_id) == 0) return bag;
    }
    if (!create || !grow_array((void **)&world->loot_bags, &world->loot_bag_capacity,
            sizeof(*world->loot_bags), world->loot_bag_count + 1)) {
        return NULL;
    }
    char *owned_map_id = copy_string(map_id);
    char *owned_object_id = copy_string(object_id);
    if (owned_map_id == NULL || owned_object_id == NULL) {
        free(owned_map_id);
        free(owned_object_id);
        return NULL;
    }
    GameWorldLootBag *bag = &world->loot_bags[world->loot_bag_count++];
    memset(bag, 0, sizeof(*bag));
    bag->map_id = owned_map_id;
    bag->object_id = owned_object_id;
    bag->x = x;
    bag->y = y;
    bag->is_container = is_container;
    return bag;
}

bool game_world_clear_loot_bag(GameWorldLootBag *bag)
{
    if (bag == NULL) return false;
    for (size_t index = 0; index < bag->item_count; ++index) free(bag->items[index].item_id);
    free(bag->items);
    bag->items = NULL;
    bag->item_count = 0;
    bag->item_capacity = 0;
    bag->gold = 0;
    return true;
}

bool game_world_loot_bag_add_item(GameWorldLootBag *bag, const char *item_id, uint32_t quantity)
{
    if (bag == NULL || item_id == NULL || item_id[0] == '\0' || quantity == 0) return false;
    for (size_t index = 0; index < bag->item_count; ++index) {
        GameInventoryItem *item = &bag->items[index];
        if (strcmp(item->item_id, item_id) != 0) continue;
        if (UINT32_MAX - item->quantity < quantity) return false;
        item->quantity += quantity;
        return true;
    }
    if (!grow_array((void **)&bag->items, &bag->item_capacity,
            sizeof(*bag->items), bag->item_count + 1)) return false;
    char *owned_id = copy_string(item_id);
    if (owned_id == NULL) return false;
    GameInventoryItem *item = &bag->items[bag->item_count++];
    item->item_id = owned_id;
    item->quantity = quantity;
    return true;
}

GameActorState *game_world_actor_at(GameWorldState *world, const char *map_id, int x, int y)
{
    if (world == NULL || map_id == NULL) return NULL;
    for (size_t index = 0; index < world->actor_count; ++index) {
        GameActorState *actor = &world->actors[index];
        if (actor->is_alive && actor->x == x && actor->y == y
                && strcmp(actor->map_id, map_id) == 0) return actor;
    }
    return NULL;
}

bool game_world_add_actor(GameWorldState *world, const GameActorState *actor)
{
    if (world == NULL || actor == NULL || actor->actor_id == NULL || actor->map_id == NULL
            || actor->monster_type_id == NULL) return false;
    for (size_t index = 0; index < world->actor_count; ++index) {
        if (strcmp(world->actors[index].actor_id, actor->actor_id) == 0) return true;
    }
    if (!grow_array((void **)&world->actors, &world->actor_capacity,
            sizeof(*world->actors), world->actor_count + 1)) return false;
    GameActorState copy = *actor;
    copy.actor_id = copy_string(actor->actor_id);
    copy.map_id = copy_string(actor->map_id);
    copy.spawn_area_id = copy_string(actor->spawn_area_id != NULL ? actor->spawn_area_id : "");
    copy.monster_type_id = copy_string(actor->monster_type_id);
    copy.name = copy_string(actor->name != NULL ? actor->name : "");
    copy.phrase_id = copy_string(actor->phrase_id != NULL ? actor->phrase_id : "");
    copy.faction = copy_string(actor->faction != NULL ? actor->faction : "");
        copy.icon_id = copy_string(actor->icon_id != NULL ? actor->icon_id : "");
        copy.monster_class = copy_string(actor->monster_class != NULL ? actor->monster_class : "humanoid");
        copy.aggression_type = copy_string(actor->aggression_type != NULL ? actor->aggression_type : "none");
    if (copy.actor_id == NULL || copy.map_id == NULL || copy.spawn_area_id == NULL
            || copy.monster_type_id == NULL || copy.name == NULL
            || copy.phrase_id == NULL || copy.faction == NULL || copy.icon_id == NULL
            || copy.monster_class == NULL || copy.aggression_type == NULL) {
        free(copy.actor_id);
        free(copy.map_id);
        free(copy.spawn_area_id);
        free(copy.monster_type_id);
        free(copy.name);
        free(copy.phrase_id);
        free(copy.faction);
        free(copy.icon_id);
        free(copy.monster_class);
        free(copy.aggression_type);
        return false;
    }
    world->actors[world->actor_count++] = copy;
    return true;
}

void game_runtime_state_init(
    GameRuntimeState *state,
    const char *player_name,
    const char *starting_map_id,
    int starting_x,
    int starting_y
)
{
    memset(state, 0, sizeof(*state));
    game_player_init(&state->player, player_name, starting_map_id, starting_x, starting_y);
    game_world_init(&state->world, starting_map_id);
}

void game_runtime_state_dispose(GameRuntimeState *state)
{
    if (state == NULL) return;
    game_player_dispose(&state->player);
    game_world_dispose(&state->world);
}