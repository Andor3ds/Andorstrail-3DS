#include "game_resources.h"

#include "game_resource_index.h"

#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

static bool read_integer(GameJsonRef object, const char *key, int *value)
{
    int64_t parsed;
    if (!game_json_integer(game_json_object_get(object, key), &parsed)
            || parsed < INT32_MIN || parsed > INT32_MAX) return false;
    *value = (int)parsed;
    return true;
}

static int integer_or_default(GameJsonRef object, const char *key, int fallback)
{
    int value;
    return read_integer(object, key, &value) ? value : fallback;
}

static double number_or_default(GameJsonRef object, const char *key, double fallback)
{
    double value;
    return game_json_number(game_json_object_get(object, key), &value) ? value : fallback;
}

static bool ref_present(GameJsonRef value)
{
    return value.document != NULL && value.node < value.document->node_count;
}

static bool has_object_id(GameJsonRef raw)
{
    char id[GAME_RESOURCE_ID_CAPACITY];
    return game_json_string_copy(game_json_object_get(raw, "id"), id, sizeof(id)) && id[0] != '\0';
}

static bool inflate_resource(
    GameResources *resources,
    const GameResourceDocumentEntry *entry,
    GameJsonDocument *document
)
{
    if (resources == NULL || resources->pack == NULL || entry == NULL || document == NULL) return false;
    if (fseek(resources->pack, (long)entry->offset, SEEK_SET) != 0) return false;
    unsigned char *compressed = malloc(entry->compressed_size);
    char *source = malloc((size_t)entry->source_size + 1);
    if (compressed == NULL || source == NULL) {
        free(compressed);
        free(source);
        return false;
    }
    const size_t read_size = fread(compressed, 1, entry->compressed_size, resources->pack);
    if (read_size != entry->compressed_size) {
        free(compressed);
        free(source);
        return false;
    }
    uLongf source_size = entry->source_size;
    const int status = uncompress(
        (Bytef *)source, &source_size, compressed, entry->compressed_size
    );
    free(compressed);
    if (status != Z_OK || source_size != entry->source_size) {
        free(source);
        return false;
    }
    if (!game_json_parse_owned(source, entry->source_size, document)) return false;
    return true;
}

bool game_resources_init(GameResources *resources, const char *pack_path)
{
    if (resources == NULL || pack_path == NULL) return false;
    memset(resources, 0, sizeof(*resources));
    FILE *pack = fopen(pack_path, "rb");
    if (pack == NULL) return false;
    if (fseek(pack, 0, SEEK_END) != 0) {
        fclose(pack);
        return false;
    }
    const long pack_size = ftell(pack);
    uint64_t required_size = 0;
    for (size_t index = 0; index < game_resource_document_count; ++index) {
        const GameResourceDocumentEntry *entry = &game_resource_documents[index];
        const uint64_t end = (uint64_t)entry->offset + entry->compressed_size;
        if (end > required_size) required_size = end;
    }
    if (pack_size < 0 || (uint64_t)pack_size < required_size || fseek(pack, 0, SEEK_SET) != 0) {
        fclose(pack);
        return false;
    }
    resources->pack = pack;
    return true;
}

void game_resources_dispose(GameResources *resources)
{
    if (resources == NULL) return;
    if (resources->pack != NULL) fclose(resources->pack);
    resources->pack = NULL;
}

static int compare_record_key(const GameResourceRecordEntry *record, GameResourceType type, const char *id)
{
    if (record->type != type) return record->type < type ? -1 : 1;
    return strcmp(record->id, id);
}

const GameResourceRecordEntry *game_resources_find(
    GameResourceType type,
    const char *id,
    size_t *matching_record_count
)
{
    if (matching_record_count != NULL) *matching_record_count = 0;
    if (id == NULL) return NULL;
    size_t low = 0;
    size_t high = game_resource_record_count;
    while (low < high) {
        const size_t middle = low + (high - low) / 2;
        if (compare_record_key(&game_resource_records[middle], type, id) < 0) low = middle + 1;
        else high = middle;
    }
    if (low >= game_resource_record_count
            || compare_record_key(&game_resource_records[low], type, id) != 0) return NULL;
    size_t end = low + 1;
    while (end < game_resource_record_count
            && compare_record_key(&game_resource_records[end], type, id) == 0) {
        ++end;
    }
    if (matching_record_count != NULL) *matching_record_count = end - low;
    return &game_resource_records[low];
}

const GameResourceRecordEntry *game_resources_find_spawn_group(
    const char *spawn_group,
    size_t ordinal,
    size_t *group_size
)
{
    if (group_size != NULL) *group_size = 0;
    if (spawn_group == NULL) return NULL;
    const GameResourceRecordEntry *selected = NULL;
    size_t count = 0;
    for (size_t index = 0; index < game_resource_spawn_group_count; ++index) {
        const GameResourceSpawnGroupEntry *entry = &game_resource_spawn_groups[index];
        if (strcmp(entry->spawn_group, spawn_group) != 0) continue;
        if (count == ordinal) selected = entry->record;
        ++count;
    }
    if (group_size != NULL) *group_size = count;
    return selected;
}

bool game_resources_open_document(
    GameResources *resources,
    size_t document_index,
    GameJsonDocument *document
)
{
    if (document_index >= game_resource_document_count) return false;
    return inflate_resource(resources, &game_resource_documents[document_index], document);
}

bool game_resources_open_record(
    GameResources *resources,
    const GameResourceRecordEntry *record,
    GameJsonDocument *document,
    GameJsonRef *value
)
{
    if (record == NULL || document == NULL || value == NULL
            || !game_resources_open_document(resources, record->document_index, document)) return false;
    const GameJsonRef root = game_json_root(document);
    *value = game_json_array_get(root, record->record_index);
    if (value->node == GAME_JSON_NO_NODE || !has_object_id(*value)) {
        game_json_dispose(document);
        return false;
    }
    return true;
}

static bool parse_chance(const char *text, unsigned int *numerator, unsigned int *denominator)
{
    if (text == NULL || text[0] == '\0') return false;
    char *separator = strchr(text, '/');
    if (separator == NULL) {
        char *end = NULL;
        const long value = strtol(text, &end, 10);
        if (end == text || *end != '\0' || value < 0 || value > 100) return false;
        *numerator = (unsigned int)value;
        *denominator = 100;
        return true;
    }
    char top[16];
    const size_t top_length = (size_t)(separator - text);
    if (top_length == 0 || top_length >= sizeof(top) || separator[1] == '\0') return false;
    memcpy(top, text, top_length);
    top[top_length] = '\0';
    char *top_end = NULL;
    char *bottom_end = NULL;
    const long top_value = strtol(top, &top_end, 10);
    const long bottom_value = strtol(separator + 1, &bottom_end, 10);
    if (*top_end != '\0' || *bottom_end != '\0' || top_value < 0
            || bottom_value <= 0 || top_value > bottom_value
            || bottom_value > UINT_MAX) return false;
    *numerator = (unsigned int)top_value;
    *denominator = (unsigned int)bottom_value;
    return true;
}

static bool add_drop_item(GameWorldLootBag *bag, const char *item_id, uint32_t quantity)
{
    if (strcmp(item_id, "gold") == 0) {
        if (quantity > INT_MAX || bag->gold > INT_MAX - (int)quantity) return false;
        bag->gold += (int)quantity;
        return true;
    }
    return game_world_loot_bag_add_item(bag, item_id, quantity);
}

static uint32_t random_below(uint32_t bound)
{
    const uint64_t domain = (uint64_t)RAND_MAX + 1;
    if (bound <= 1) return 0;
    if (bound > domain) return (uint32_t)((uint64_t)(unsigned int)rand() * bound / domain);
    const uint64_t limit = domain - domain % bound;
    uint64_t sample;
    do {
        sample = (unsigned int)rand();
    } while (sample >= limit);
    return (uint32_t)(sample % bound);
}

bool game_resources_generate_drop_list(
    GameResources *resources,
    GameWorldState *world,
    const char *drop_list_id,
    const char *map_id,
    const char *object_id,
    int x,
    int y,
    bool is_container
)
{
    if (resources == NULL || world == NULL || drop_list_id == NULL
            || map_id == NULL || object_id == NULL) return false;
    if (game_world_loot_bag(world, map_id, object_id, x, y, is_container, false) != NULL) return true;

    size_t match_count = 0;
    const GameResourceRecordEntry *record = game_resources_find(
        GAME_RESOURCE_DROP_LIST, drop_list_id, &match_count
    );
    if (record == NULL || match_count == 0) return false;
    GameJsonDocument document;
    GameJsonRef raw;
    if (!game_resources_open_record(resources, record, &document, &raw)) return false;
    GameDropListDefinition definition;
    if (!game_resource_drop_list_view(raw, &definition)) {
        game_json_dispose(&document);
        return false;
    }
    GameWorldLootBag *bag = game_world_loot_bag(
        world, map_id, object_id, x, y, is_container, true
    );
    if (bag == NULL) {
        game_json_dispose(&document);
        return false;
    }

    for (size_t index = 0; index < game_json_array_size(definition.items); ++index) {
        const GameJsonRef item = game_json_array_get(definition.items, index);
        char item_id[GAME_RESOURCE_ID_CAPACITY];
        char chance[32];
        int64_t minimum;
        int64_t maximum;
        if (!game_json_string_copy(game_json_object_get(item, "itemID"), item_id, sizeof(item_id))
                || !game_json_string_copy(game_json_object_get(item, "chance"), chance, sizeof(chance))
                || !game_json_integer(game_json_object_get(game_json_object_get(item, "quantity"), "min"), &minimum)
                || !game_json_integer(game_json_object_get(game_json_object_get(item, "quantity"), "max"), &maximum)
                || minimum < 0 || maximum < minimum || maximum > UINT32_MAX) {
            game_json_dispose(&document);
            return false;
        }
        unsigned int numerator;
        unsigned int denominator;
        if (!parse_chance(chance, &numerator, &denominator)) {
            game_json_dispose(&document);
            return false;
        }
        if (numerator == 0 || (numerator < denominator && random_below(denominator) >= numerator)) {
            continue;
        }
        const uint64_t range = (uint64_t)(maximum - minimum) + 1;
        const uint32_t quantity = (uint32_t)(minimum + random_below((uint32_t)range));
        if (quantity > 0 && !add_drop_item(bag, item_id, quantity)) {
            game_json_dispose(&document);
            return false;
        }
    }
    game_json_dispose(&document);
    return true;
}

bool game_resource_item_view(GameJsonRef raw, GameItemDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->name = game_json_object_get(raw, "name");
    definition->description = game_json_object_get(raw, "description");
    definition->icon_id = game_json_object_get(raw, "iconID");
    definition->category = game_json_object_get(raw, "category");
    definition->equip_effect = game_json_object_get(raw, "equipEffect");
    definition->use_effect = game_json_object_get(raw, "useEffect");
    definition->hit_effect = game_json_object_get(raw, "hitEffect");
    definition->miss_effect = game_json_object_get(raw, "missEffect");
    definition->kill_effect = game_json_object_get(raw, "killEffect");
    definition->hit_received_effect = game_json_object_get(raw, "hitReceivedEffect");
    definition->miss_received_effect = game_json_object_get(raw, "missReceivedEffect");
    definition->base_market_cost = integer_or_default(raw, "baseMarketCost", 0);
    definition->has_manual_price = integer_or_default(raw, "hasManualPrice", 0) > 0;
    return true;
}

bool game_resource_monster_view(GameJsonRef raw, GameMonsterDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->name = game_json_object_get(raw, "name");
    definition->icon_id = game_json_object_get(raw, "iconID");
    definition->spawn_group = game_json_object_get(raw, "spawnGroup");
    definition->phrase_id = game_json_object_get(raw, "phraseID");
    definition->attack_damage = game_json_object_get(raw, "attackDamage");
    definition->drop_list_id = game_json_object_get(raw, "droplistID");
    definition->movement_aggression = game_json_object_get(raw, "movementAggressionType");
    definition->monster_class = game_json_object_get(raw, "monsterClass");
    definition->faction = game_json_object_get(raw, "faction");
    definition->is_unique = integer_or_default(raw, "unique", 0) > 0;
    definition->critical_skill = integer_or_default(raw, "criticalSkill", 0);
    definition->critical_multiplier = number_or_default(raw, "criticalMultiplier", 0.0);
    definition->block_chance = integer_or_default(raw, "blockChance", 0);
    definition->damage_resistance = integer_or_default(raw, "damageResistance", 0);
    definition->max_hp = integer_or_default(raw, "maxHP", 1);
    definition->max_ap = integer_or_default(raw, "maxAP", 10);
    definition->move_cost = integer_or_default(raw, "moveCost", 10);
    definition->attack_cost = integer_or_default(raw, "attackCost", 10);
    definition->attack_chance = integer_or_default(raw, "attackChance", 0);
    return true;
}

bool game_resource_quest_view(GameJsonRef raw, GameQuestDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->name = game_json_object_get(raw, "name");
    definition->stages = game_json_object_get(raw, "stages");
    definition->show_in_log = integer_or_default(raw, "showInLog", 0) != 0;
    return true;
}

bool game_resource_conversation_view(GameJsonRef raw, GameConversationDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->message = game_json_object_get(raw, "message");
    definition->replies = game_json_object_get(raw, "replies");
    definition->rewards = game_json_object_get(raw, "rewards");
    definition->switch_to_npc = game_json_object_get(raw, "switchToNPC");
    return true;
}

bool game_resource_condition_view(GameJsonRef raw, GameConditionDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->name = game_json_object_get(raw, "name");
    definition->description = game_json_object_get(raw, "description");
    definition->icon_id = game_json_object_get(raw, "iconID");
    definition->category = game_json_object_get(raw, "category");
    definition->round_effect = game_json_object_get(raw, "roundEffect");
    definition->ability_effect = game_json_object_get(raw, "abilityEffect");
    definition->is_stacking = integer_or_default(raw, "isStacking", 0) != 0;
    definition->is_positive = integer_or_default(raw, "isPositive", 0) != 0;
    return true;
}

bool game_resource_drop_list_view(GameJsonRef raw, GameDropListDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->items = game_json_object_get(raw, "items");
    return true;
}

bool game_resource_item_category_view(GameJsonRef raw, GameItemCategoryDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->name = game_json_object_get(raw, "name");
    definition->action_type = game_json_object_get(raw, "actionType");
    definition->size = game_json_object_get(raw, "size");
    definition->inventory_slot = game_json_object_get(raw, "inventorySlot");
    return true;
}

bool game_resource_item_filter_view(GameJsonRef raw, GameItemFilterDefinition *definition)
{
    if (definition == NULL || !has_object_id(raw)) return false;
    memset(definition, 0, sizeof(*definition));
    definition->raw = raw;
    definition->id = game_json_object_get(raw, "id");
    definition->include_tags = game_json_object_get(raw, "includeTags");
    definition->exclude_tags = game_json_object_get(raw, "excludeTags");
    return true;
}

bool game_resource_requirement_view(GameJsonRef raw, GameRequirement *requirement)
{
    if (requirement == NULL || !ref_present(raw)) return false;
    memset(requirement, 0, sizeof(*requirement));
    requirement->raw = raw;
    requirement->type = game_json_object_get(raw, "requireType");
    requirement->id = game_json_object_get(raw, "requireID");
    requirement->value = game_json_object_get(raw, "value");
    requirement->negate = game_json_object_get(raw, "negate");
    char type[32];
    return game_json_string_copy(requirement->type, type, sizeof(type));
}

bool game_resource_effect_view(GameJsonRef raw, GameEffect *effect)
{
    if (effect == NULL || !ref_present(raw)) return false;
    memset(effect, 0, sizeof(*effect));
    effect->raw = raw;
    effect->type = game_json_object_get(raw, "rewardType");
    effect->id = game_json_object_get(raw, "rewardID");
    effect->value = game_json_object_get(raw, "value");
    effect->map_name = game_json_object_get(raw, "mapName");
    effect->requirements = game_json_object_get(raw, "requires");
    char type[40];
    return game_json_string_copy(effect->type, type, sizeof(type));
}