#ifndef ANDOR_GAME_CONVERSATION_H
#define ANDOR_GAME_CONVERSATION_H

#include "game_resources.h"
#include "game_state.h"

#include <stdbool.h>

#define GAME_CONVERSATION_MAX_PENDING_REQUIREMENTS 16

typedef struct {
    char type[40];
    char id[GAME_RESOURCE_ID_CAPACITY];
    int64_t value;
    bool negated;
} GameConversationPendingRequirement;

typedef struct {
    char actor_id[GAME_STATE_ID_CAPACITY];
    char phrase_id[GAME_STATE_ID_CAPACITY];
    char next_phrase_id[GAME_STATE_ID_CAPACITY];
    bool active;
    bool waiting_for_reply;
    GameConversationPendingRequirement pending_requirements[GAME_CONVERSATION_MAX_PENDING_REQUIREMENTS];
    size_t pending_requirement_count;
} GameConversationSession;

bool game_conversation_start(
    GameConversationSession *session,
    GameResources *resources,
    GamePlayer *player,
    GameWorldState *world,
    const char *actor_id,
    const char *phrase_id,
    char *message,
    size_t message_capacity
);
bool game_conversation_continue(
    GameConversationSession *session,
    GameResources *resources,
    GamePlayer *player,
    GameWorldState *world,
    char *message,
    size_t message_capacity
);
void game_conversation_end(GameConversationSession *session);

#endif