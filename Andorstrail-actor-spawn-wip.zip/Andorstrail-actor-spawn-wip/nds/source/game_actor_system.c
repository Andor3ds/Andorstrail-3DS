#include "game_actor_system.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int position_is_free(
    GameWorldState *world,
    const char *map_name,
    int map_width,
    int map_height,
    const unsigned char *walkable,
    int player_x,
    int player_y,
    const MapPlace *places,
    size_t place_count,
    const MapSpawnArea *area,
    int x,
    int y
)
{
    if (x < 0 || x >= map_width || y < 0 || y >= map_height
            || !walkable[y * map_width + x]
            || (x == player_x && y == player_y)
            || game_world_actor_at(world, map_name, x, y) != NULL) return 0;
    if (area->ignore_areas) return 1;
    for (size_t index = 0; index < place_count; ++index) {
        const MapPlace *place = &places[index];
        if (place->type != MAP_PLACE_MAPCHANGE && place->type != MAP_PLACE_KEY
                && place->type != MAP_PLACE_REST) continue;
        if (x >= place->x && y >= place->y
                && x < place->x + place->width && y < place->y + place->height) return 0;
    }
    return 1;
}

bool game_actor_spawn_map(
    GameResources *resources,
    GameRuntimeState *state,
    const char *map_name,
    int map_width,
    int map_height,
    const unsigned char *walkable,
    int player_x,
    int player_y,
    const MapPlace *places,
    size_t place_count,
    const MapSpawnArea *spawn_areas,
    size_t spawn_area_count
)
{
    if (resources == NULL || state == NULL || map_name == NULL || walkable == NULL
            || spawn_areas == NULL) return false;
    for (size_t area_index = 0; area_index < spawn_area_count; ++area_index) {
        const MapSpawnArea *area = &spawn_areas[area_index];
        if (strcmp(area->map_name, map_name) != 0 || !area->active
                || area->quantity == 0 || area->width == 0 || area->height == 0) continue;
        size_t group_size = 0;
        game_resources_find_spawn_group(area->spawn_group, 0, &group_size);
        if (group_size == 0) continue;
        for (unsigned int quantity = 0; quantity < area->quantity; ++quantity) {
            const GameResourceRecordEntry *record = game_resources_find_spawn_group(
                area->spawn_group, (size_t)rand() % group_size, NULL
            );
            GameJsonDocument document;
            GameJsonRef raw;
            if (record == NULL || !game_resources_open_record(resources, record, &document, &raw)) {
                continue;
            }
            GameMonsterDefinition definition;
            GameActorState actor = {0};
            char actor_id[GAME_RESOURCE_ID_CAPACITY * 2];
            char monster_id[GAME_RESOURCE_ID_CAPACITY];
            char actor_name[GAME_RESOURCE_ID_CAPACITY];
            char phrase_id[GAME_RESOURCE_ID_CAPACITY];
            char faction[GAME_RESOURCE_ID_CAPACITY];
            char icon_id[GAME_RESOURCE_ID_CAPACITY];
            char monster_class[40];
            char aggression[40];
            int64_t min_damage = 0;
            int64_t max_damage = 0;
            const GameJsonRef damage = game_json_object_get(raw, "attackDamage");
            const int valid = game_resource_monster_view(raw, &definition)
                && game_json_string_copy(definition.id, monster_id, sizeof(monster_id))
                && game_json_string_copy(definition.name, actor_name, sizeof(actor_name))
                && (definition.phrase_id.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.phrase_id, phrase_id, sizeof(phrase_id)))
                && (definition.faction.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.faction, faction, sizeof(faction)))
                && (definition.icon_id.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.icon_id, icon_id, sizeof(icon_id)))
                && (definition.monster_class.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.monster_class, monster_class, sizeof(monster_class)))
                && (definition.movement_aggression.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.movement_aggression, aggression, sizeof(aggression)));
            if (!valid) {
                game_json_dispose(&document);
                continue;
            }
            if (definition.phrase_id.node == GAME_JSON_NO_NODE) phrase_id[0] = '\0';
            if (definition.faction.node == GAME_JSON_NO_NODE) faction[0] = '\0';
            if (definition.icon_id.node == GAME_JSON_NO_NODE) icon_id[0] = '\0';
            if (definition.monster_class.node == GAME_JSON_NO_NODE) strcpy(monster_class, "humanoid");
            if (definition.movement_aggression.node == GAME_JSON_NO_NODE) strcpy(aggression, "none");
            game_json_integer(game_json_object_get(damage, "min"), &min_damage);
            game_json_integer(game_json_object_get(damage, "max"), &max_damage);
            game_json_dispose(&document);

            int actor_x = -1;
            int actor_y = -1;
            for (unsigned int attempt = 0; attempt < 100; ++attempt) {
                const int x = area->x + rand() % area->width;
                const int y = area->y + rand() % area->height;
                if (!position_is_free(
                        &state->world, map_name, map_width, map_height, walkable,
                        player_x, player_y,
                        places, place_count, area, x, y)) continue;
                actor_x = x;
                actor_y = y;
                break;
            }
            if (actor_x < 0) continue;

            snprintf(actor_id, sizeof(actor_id), "%s/%s/%u", map_name, area->name, quantity);
            actor.actor_id = actor_id;
            actor.map_id = (char *)map_name;
            actor.spawn_area_id = (char *)area->name;
            actor.monster_type_id = monster_id;
            actor.name = actor_name;
            actor.phrase_id = phrase_id;
            actor.faction = faction;
            actor.icon_id = icon_id;
            actor.monster_class = monster_class;
            actor.aggression_type = aggression;
            actor.x = actor_x;
            actor.y = actor_y;
            actor.hp = actor.max_hp = definition.max_hp;
            actor.ap = actor.max_ap = definition.max_ap;
            actor.move_cost = definition.move_cost;
            actor.attack_cost = definition.attack_cost;
            actor.attack_chance = definition.attack_chance;
            actor.critical_skill = definition.critical_skill;
            actor.critical_multiplier = definition.critical_multiplier;
            actor.min_damage = (int)min_damage;
            actor.max_damage = (int)max_damage;
            actor.block_chance = definition.block_chance;
            actor.damage_resistance = definition.damage_resistance;
            actor.is_alive = true;
            actor.is_unique = definition.is_unique;
            int64_t faction_score = 0;
            if (faction[0] != '\0') game_named_values_get(&state->player.alignments, faction, &faction_score);
            actor.is_hostile = phrase_id[0] == '\0' || faction_score < 0;
            if (!game_world_add_actor(&state->world, &actor)) return false;
        }
    }
    return true;
}