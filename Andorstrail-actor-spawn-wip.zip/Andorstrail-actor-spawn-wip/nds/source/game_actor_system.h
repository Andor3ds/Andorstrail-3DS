#ifndef ANDOR_GAME_ACTOR_SYSTEM_H
#define ANDOR_GAME_ACTOR_SYSTEM_H

#include "game_resources.h"
#include "game_state.h"
#include "map_data.h"

#include <stdbool.h>
#include <stddef.h>

bool game_actor_spawn_map(
    GameResources *resources,
    GameRuntimeState *state,
    const char *map_name,
    int map_width,
    int map_height,
    const unsigned char *walkable,
    int player_x,
    int player_y,
    const MapPlace *places,
    size_t place_count,
    const MapSpawnArea *spawn_areas,
    size_t spawn_area_count
);

#endif