#ifndef ANDOR_GAME_REQUIREMENTS_H
#define ANDOR_GAME_REQUIREMENTS_H

#include "game_state.h"

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    const char *type;
    const char *id;
    int64_t value;
    bool negated;
} GameRequirementState;

bool game_requirement_is_satisfied(
    const GamePlayer *player,
    const GameWorldState *world,
    const GameRequirementState *requirement
);
bool game_requirement_fulfill(
    GamePlayer *player,
    const GameRequirementState *requirement
);

#endif