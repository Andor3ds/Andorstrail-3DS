#ifndef ANDOR_MAP_DATA_H
#define ANDOR_MAP_DATA_H

enum MapPlaceType {
    MAP_PLACE_REST = 1,
    MAP_PLACE_MAPCHANGE = 2,
    MAP_PLACE_SIGN = 3,
    MAP_PLACE_SCRIPT = 4,
    MAP_PLACE_KEY = 5,
    MAP_PLACE_CONTAINER = 6,
    MAP_PLACE_SPAWN = 7,
};

typedef struct {
    const char *name;
    unsigned char type;
    unsigned short x;
    unsigned short y;
    unsigned short width;
    unsigned short height;
    const char *phrase_id;
    const char *require_type;
    const char *require_id;
    int require_value;
    unsigned char require_negation;
    const char *trigger_when;
} MapPlace;

typedef struct {
    unsigned short x;
    unsigned short y;
    unsigned short width;
    unsigned short height;
    const char *target_map;
    const char *target_place;
} MapChangeEvent;

typedef struct {
    const char *map_name;
    const char *name;
    unsigned short x;
    unsigned short y;
    unsigned short width;
    unsigned short height;
    const char *spawn_group;
    unsigned short quantity;
    unsigned short respawn_speed;
    unsigned char active;
    unsigned char ignore_areas;
} MapSpawnArea;

#endif