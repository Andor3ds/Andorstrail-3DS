#include "game_requirements.h"

#include <limits.h>
#include <stdlib.h>
#include <string.h>

static int64_t named_value(const GameNamedValues *values, const char *id)
{
    int64_t value = 0;
    game_named_values_get(values, id, &value);
    return value;
}

static bool item_requirement(const GamePlayer *player, const char *id, int64_t count)
{
    if (player == NULL || id == NULL || count < 0 || count > UINT32_MAX) return false;
    if (strcmp(id, "gold") == 0) return player->gold >= count;
    return game_player_item_quantity(player, id) >= (uint32_t)count;
}

bool game_requirement_is_satisfied(
    const GamePlayer *player,
    const GameWorldState *world,
    const GameRequirementState *requirement
)
{
    if (player == NULL || world == NULL || requirement == NULL || requirement->type == NULL) return false;
    const char *id = requirement->id != NULL ? requirement->id : "";
    const int64_t value = requirement->value;
    bool matched = false;

    if (strcmp(requirement->type, "questProgress") == 0) {
        matched = value >= INT_MIN && value <= INT_MAX
            && game_player_has_quest_progress(player, id, (int)value);
    } else if (strcmp(requirement->type, "questLatestProgress") == 0) {
        matched = value >= INT_MIN && value <= INT_MAX
            && game_player_is_latest_quest_progress(player, id, (int)value);
    } else if (strcmp(requirement->type, "inventoryKeep") == 0
            || strcmp(requirement->type, "inventoryRemove") == 0) {
        matched = item_requirement(player, id, value);
    } else if (strcmp(requirement->type, "wear") == 0
            || strcmp(requirement->type, "wearRemove") == 0) {
        matched = value >= 0 && value <= UINT32_MAX
            && game_player_equipped_quantity(player, id) >= (uint32_t)value;
    } else if (strcmp(requirement->type, "skillLevel") == 0) {
        matched = named_value(&player->skill_levels, id) >= value;
    } else if (strcmp(requirement->type, "hasActorCondition") == 0) {
        if (player != NULL) {
            for (size_t index = 0; index < player->condition_count; ++index) {
                if (strcmp(player->conditions[index].condition_id, id) == 0) {
                    matched = true;
                    break;
                }
            }
        }
    } else if (strcmp(requirement->type, "factionScore") == 0) {
        matched = named_value(&player->alignments, id) >= value;
    } else if (strcmp(requirement->type, "factionScoreEquals") == 0) {
        matched = named_value(&player->alignments, id) == value;
    } else if (strcmp(requirement->type, "timerElapsed") == 0) {
        matched = value >= 0
            && game_world_timer_elapsed(world, id, (uint64_t)value);
    } else if (strcmp(requirement->type, "random") == 0) {
        matched = value >= 100 || (value > 0 && (rand() % 100) < value);
    }

    return requirement->negated ? !matched : matched;
}

bool game_requirement_fulfill(GamePlayer *player, const GameRequirementState *requirement)
{
    if (player == NULL || requirement == NULL || requirement->type == NULL || requirement->id == NULL) {
        return false;
    }
    if (strcmp(requirement->type, "inventoryRemove") == 0) {
        if (requirement->value <= 0 || requirement->value > UINT32_MAX) return false;
        if (strcmp(requirement->id, "gold") == 0) {
            if (player->gold < requirement->value) return false;
            player->gold -= (int)requirement->value;
            return true;
        }
        return game_player_remove_item(player, requirement->id, (uint32_t)requirement->value);
    }
    if (strcmp(requirement->type, "wearRemove") == 0) {
        if (requirement->value <= 0 || requirement->value > UINT32_MAX) return false;
        return game_player_remove_equipped_item(
            player, requirement->id, (uint32_t)requirement->value
        );
    }
    return true;
}