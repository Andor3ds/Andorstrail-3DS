#include "game_conversation.h"

#include "game_requirements.h"

#include <string.h>

static bool copy_ref(GameJsonRef ref, char *destination, size_t capacity, const char *fallback)
{
    if (ref.node == GAME_JSON_NO_NODE) {
        if (fallback == NULL) return false;
        const size_t length = strlen(fallback);
        if (length >= capacity) return false;
        memcpy(destination, fallback, length + 1);
        return true;
    }
    return game_json_string_copy(ref, destination, capacity);
}

static bool reply_is_satisfied(
    GameJsonRef reply,
    const GamePlayer *player,
    const GameWorldState *world
)
{
    const GameJsonRef requirements = game_json_object_get(reply, "requires");
    for (size_t index = 0; index < game_json_array_size(requirements); ++index) {
        const GameJsonRef raw = game_json_array_get(requirements, index);
        char type[40];
        char id[GAME_RESOURCE_ID_CAPACITY];
        int64_t value = 0;
        bool negated = false;
        if (!game_json_string_copy(game_json_object_get(raw, "requireType"), type, sizeof(type))) return false;
        if (!copy_ref(game_json_object_get(raw, "requireID"), id, sizeof(id), "")) return false;
        game_json_integer(game_json_object_get(raw, "value"), &value);
        game_json_boolean(game_json_object_get(raw, "negate"), &negated);
        const GameRequirementState requirement = {type, id, value, negated};
        if (!game_requirement_is_satisfied(player, world, &requirement)) return false;
    }
    return true;
}

static bool fulfill_reply_requirements(
    GameJsonRef reply,
    GamePlayer *player
)
{
    const GameJsonRef requirements = game_json_object_get(reply, "requires");
    for (size_t index = 0; index < game_json_array_size(requirements); ++index) {
        const GameJsonRef raw = game_json_array_get(requirements, index);
        char type[40];
        char id[GAME_RESOURCE_ID_CAPACITY];
        int64_t value = 0;
        bool negated = false;
        if (!game_json_string_copy(game_json_object_get(raw, "requireType"), type, sizeof(type))) return false;
        if (!copy_ref(game_json_object_get(raw, "requireID"), id, sizeof(id), "")) return false;
        game_json_integer(game_json_object_get(raw, "value"), &value);
        game_json_boolean(game_json_object_get(raw, "negate"), &negated);
        const GameRequirementState requirement = {type, id, value, negated};
        if (!game_requirement_fulfill(player, &requirement)) return false;
    }
    return true;
}

static bool reward_requirements_met(
    GameJsonRef reward,
    const GamePlayer *player,
    const GameWorldState *world
)
{
    const GameJsonRef requirements = game_json_object_get(reward, "requires");
    for (size_t index = 0; index < game_json_array_size(requirements); ++index) {
        const GameJsonRef raw = game_json_array_get(requirements, index);
        char type[40];
        char id[GAME_RESOURCE_ID_CAPACITY];
        int64_t value = 0;
        bool negated = false;
        if (!game_json_string_copy(game_json_object_get(raw, "requireType"), type, sizeof(type))
                || !copy_ref(game_json_object_get(raw, "requireID"), id, sizeof(id), "")) return false;
        game_json_integer(game_json_object_get(raw, "value"), &value);
        game_json_boolean(game_json_object_get(raw, "negate"), &negated);
        const GameRequirementState requirement = {type, id, value, negated};
        if (!game_requirement_is_satisfied(player, world, &requirement)) return false;
    }
    return true;
}

static void apply_phrase_rewards(GameJsonRef phrase, GamePlayer *player, GameWorldState *world)
{
    const GameJsonRef rewards = game_json_object_get(phrase, "rewards");
    for (size_t index = 0; index < game_json_array_size(rewards); ++index) {
        const GameJsonRef reward = game_json_array_get(rewards, index);
        if (!reward_requirements_met(reward, player, world)) continue;
        char type[40];
        char id[GAME_RESOURCE_ID_CAPACITY];
        int64_t value = 0;
        if (!game_json_string_copy(game_json_object_get(reward, "rewardType"), type, sizeof(type))
                || !copy_ref(game_json_object_get(reward, "rewardID"), id, sizeof(id), "")) continue;
        game_json_integer(game_json_object_get(reward, "value"), &value);
        if (strcmp(type, "questProgress") == 0 && value >= INT32_MIN && value <= INT32_MAX) {
            game_player_add_quest_progress(player, id, (int)value);
        } else if (strcmp(type, "removeQuestProgress") == 0 && value >= INT32_MIN && value <= INT32_MAX) {
            game_player_remove_quest_progress(player, id, (int)value);
        } else if (strcmp(type, "giveItem") == 0 && value > 0 && value <= UINT32_MAX) {
            if (strcmp(id, "gold") == 0) game_player_add_gold(player, (int)value);
            else game_player_add_item(player, id, (uint32_t)value);
        } else if (strcmp(type, "alignmentSet") == 0) {
            game_named_values_set(&player->alignments, id, value);
        } else if (strcmp(type, "alignmentChange") == 0) {
            int64_t current = 0;
            game_named_values_get(&player->alignments, id, &current);
            game_named_values_set(&player->alignments, id, current + value);
        }
    }
}

static bool save_reply_requirements(GameConversationSession *session, GameJsonRef reply)
{
    const GameJsonRef requirements = game_json_object_get(reply, "requires");
    const size_t count = game_json_array_size(requirements);
    if (count > GAME_CONVERSATION_MAX_PENDING_REQUIREMENTS) return false;
    session->pending_requirement_count = 0;
    for (size_t index = 0; index < count; ++index) {
        const GameJsonRef raw = game_json_array_get(requirements, index);
        GameConversationPendingRequirement *saved =
            &session->pending_requirements[session->pending_requirement_count];
        if (!game_json_string_copy(game_json_object_get(raw, "requireType"), saved->type, sizeof(saved->type))
                || !copy_ref(game_json_object_get(raw, "requireID"), saved->id, sizeof(saved->id), "")) {
            return false;
        }
        game_json_integer(game_json_object_get(raw, "value"), &saved->value);
        game_json_boolean(game_json_object_get(raw, "negate"), &saved->negated);
        ++session->pending_requirement_count;
    }
    return true;
}

static void fulfill_saved_reply_requirements(GameConversationSession *session, GamePlayer *player)
{
    for (size_t index = 0; index < session->pending_requirement_count; ++index) {
        const GameConversationPendingRequirement *saved = &session->pending_requirements[index];
        const GameRequirementState requirement = {
            saved->type, saved->id, saved->value, saved->negated
        };
        game_requirement_fulfill(player, &requirement);
    }
    session->pending_requirement_count = 0;
}

static bool find_record(GameResources *resources, const char *id, GameJsonDocument *document, GameJsonRef *raw)
{
    const GameResourceRecordEntry *record = game_resources_find(
        GAME_RESOURCE_CONVERSATION, id, NULL
    );
    return record != NULL && game_resources_open_record(resources, record, document, raw);
}

static bool present_next(
    GameConversationSession *session,
    GameResources *resources,
    GamePlayer *player,
    GameWorldState *world,
    char *message,
    size_t message_capacity
)
{
    for (unsigned int automatic_steps = 0; automatic_steps < 64; ++automatic_steps) {
        GameJsonDocument document;
        GameJsonRef raw;
        if (!find_record(resources, session->phrase_id, &document, &raw)) {
            game_conversation_end(session);
            return false;
        }
        GameConversationDefinition phrase;
        if (!game_resource_conversation_view(raw, &phrase)) {
            game_json_dispose(&document);
            game_conversation_end(session);
            return false;
        }
        apply_phrase_rewards(raw, player, world);
        GameJsonRef first_valid_reply = {NULL, GAME_JSON_NO_NODE};
        for (size_t index = 0; index < game_json_array_size(phrase.replies); ++index) {
            GameJsonRef reply = game_json_array_get(phrase.replies, index);
            if (reply_is_satisfied(reply, player, world)) {
                first_valid_reply = reply;
                break;
            }
        }

        if (phrase.message.node != GAME_JSON_NO_NODE) {
            char decoded_message[4096];
            if (!game_json_string_copy(phrase.message, decoded_message, sizeof(decoded_message))) {
                game_json_dispose(&document);
                game_conversation_end(session);
                return false;
            }
            snprintf(message, message_capacity, "%s", decoded_message);
            session->waiting_for_reply = first_valid_reply.node != GAME_JSON_NO_NODE;
            if (session->waiting_for_reply) {
                if (!save_reply_requirements(session, first_valid_reply)) {
                    game_json_dispose(&document);
                    game_conversation_end(session);
                    return false;
                }
                GameJsonRef next_phrase = game_json_object_get(first_valid_reply, "nextPhraseID");
                if (!copy_ref(next_phrase, session->next_phrase_id,
                        sizeof(session->next_phrase_id), "")) {
                    game_json_dispose(&document);
                    game_conversation_end(session);
                    return false;
                }
            } else {
                session->next_phrase_id[0] = '\0';
            }
            game_json_dispose(&document);
            return true;
        }

        if (first_valid_reply.node == GAME_JSON_NO_NODE) {
            game_json_dispose(&document);
            game_conversation_end(session);
            return false;
        }
        fulfill_reply_requirements(first_valid_reply, player);
        GameJsonRef next_phrase = game_json_object_get(first_valid_reply, "nextPhraseID");
        char next_id[GAME_STATE_ID_CAPACITY];
        if (!copy_ref(next_phrase, next_id, sizeof(next_id), "")) {
            game_json_dispose(&document);
            game_conversation_end(session);
            return false;
        }
        game_json_dispose(&document);
        if (next_id[0] == '\0' || strcmp(next_id, "C") == 0) {
            game_conversation_end(session);
            return false;
        }
        memcpy(session->phrase_id, next_id, strlen(next_id) + 1);
    }
    game_conversation_end(session);
    return false;
}

bool game_conversation_start(
    GameConversationSession *session,
    GameResources *resources,
    GamePlayer *player,
    GameWorldState *world,
    const char *actor_id,
    const char *phrase_id,
    char *message,
    size_t message_capacity
)
{
    if (session == NULL || resources == NULL || player == NULL || world == NULL
            || actor_id == NULL || phrase_id == NULL || message == NULL) return false;
    memset(session, 0, sizeof(*session));
    if (!copy_ref((GameJsonRef){NULL, GAME_JSON_NO_NODE}, session->actor_id,
            sizeof(session->actor_id), actor_id)
            || !copy_ref((GameJsonRef){NULL, GAME_JSON_NO_NODE}, session->phrase_id,
                sizeof(session->phrase_id), phrase_id)) return false;
    session->active = true;
    return present_next(session, resources, player, world, message, message_capacity);
}

bool game_conversation_continue(
    GameConversationSession *session,
    GameResources *resources,
    GamePlayer *player,
    GameWorldState *world,
    char *message,
    size_t message_capacity
)
{
    if (session == NULL || !session->active || !session->waiting_for_reply) return false;
    fulfill_saved_reply_requirements(session, player);
    if (session->next_phrase_id[0] == '\0' || strcmp(session->next_phrase_id, "C") == 0) {
        game_conversation_end(session);
        return false;
    }
    memcpy(session->phrase_id, session->next_phrase_id, strlen(session->next_phrase_id) + 1);
    session->waiting_for_reply = false;
    return present_next(session, resources, player, world, message, message_capacity);
}

void game_conversation_end(GameConversationSession *session)
{
    if (session == NULL) return;
    memset(session, 0, sizeof(*session));
}