#include <nds.h>
#include <string.h>
#include "screen_renderer.h"

#define MAP_VIEW_WIDTH 256
#define MAP_VIEW_HEIGHT 192
#define COMBINED_VIEW_HEIGHT (MAP_VIEW_HEIGHT * 2)
#define PLAYER_FOCUS_Y 176

static int top_background;
static int bottom_background;

static int clamp(int value, int minimum, int maximum)
{
    if (value < minimum) return minimum;
    if (value > maximum) return maximum;
    return value;
}

void screen_renderer_init(void)
{
    videoSetMode(MODE_5_2D);
    videoSetModeSub(MODE_5_2D);
    vramSetPrimaryBanks(
        VRAM_A_MAIN_BG_0x06000000,
        VRAM_B_MAIN_BG_0x06020000,
        VRAM_C_SUB_BG,
        VRAM_D_LCD
    );

    top_background = bgInit(2, BgType_Bmp16, BgSize_B16_256x256, 0, 0);
    bottom_background = bgInitSub(3, BgType_Bmp16, BgSize_B16_256x256, 0, 0);
}

static void draw_viewport(
    int background_id,
    const unsigned short *world_pixels,
    int map_pixel_width,
    int map_pixel_height,
    const unsigned short *hero,
    int player_pixel_x,
    int player_pixel_y,
    int camera_x,
    int camera_top,
    int world_y_offset
)
{
    u16 *screen = bgGetGfxPtr(background_id);

    for (int pixel_y = 0; pixel_y < MAP_VIEW_HEIGHT; ++pixel_y) {
        const int world_y = camera_top + world_y_offset + pixel_y;
        u16 *destination = screen + pixel_y * MAP_VIEW_WIDTH;
        for (int pixel_x = 0; pixel_x < MAP_VIEW_WIDTH; ++pixel_x) {
            destination[pixel_x] = BIT(15);
        }
        if (world_y < 0 || world_y >= map_pixel_height) continue;

        const u16 *source = world_pixels + world_y * map_pixel_width + camera_x;
        memcpy(destination, source, MAP_VIEW_WIDTH * sizeof(u16));
    }

    const int sprite_x = player_pixel_x - camera_x;
    const int sprite_y = player_pixel_y - (camera_top + world_y_offset);
    for (int pixel_y = 0; pixel_y < 32; ++pixel_y) {
        const int screen_y = sprite_y + pixel_y;
        if (screen_y < 0 || screen_y >= MAP_VIEW_HEIGHT) continue;
        for (int pixel_x = 0; pixel_x < 32; ++pixel_x) {
            const int screen_x = sprite_x + pixel_x;
            if (screen_x < 0 || screen_x >= MAP_VIEW_WIDTH) continue;
            const u16 pixel = hero[pixel_y * 32 + pixel_x];
            if (pixel & BIT(15)) {
                screen[screen_y * MAP_VIEW_WIDTH + screen_x] = pixel;
            }
        }
    }
}

void screen_renderer_draw(
    const unsigned short *background,
    int map_width,
    int map_height,
    const unsigned short *hero,
    int player_x,
    int player_y
)
{
    const int map_pixel_width = map_width * 32;
    const int map_pixel_height = map_height * 32;
    const int player_pixel_x = player_x * 32;
    const int player_pixel_y = player_y * 32;
    const int camera_x = clamp(player_pixel_x + 16 - MAP_VIEW_WIDTH / 2, 0, map_pixel_width - MAP_VIEW_WIDTH);
    const int max_camera_y = map_pixel_height > COMBINED_VIEW_HEIGHT
        ? map_pixel_height - COMBINED_VIEW_HEIGHT
        : 0;
    const int camera_top = clamp(player_pixel_y + 16 - PLAYER_FOCUS_Y, 0, max_camera_y);

    draw_viewport(
        top_background, background, map_pixel_width, map_pixel_height,
        hero, player_pixel_x, player_pixel_y, camera_x, camera_top, 0
    );
    draw_viewport(
        bottom_background, background, map_pixel_width, map_pixel_height,
        hero, player_pixel_x, player_pixel_y, camera_x, camera_top, MAP_VIEW_HEIGHT
    );
}