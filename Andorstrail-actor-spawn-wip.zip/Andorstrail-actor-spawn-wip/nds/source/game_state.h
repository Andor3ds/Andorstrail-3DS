#ifndef ANDOR_GAME_STATE_H
#define ANDOR_GAME_STATE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define GAME_STATE_ID_CAPACITY 96
#define GAME_PLAYER_NAME_CAPACITY 64

typedef struct {
    int current;
    int maximum;
} GameRange;

typedef struct {
    int max_hp;
    int max_ap;
    int move_cost;
    int attack_cost;
    int attack_chance;
    int critical_skill;
    float critical_multiplier;
    int min_damage;
    int max_damage;
    int block_chance;
    int damage_resistance;
    int use_item_cost;
    int reequip_cost;
} GamePlayerBaseStats;

typedef struct {
    char *name;
    int64_t value;
} GameNamedValue;

typedef struct {
    GameNamedValue *values;
    size_t count;
    size_t capacity;
} GameNamedValues;

typedef struct {
    char *quest_id;
    int *stages;
    size_t stage_count;
    size_t stage_capacity;
} GameQuestProgress;

typedef struct {
    char *item_id;
    uint32_t quantity;
} GameInventoryItem;

typedef struct {
    char *slot_id;
    char *item_id;
} GameEquippedItem;

typedef struct {
    char *condition_id;
    int magnitude;
    int remaining_duration;
} GamePlayerCondition;

typedef struct {
    char player_id[GAME_STATE_ID_CAPACITY];
    char name[GAME_PLAYER_NAME_CAPACITY];
    char map_id[GAME_STATE_ID_CAPACITY];
    int x;
    int y;
    char spawn_map_id[GAME_STATE_ID_CAPACITY];
    char spawn_place_id[GAME_STATE_ID_CAPACITY];
    GameRange hp;
    GameRange ap;
    GameRange level_experience;
    GamePlayerBaseStats base_stats;
    int icon_id;
    int map_icon_id;
    int level;
    uint64_t total_experience;
    uint64_t saved_version;
    int available_skill_points;
    int gold;
    GameInventoryItem *items;
    size_t item_count;
    size_t item_capacity;
    GameEquippedItem *equipment;
    size_t equipment_count;
    size_t equipment_capacity;
    GamePlayerCondition *conditions;
    size_t condition_count;
    size_t condition_capacity;
    GameQuestProgress *quest_progress;
    size_t quest_progress_count;
    size_t quest_progress_capacity;
    GameNamedValues skill_levels;
    GameNamedValues alignments;
    GameNamedValues properties;
} GamePlayer;

typedef struct {
    char *map_id;
    uint64_t last_visit_tick;
    bool visited;
} GameMapState;

typedef struct {
    char *map_id;
    char *event_id;
    uint8_t type;
    int x;
    int y;
    bool active;
    bool triggered;
    int64_t value;
} GameObjectState;

typedef struct {
    char *name;
    uint64_t started_at_tick;
    bool active;
} GameWorldTimer;

typedef struct {
    char *actor_id;
    char *map_id;
    char *spawn_area_id;
    char *monster_type_id;
    char *name;
    char *phrase_id;
    char *faction;
    char *icon_id;
    char *monster_class;
    char *aggression_type;
    int x;
    int y;
    int hp;
    int max_hp;
    int ap;
    int max_ap;
    int move_cost;
    int attack_cost;
    int attack_chance;
    int critical_skill;
    double critical_multiplier;
    int min_damage;
    int max_damage;
    int block_chance;
    int damage_resistance;
    bool is_alive;
    bool is_hostile;
    bool is_unique;
} GameActorState;

typedef struct {
    char *map_id;
    char *object_id;
    int x;
    int y;
    bool is_container;
    int gold;
    GameInventoryItem *items;
    size_t item_count;
    size_t item_capacity;
} GameWorldLootBag;

typedef struct {
    char current_map_id[GAME_STATE_ID_CAPACITY];
    uint64_t world_time;
    GameNamedValues flags;
    GameMapState *maps;
    size_t map_count;
    size_t map_capacity;
    GameObjectState *objects;
    size_t object_count;
    size_t object_capacity;
    GameWorldTimer *timers;
    size_t timer_count;
    size_t timer_capacity;
    GameWorldLootBag *loot_bags;
    size_t loot_bag_count;
    size_t loot_bag_capacity;
    GameActorState *actors;
    size_t actor_count;
    size_t actor_capacity;
} GameWorldState;

typedef struct {
    GamePlayer player;
    GameWorldState world;
} GameRuntimeState;

void game_player_init(GamePlayer *player, const char *name, const char *map_id, int x, int y);
void game_player_dispose(GamePlayer *player);
bool game_player_add_gold(GamePlayer *player, int amount);
uint32_t game_player_item_quantity(const GamePlayer *player, const char *item_id);
bool game_player_add_item(GamePlayer *player, const char *item_id, uint32_t quantity);
bool game_player_remove_item(GamePlayer *player, const char *item_id, uint32_t quantity);
bool game_player_equip(GamePlayer *player, const char *slot_id, const char *item_id);
bool game_player_unequip(GamePlayer *player, const char *slot_id);
uint32_t game_player_equipped_quantity(const GamePlayer *player, const char *item_id);
bool game_player_remove_equipped_item(GamePlayer *player, const char *item_id, uint32_t quantity);
bool game_player_set_condition(
    GamePlayer *player,
    const char *condition_id,
    int magnitude,
    int remaining_duration
);
bool game_player_remove_condition(GamePlayer *player, const char *condition_id);
bool game_player_add_quest_progress(GamePlayer *player, const char *quest_id, int stage);
bool game_player_remove_quest_progress(GamePlayer *player, const char *quest_id, int stage);
bool game_player_has_quest_progress(const GamePlayer *player, const char *quest_id, int stage);
int game_player_latest_quest_progress(const GamePlayer *player, const char *quest_id);
bool game_player_is_latest_quest_progress(const GamePlayer *player, const char *quest_id, int stage);

void game_world_init(GameWorldState *world, const char *map_id);
void game_world_dispose(GameWorldState *world);
void game_world_tick(GameWorldState *world, uint64_t ticks);
GameMapState *game_world_map_state(GameWorldState *world, const char *map_id, bool create);
GameObjectState *game_world_object_state(
    GameWorldState *world,
    const char *map_id,
    const char *event_id,
    uint8_t type,
    int x,
    int y,
    bool create
);
bool game_world_set_timer(GameWorldState *world, const char *name);
bool game_world_timer_elapsed(const GameWorldState *world, const char *name, uint64_t duration);
GameWorldLootBag *game_world_loot_bag(
    GameWorldState *world,
    const char *map_id,
    const char *object_id,
    int x,
    int y,
    bool is_container,
    bool create
);
bool game_world_clear_loot_bag(GameWorldLootBag *bag);
bool game_world_loot_bag_add_item(GameWorldLootBag *bag, const char *item_id, uint32_t quantity);
GameActorState *game_world_actor_at(GameWorldState *world, const char *map_id, int x, int y);
bool game_world_add_actor(GameWorldState *world, const GameActorState *actor);

bool game_named_values_set(GameNamedValues *values, const char *name, int64_t value);
bool game_named_values_get(const GameNamedValues *values, const char *name, int64_t *value);
bool game_named_values_remove(GameNamedValues *values, const char *name);
void game_named_values_dispose(GameNamedValues *values);

void game_runtime_state_init(
    GameRuntimeState *state,
    const char *player_name,
    const char *starting_map_id,
    int starting_x,
    int starting_y
);
void game_runtime_state_dispose(GameRuntimeState *state);

#endif