#include <nds.h>
#include <stdio.h>
#include <string.h>
#include "dialog_art.h"
#include "sign_dialog.h"

#define DIALOG_SCREEN_WIDTH 256
#define DIALOG_SCREEN_HEIGHT 192
#define BOTTOM_BITMAP_BG_ID 7
#define DIALOG_MAX_LINES 3
#define DIALOG_TEXT_CAPACITY 256
#define DIALOG_FRAME_X 28
#define DIALOG_FRAME_WIDTH 200
#define DIALOG_MESSAGE_HEIGHT 70
#define DIALOG_BUTTONS_HEIGHT 35
#define DIALOG_BUTTON_HEIGHT 27
#define DIALOG_PANEL_GAP 3
#define DIALOG_TEXT_SCALE 2
#define DIALOG_TEXT_INSET 6
#define DIALOG_TEXT_LINE_HEIGHT 18

static const unsigned char uppercase_font[26][7] = {
    {14, 17, 17, 31, 17, 17, 17}, {30, 17, 17, 30, 17, 17, 30},
    {14, 17, 16, 16, 16, 17, 14}, {30, 17, 17, 17, 17, 17, 30},
    {31, 16, 16, 30, 16, 16, 31}, {31, 16, 16, 30, 16, 16, 16},
    {14, 17, 16, 23, 17, 17, 15}, {17, 17, 17, 31, 17, 17, 17},
    {14, 4, 4, 4, 4, 4, 14}, {7, 2, 2, 2, 2, 18, 12},
    {17, 18, 20, 24, 20, 18, 17}, {16, 16, 16, 16, 16, 16, 31},
    {17, 27, 21, 21, 17, 17, 17}, {17, 25, 21, 19, 17, 17, 17},
    {14, 17, 17, 17, 17, 17, 14}, {30, 17, 17, 30, 16, 16, 16},
    {14, 17, 17, 17, 21, 18, 13}, {30, 17, 17, 30, 20, 18, 17},
    {15, 16, 16, 14, 1, 1, 30}, {31, 4, 4, 4, 4, 4, 4},
    {17, 17, 17, 17, 17, 17, 14}, {17, 17, 17, 17, 17, 10, 4},
    {17, 17, 17, 21, 21, 21, 10}, {17, 17, 10, 4, 10, 17, 17},
    {17, 17, 10, 4, 4, 4, 4}, {31, 1, 2, 4, 8, 16, 31},
};

static const unsigned char lowercase_font[26][7] = {
    {0, 0, 14, 1, 15, 17, 15}, {16, 16, 30, 17, 17, 17, 30},
    {0, 0, 14, 16, 16, 17, 14}, {1, 1, 15, 17, 17, 17, 15},
    {0, 0, 14, 17, 31, 16, 14}, {6, 9, 8, 28, 8, 8, 8},
    {0, 0, 15, 17, 15, 1, 14}, {16, 16, 30, 17, 17, 17, 17},
    {4, 0, 12, 4, 4, 4, 14}, {2, 0, 6, 2, 2, 18, 12},
    {16, 16, 18, 20, 24, 20, 18}, {12, 4, 4, 4, 4, 4, 14},
    {0, 0, 26, 21, 21, 21, 21}, {0, 0, 30, 17, 17, 17, 17},
    {0, 0, 14, 17, 17, 17, 14}, {0, 0, 30, 17, 30, 16, 16},
    {0, 0, 15, 17, 15, 1, 1}, {0, 0, 22, 25, 16, 16, 16},
    {0, 0, 15, 16, 14, 1, 30}, {8, 8, 28, 8, 8, 9, 6},
    {0, 0, 17, 17, 17, 19, 13}, {0, 0, 17, 17, 17, 10, 4},
    {0, 0, 17, 17, 21, 21, 10}, {0, 0, 17, 10, 4, 10, 17},
    {0, 0, 17, 17, 15, 1, 14}, {0, 0, 31, 2, 4, 8, 31},
};

static char dialog_message[DIALOG_TEXT_CAPACITY];
static int dialog_active;

typedef struct {
    const unsigned short *pixels;
    int width;
    int height;
    int stretch_x_start;
    int stretch_x_end;
    int stretch_y_start;
    int stretch_y_end;
} NinePatch;

static const NinePatch standard_frame = {
    dialog_std_frame_pixels,
    DIALOG_STD_FRAME_WIDTH,
    DIALOG_STD_FRAME_HEIGHT,
    DIALOG_STD_FRAME_STRETCH_X_START,
    DIALOG_STD_FRAME_STRETCH_X_END,
    DIALOG_STD_FRAME_STRETCH_Y_START,
    DIALOG_STD_FRAME_STRETCH_Y_END,
};

static const NinePatch enabled_button = {
    dialog_button_unpressed_pixels,
    DIALOG_BUTTON_UNPRESSED_WIDTH,
    DIALOG_BUTTON_UNPRESSED_HEIGHT,
    DIALOG_BUTTON_UNPRESSED_STRETCH_X_START,
    DIALOG_BUTTON_UNPRESSED_STRETCH_X_END,
    DIALOG_BUTTON_UNPRESSED_STRETCH_Y_START,
    DIALOG_BUTTON_UNPRESSED_STRETCH_Y_END,
};

static const u16 dialogue_color = RGB15(31, 31, 31) | BIT(15);

static void fill_rect(u16 *screen, int x, int y, int width, int height, u16 color)
{
    for (int row = y; row < y + height; ++row) {
        if (row < 0 || row >= DIALOG_SCREEN_HEIGHT) continue;
        for (int column = x; column < x + width; ++column) {
            if (column < 0 || column >= DIALOG_SCREEN_WIDTH) continue;
            screen[row * DIALOG_SCREEN_WIDTH + column] = color;
        }
    }
}

static int map_ninepatch_axis(
    int target_position,
    int target_size,
    int source_size,
    int stretch_start,
    int stretch_end
)
{
    const int stretch_size = stretch_end - stretch_start;
    const int fixed_after = source_size - stretch_end;
    const int stretch_target_size = target_size - stretch_start - fixed_after;

    if (target_position < stretch_start) return target_position;
    if (target_position >= target_size - fixed_after) {
        return stretch_end + target_position - (target_size - fixed_after);
    }
    if (stretch_target_size <= 0) return stretch_start;
    return stretch_start + (target_position - stretch_start) * stretch_size / stretch_target_size;
}

static void draw_ninepatch(
    u16 *screen,
    const NinePatch *patch,
    int x,
    int y,
    int width,
    int height
)
{
    for (int target_y = 0; target_y < height; ++target_y) {
        const int source_y = map_ninepatch_axis(
            target_y, height, patch->height, patch->stretch_y_start, patch->stretch_y_end
        );
        for (int target_x = 0; target_x < width; ++target_x) {
            const int source_x = map_ninepatch_axis(
                target_x, width, patch->width, patch->stretch_x_start, patch->stretch_x_end
            );
            const u16 pixel = patch->pixels[source_y * patch->width + source_x];
            if ((pixel & BIT(15)) == 0) continue;

            const int screen_x = x + target_x;
            const int screen_y = y + target_y;
            if (screen_x < 0 || screen_x >= DIALOG_SCREEN_WIDTH
                    || screen_y < 0 || screen_y >= DIALOG_SCREEN_HEIGHT) {
                continue;
            }
            screen[screen_y * DIALOG_SCREEN_WIDTH + screen_x] = pixel;
        }
    }
}

static void dim_background(u16 *screen)
{
    for (int index = 0; index < DIALOG_SCREEN_WIDTH * DIALOG_SCREEN_HEIGHT; ++index) {
        const u16 pixel = screen[index];
        const unsigned int red = pixel & 31;
        const unsigned int green = (pixel >> 5) & 31;
        const unsigned int blue = (pixel >> 10) & 31;
        screen[index] = (u16)(((red * 5 / 8) | ((green * 5 / 8) << 5) | ((blue * 5 / 8) << 10)) | BIT(15));
    }
}

static const unsigned char *glyph_rows(char character)
{
    if (character >= 'A' && character <= 'Z') {
        return uppercase_font[character - 'A'];
    }
    if (character >= 'a' && character <= 'z') {
        return lowercase_font[character - 'a'];
    }
    return NULL;
}

static void draw_glyph(u16 *screen, int x, int y, char character, int scale, u16 color)
{
    const unsigned char *rows = glyph_rows(character);
    if (rows != NULL) {
        for (int row = 0; row < 7; ++row) {
            for (int column = 0; column < 5; ++column) {
                if ((rows[row] & (1 << (4 - column))) == 0) continue;
                fill_rect(screen, x + column * scale, y + row * scale, scale, scale, color);
            }
        }
    } else if (character == ':') {
        fill_rect(screen, x + 4 * scale, y + 2 * scale, scale, scale, color);
        fill_rect(screen, x + 4 * scale, y + 5 * scale, scale, scale, color);
    }
}

static int text_width(const char *text, int scale)
{
    const size_t length = strlen(text);
    const int advance = scale == DIALOG_TEXT_SCALE ? 11 : 6 * scale;
    return length == 0 ? 0 : ((int)length - 1) * advance + 5 * scale;
}

static void draw_text(u16 *screen, int x, int y, const char *text, int scale, u16 color)
{
    const int advance = scale == DIALOG_TEXT_SCALE ? 11 : 6 * scale;
    int character_x = x;
    for (const char *character = text; *character != '\0'; ++character) {
        draw_glyph(screen, character_x + 1, y + 1, *character, scale, RGB15(0, 0, 0) | BIT(15));
        character_x += advance;
    }
    character_x = x;
    for (const char *character = text; *character != '\0'; ++character) {
        draw_glyph(screen, character_x, y, *character, scale, color);
        character_x += advance;
    }
}

void sign_dialog_show(const char *message)
{
    snprintf(dialog_message, sizeof(dialog_message), "%s", message != NULL ? message : "");
    dialog_active = dialog_message[0] != '\0';
}

int sign_dialog_handle_input(unsigned int keys)
{
    if (!dialog_active) return 0;

    if (keys & (KEY_A | KEY_B)) {
        dialog_active = 0;
    }
    return 1;
}

int sign_dialog_is_active(void)
{
    return dialog_active;
}

void sign_dialog_draw(void)
{
    if (!dialog_active) return;

    u16 *screen = bgGetGfxPtr(BOTTOM_BITMAP_BG_ID);
    const int total_height = DIALOG_MESSAGE_HEIGHT + DIALOG_PANEL_GAP + DIALOG_BUTTONS_HEIGHT;
    const int message_y = (DIALOG_SCREEN_HEIGHT - total_height) / 2;
    const int buttons_y = message_y + DIALOG_MESSAGE_HEIGHT + DIALOG_PANEL_GAP;
    const int content_x = DIALOG_FRAME_X + DIALOG_STD_FRAME_PADDING_LEFT + DIALOG_TEXT_INSET;
    const int content_y = message_y + DIALOG_STD_FRAME_PADDING_TOP + DIALOG_TEXT_INSET;

    dim_background(screen);
    draw_ninepatch(screen, &standard_frame, DIALOG_FRAME_X, message_y, DIALOG_FRAME_WIDTH, DIALOG_MESSAGE_HEIGHT);
    draw_ninepatch(screen, &standard_frame, DIALOG_FRAME_X, buttons_y, DIALOG_FRAME_WIDTH, DIALOG_BUTTONS_HEIGHT);

    const char *cursor = dialog_message;
    for (int line_index = 0; line_index < DIALOG_MAX_LINES && *cursor != '\0'; ++line_index) {
        char line[40];
        int length = 0;
        while (*cursor != '\0' && *cursor != '\n' && length < (int)sizeof(line) - 1) {
            line[length++] = *cursor++;
        }
        line[length] = '\0';
        draw_text(screen, content_x, content_y + line_index * DIALOG_TEXT_LINE_HEIGHT,
            line, DIALOG_TEXT_SCALE, dialogue_color);
        if (*cursor == '\n') ++cursor;
    }

    const int button_y = buttons_y + (DIALOG_BUTTONS_HEIGHT - DIALOG_BUTTON_HEIGHT) / 2;
    const int button_width = (DIALOG_FRAME_WIDTH - DIALOG_STD_FRAME_PADDING_LEFT * 2 - 8) / 2;
    const int first_button_x = DIALOG_FRAME_X + DIALOG_STD_FRAME_PADDING_LEFT;
    const int second_button_x = first_button_x + button_width + 8;
    draw_ninepatch(screen, &enabled_button, first_button_x, button_y, button_width, DIALOG_BUTTON_HEIGHT);
    draw_ninepatch(screen, &enabled_button, second_button_x, button_y, button_width, DIALOG_BUTTON_HEIGHT);

    const char *button_labels[] = {"Next", "Leave"};
    const int button_x[] = {first_button_x, second_button_x};
    for (int index = 0; index < 2; ++index) {
        const int label_x = button_x[index] + (button_width - text_width(button_labels[index], 2)) / 2;
        draw_text(screen, label_x, button_y + (DIALOG_BUTTON_HEIGHT - 14) / 2, button_labels[index], 2, dialogue_color);
    }
}