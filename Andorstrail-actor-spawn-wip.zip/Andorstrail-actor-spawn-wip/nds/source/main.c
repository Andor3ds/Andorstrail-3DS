#include <nds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <filesystem.h>
#include <zlib.h>
#include "game_actor_system.h"
#include "game_conversation.h"
#include "game_resources.h"
#include "game_requirements.h"
#include "game_state.h"
#include "map_data.h"
#include "screen_renderer.h"
#include "sign_dialog.h"

typedef struct {
    const char *name;
                && x < place->x + place->width && y < place->y + place->height) return 0;
    }
    return 1;
}

static int spawn_actors_for_map(const GameMap *map)
{
    for (size_t area_index = 0; area_index < map_spawn_area_count; ++area_index) {
        const MapSpawnArea *area = &map_spawn_areas[area_index];
        if (strcmp(area->map_name, map->name) != 0 || !area->active
                || area->quantity == 0 || area->width == 0 || area->height == 0) continue;
        size_t group_size = 0;
        game_resources_find_spawn_group(area->spawn_group, 0, &group_size);
        if (group_size == 0) continue;
        for (unsigned int quantity = 0; quantity < area->quantity; ++quantity) {
            const GameResourceRecordEntry *monster_record = game_resources_find_spawn_group(
                area->spawn_group, (size_t)rand() % group_size, NULL
            );
            GameJsonDocument document;
            GameJsonRef raw;
            if (monster_record == NULL
                    || !game_resources_open_record(&game_resources, monster_record, &document, &raw)) {
                continue;
            }
            GameMonsterDefinition definition;
            GameActorState actor = {0};
            char actor_id[GAME_RESOURCE_ID_CAPACITY * 2];
            char monster_id[GAME_RESOURCE_ID_CAPACITY];
            char actor_name[GAME_RESOURCE_ID_CAPACITY];
            char phrase_id[GAME_RESOURCE_ID_CAPACITY];
            char faction[GAME_RESOURCE_ID_CAPACITY];
            char icon_id[GAME_RESOURCE_ID_CAPACITY];
            char monster_class[40];
            char aggression[40];
            int64_t min_damage = 0;
            int64_t max_damage = 0;
            const GameJsonRef damage = game_json_object_get(raw, "attackDamage");
            const int valid = game_resource_monster_view(raw, &definition)
                && game_json_string_copy(definition.id, monster_id, sizeof(monster_id))
                && game_json_string_copy(definition.name, actor_name, sizeof(actor_name))
                && (definition.phrase_id.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.phrase_id, phrase_id, sizeof(phrase_id)))
                && (definition.faction.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.faction, faction, sizeof(faction)))
                && (definition.icon_id.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.icon_id, icon_id, sizeof(icon_id)))
                && (definition.monster_class.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.monster_class, monster_class, sizeof(monster_class)))
                && (definition.movement_aggression.node == GAME_JSON_NO_NODE
                    || game_json_string_copy(definition.movement_aggression, aggression, sizeof(aggression)));
            if (!valid) {
                game_json_dispose(&document);
                continue;
            }
            if (definition.phrase_id.node == GAME_JSON_NO_NODE) phrase_id[0] = '\0';
            if (definition.faction.node == GAME_JSON_NO_NODE) faction[0] = '\0';
            if (definition.icon_id.node == GAME_JSON_NO_NODE) icon_id[0] = '\0';
            if (definition.monster_class.node == GAME_JSON_NO_NODE) strcpy(monster_class, "humanoid");
            if (definition.movement_aggression.node == GAME_JSON_NO_NODE) strcpy(aggression, "none");
            game_json_integer(game_json_object_get(damage, "min"), &min_damage);
            game_json_integer(game_json_object_get(damage, "max"), &max_damage);
            game_json_dispose(&document);

            int actor_x = -1;
            int actor_y = -1;
            for (unsigned int attempt = 0; attempt < 100; ++attempt) {
                const int x = area->x + rand() % area->width;
                const int y = area->y + rand() % area->height;
                if (!spawn_position_is_free(map, area, x, y)) continue;
                actor_x = x;
                actor_y = y;
                break;
            }
            if (actor_x < 0) continue;

            snprintf(actor_id, sizeof(actor_id), "%s/%s/%u", map->name, area->name, quantity);
            actor.actor_id = actor_id;
            actor.map_id = (char *)map->name;
            actor.spawn_area_id = (char *)area->name;
            actor.monster_type_id = monster_id;
            actor.name = actor_name;
            actor.phrase_id = phrase_id;
            actor.faction = faction;
            actor.icon_id = icon_id;
            actor.monster_class = monster_class;
            actor.aggression_type = aggression;
            actor.x = actor_x;
            actor.y = actor_y;
            actor.hp = actor.max_hp = definition.max_hp;
            actor.ap = actor.max_ap = definition.max_ap;
            actor.move_cost = definition.move_cost;
            actor.attack_cost = definition.attack_cost;
            actor.attack_chance = definition.attack_chance;
            actor.critical_skill = definition.critical_skill;
            actor.critical_multiplier = definition.critical_multiplier;
            actor.min_damage = (int)min_damage;
            actor.max_damage = (int)max_damage;
            actor.block_chance = definition.block_chance;
            actor.damage_resistance = definition.damage_resistance;
            actor.is_alive = true;
            actor.is_unique = definition.is_unique;
            actor.is_hostile = phrase_id[0] == '\0'
                || (faction[0] != '\0' && get_named_state(&game_state.player.alignments, faction) < 0);
            game_world_add_actor(&game_state.world, &actor);
        }
    }
    return 1;
}

static int load_hero_sprite(void)
{
    unsigned short *pixels = load_rgb555("nitro:/hero.rgb555.z", 32 * 32);
    if (pixels == NULL) return 0;
    memcpy(hero_sprite, pixels, sizeof(hero_sprite));
    free(pixels);
    return 1;
}

static int set_current_map(const GameMap *map, int x, int y)
{
    unsigned short *new_background = load_map_background(map);
    if (new_background == NULL) return 0;

    if (x < 0 || x >= map->width || y < 0 || y >= map->height
            || !map->walkable[y * map->width + x]) {
        for (unsigned int index = 0; index < map->place_count; ++index) {
            const MapPlace *place = &map->places[index];
            if (place->type != MAP_PLACE_MAPCHANGE) continue;
            x = place->x;
            y = place->y;
            break;
        }
    }

    free(current_background);
    current_background = new_background;
    current_map = map;
    snprintf(game_state.player.map_id, sizeof(game_state.player.map_id), "%s", map->name);
    snprintf(game_state.world.current_map_id, sizeof(game_state.world.current_map_id), "%s", map->name);
    game_state.player.x = x;
    game_state.player.y = y;
    GameMapState *map_state = game_world_map_state(&game_state.world, map->name, true);
    if (map_state != NULL) {
        if (!map_state->visited) {
            generate_map_container_loot(map);
            game_actor_spawn_map(
                &game_resources,
                &game_state,
                map->name,
                map->width,
                map->height,
                map->walkable,
                game_state.player.x,
                game_state.player.y,
                map->places,
                map->place_count,
                map_spawn_areas,
                map_spawn_area_count
            );
        }
        map_state->visited = true;
        map_state->last_visit_tick = game_state.world.world_time;
    }
    return 1;
}

static const GameMap *find_map(const char *name)
{
    for (unsigned int index = 0; index < sizeof(maps) / sizeof(maps[0]); ++index) {
        if (strcmp(maps[index].name, name) == 0) return &maps[index];
    }
    return NULL;
}

static const MapPlace *find_place(const GameMap *map, const char *name, unsigned char type)
{
    for (unsigned int index = 0; index < map->place_count; ++index) {
        const MapPlace *place = &map->places[index];
        if (place->type == type && strcmp(place->name, name) == 0) return place;
    }
    return NULL;
}

static int player_is_in_place(const MapPlace *place)
{
    if (place == NULL) return 0;
    return !(game_state.player.x < place->x || game_state.player.y < place->y
            || game_state.player.x >= place->x + place->width
            || game_state.player.y >= place->y + place->height);
}

static const MapPlace *place_at_position(int x, int y, unsigned char type)
{
    for (unsigned int index = 0; index < current_map->place_count; ++index) {
        const MapPlace *place = &current_map->places[index];
        if (place->type != type) continue;
        if (x >= place->x && y >= place->y
                && x < place->x + place->width
                && y < place->y + place->height) {
            return place;
        }
    }
    return NULL;
}

static const char *event_phrase_id(const MapPlace *place);

static int position_is_in_place(const MapPlace *place, int x, int y)
{
    if (place == NULL) return 0;
    return !(x < place->x || y < place->y
            || x >= place->x + place->width
            || y >= place->y + place->height);
}

static const MapPlace *place_at_player(unsigned char type)
{
    for (unsigned int index = 0; index < current_map->place_count; ++index) {
        const MapPlace *place = &current_map->places[index];
        if (place->type != type) continue;
        if (player_is_in_place(place)) return place;
    }
    return NULL;
}

static const char *lookup_event_message(const char *phrase_id)
{
    if (phrase_id == NULL || phrase_id[0] == '\0') return "You see something unusual.";

    static const struct {
        const char *id;
        const char *message;
    } messages[] = {
        {"sign_crossglen_cave", "The sign on the wall is cracked in several places. You cannot make out anything comprehensible from the writing."},
        {"sign_fallhaven1", "Welcome to Fallhaven. Watch out for pickpockets!"},
        {"sign_notdone", "This map is not yet done. Please come back in a later version of the game."},
        {"sign_pitcave2", "The ground is littered with bloodstained scraps of paper, seemingly torn from a journal in a fight."},
        {"sign_wild1", "West: Crossglen\nSouth: Fallhaven\nNorth: Feygard"},
        {"sign_wild3", "West: Crossglen\nEast: Fallhaven\nNorth: Feygard"},
        {"sign_wild6", "North: Crossglen\nEast: Fallhaven\nSouth: Stoutford"},
        {"sign_wild7", "West: Stoutford\nNorth: Fallhaven\nSouth: Sutdover River and Sullengard"},
        {"sign_wild10", "North: Fallhaven\nWest: Stoutford"},
        {"sign_wild12", "North: Fallhaven\nEast: Vilegard\nEast: Nor City"},
        {"keyarea_andor1", "You should talk to Mikhail first."},
        {"key_fallhavenchurch", "You are not allowed to enter the catacombs of Fallhaven Church without permission."},
        {"note_lodars", "On the ground, you find a piece of paper with a lot of strange symbols. You can barely make out the words 'meet me at Lodar's hideaway', but you are not sure what it means."},
        {"fallhaven_tavern_room", "You are not allowed into the room unless you have rented it."},
    };

    for (unsigned int index = 0; index < sizeof(messages) / sizeof(messages[0]); ++index) {
        if (strcmp(messages[index].id, phrase_id) == 0) {
            return messages[index].message;
        }
    }
    return phrase_id;
}

static void set_last_event_message(const char *message)
{
    snprintf(last_event_message, sizeof(last_event_message), "%s", message != NULL ? message : "");
}

static void set_sign_message(const char *phrase_id)
{
    set_last_event_message(lookup_event_message(phrase_id));
    sign_dialog_show(last_event_message);
}

static void set_named_state(GameNamedValues *values, const char *name, int64_t value)
{
    game_named_values_set(values, name, value);
}

static int64_t get_named_state(const GameNamedValues *values, const char *name)
{
    int64_t value = 0;
    game_named_values_get(values, name, &value);
    return value;
}

static void consume_named_state(GameNamedValues *values, const char *name, int64_t quantity)
{
    if (quantity <= 0) return;
    const int64_t current = get_named_state(values, name);
    set_named_state(values, name, current <= quantity ? 0 : current - quantity);
}

static void apply_requirement_effects(const MapPlace *place)
{
    if (place == NULL || place->require_type == NULL || place->require_type[0] == '\0') return;
    const char *require_type = place->require_type;
    const char *require_id = place->require_id;
    const int64_t value = place->require_value;

    if (strcmp(require_type, "questProgress") == 0 || strcmp(require_type, "questLatestProgress") == 0) {
        if (require_id != NULL && require_id[0] != '\0') {
            game_player_add_quest_progress(&game_state.player, require_id, (int)value);
        }
        return;
    }
    if (strcmp(require_type, "inventoryRemove") == 0) {
        consume_named_state(&game_state.player.properties, require_id, value);
        return;
    }
    if (strcmp(require_type, "factionScore") == 0 || strcmp(require_type, "factionScoreEquals") == 0) {
        if (require_id != NULL && require_id[0] != '\0') {
            const int64_t current = get_named_state(&game_state.player.alignments, require_id);
            if (value > current) {
                set_named_state(&game_state.player.alignments, require_id, value);
            }
        }
    }
}

static int requirement_is_satisfied(const MapPlace *place)
{
    if (place == NULL || place->require_type == NULL || place->require_type[0] == '\0') return 1;
    const GameRequirementState requirement = {
        place->require_type,
        place->require_id,
        place->require_value,
        place->require_negation != 0,
    };
    return game_requirement_is_satisfied(&game_state.player, &game_state.world, &requirement);
}

static void show_map_object_phrase(const char *phrase_id)
{
    size_t record_count = 0;
    const GameResourceRecordEntry *record = game_resources_find(
        GAME_RESOURCE_CONVERSATION, phrase_id, &record_count
    );
    for (size_t index = 0; record != NULL && index < record_count; ++index) {
        GameJsonDocument document;
        GameJsonRef raw;
        if (!game_resources_open_record(&game_resources, &record[index], &document, &raw)) continue;
        GameConversationDefinition phrase;
        char message[sizeof(last_event_message)];
        const int has_message = game_resource_conversation_view(raw, &phrase)
            && game_json_string_copy(phrase.message, message, sizeof(message))
            && message[0] != '\0';
        if (has_message) {
            set_last_event_message(message);
            sign_dialog_show(last_event_message);
            game_json_dispose(&document);
            return;
        }
        game_json_dispose(&document);
    }
    set_sign_message(phrase_id);
}

static int can_enter_key_area(int x, int y)
{
    const MapPlace *place = place_at_position(x, y, MAP_PLACE_KEY);
    if (place == NULL) return 1;
    if (!requirement_is_satisfied(place)) {
        show_map_object_phrase(event_phrase_id(place));
        return 0;
    }
    const GameRequirementState requirement = {
        place->require_type,
        place->require_id,
        place->require_value,
        place->require_negation != 0,
    };
    game_requirement_fulfill(&game_state.player, &requirement);
    return 1;
}

static int start_actor_conversation(const GameActorState *actor)
{
    if (actor == NULL || actor->is_hostile || actor->phrase_id[0] == '\0') return 0;

    char message[sizeof(last_event_message)];
    if (!game_conversation_start(
            &conversation_session,
            &game_resources,
            &game_state.player,
            &game_state.world,
            actor->actor_id,
            actor->phrase_id,
            message,
            sizeof(message))) {
        return 0;
    }
    set_last_event_message(message);
    sign_dialog_show(last_event_message);
    return 1;
}

static int is_event_seen(const GameMap *map, const MapPlace *place)
{
    GameObjectState *event = game_world_object_state(
        &game_state.world, map->name, place->name, place->type, place->x, place->y, false
    );
    return event != NULL && event->triggered;
}

static void mark_event_seen(const GameMap *map, const MapPlace *place)
{
    if (map == NULL || place == NULL) return;
    GameObjectState *event = game_world_object_state(
        &game_state.world, map->name, place->name, place->type, place->x, place->y, true
    );
    if (event != NULL) event->triggered = true;
}

static int transition_at_player(void)
{
    for (unsigned int index = 0; index < current_map->map_change_count; ++index) {
        const MapChangeEvent *event = &current_map->map_changes[index];
        if (game_state.player.x < event->x || game_state.player.y < event->y
                || game_state.player.x >= event->x + event->width
                || game_state.player.y >= event->y + event->height) {
            continue;
        }

        const GameMap *destination = find_map(event->target_map);
        if (destination == NULL) continue;
        const MapPlace *place = find_place(destination, event->target_place, MAP_PLACE_MAPCHANGE);
        if (place == NULL) continue;

        const int offset_x = game_state.player.x - event->x;
        const int offset_y = game_state.player.y - event->y;
        const int destination_x = place->x + (offset_x < place->width ? offset_x : place->width - 1);
        const int destination_y = place->y + (offset_y < place->height ? offset_y : place->height - 1);
        return set_current_map(destination, destination_x, destination_y);
    }
    return 0;
}

static int confirm_rest_at_player(void)
{
    const MapPlace *place = place_at_player(MAP_PLACE_REST);
    if (place == NULL) return 0;

    snprintf(game_state.player.spawn_map_id, sizeof(game_state.player.spawn_map_id), "%s", current_map->name);
    snprintf(game_state.player.spawn_place_id, sizeof(game_state.player.spawn_place_id), "%s", place->name);
    return 1;
}

static const char *event_phrase_id(const MapPlace *place)
{
    if (place == NULL) return "event";
    if (place->phrase_id != NULL && place->phrase_id[0] != '\0') return place->phrase_id;
    if (place->name != NULL && place->name[0] != '\0') return place->name;
    return "event";
}

static int process_interaction(void)
{
    const unsigned char order[] = {
        MAP_PLACE_MAPCHANGE,
        MAP_PLACE_REST,
        MAP_PLACE_SCRIPT,
        MAP_PLACE_KEY,
        MAP_PLACE_CONTAINER,
        MAP_PLACE_SPAWN,
    };

    for (unsigned int index = 0; index < sizeof(order) / sizeof(order[0]); ++index) {
        const MapPlace *place = place_at_player(order[index]);
        if (place == NULL) continue;

        if (order[index] == MAP_PLACE_MAPCHANGE) {
            return transition_at_player();
        }
        if (order[index] == MAP_PLACE_REST) {
            return confirm_rest_at_player();
        }

        if (order[index] == MAP_PLACE_SIGN) {
            if (!requirement_is_satisfied(place)) {
                set_last_event_message("blocked");
                return 1;
            }
            if (!is_event_seen(current_map, place)) {
                mark_event_seen(current_map, place);
                set_named_state(&game_state.world.flags, event_phrase_id(place), 1);
                apply_requirement_effects(place);
            }
            set_sign_message(event_phrase_id(place));
            return 1;
        }
        if (order[index] == MAP_PLACE_SCRIPT) {
            if (!requirement_is_satisfied(place)) {
                set_last_event_message("script locked");
                return 1;
            }
            if (!is_event_seen(current_map, place)) {
                mark_event_seen(current_map, place);
                set_named_state(&game_state.world.flags, event_phrase_id(place), 1);
                apply_requirement_effects(place);
                char message[64];
                snprintf(message, sizeof(message), "script: %s", event_phrase_id(place));
                set_last_event_message(message);
            }
            return 1;
        }
        if (order[index] == MAP_PLACE_CONTAINER) {
            GameWorldLootBag *bag = game_world_loot_bag(
                &game_state.world, current_map->name, place->name,
                place->x, place->y, true, false
            );
            if (bag == NULL) return 1;
            int item_count = 0;
            for (size_t item_index = 0; item_index < bag->item_count; ++item_index) {
                if (!game_player_add_item(
                        &game_state.player,
                        bag->items[item_index].item_id,
                        bag->items[item_index].quantity)) {
                    return 1;
                }
                ++item_count;
            }
            if (!game_player_add_gold(&game_state.player, bag->gold)) return 1;
            const int gold = bag->gold;
            game_world_clear_loot_bag(bag);
            char message[128];
            if (item_count == 0 && gold == 0) {
                snprintf(message, sizeof(message), "The container is empty.");
            } else {
                snprintf(message, sizeof(message), "Found %d gold and %d item stacks.", gold, item_count);
            }
            set_last_event_message(message);
            sign_dialog_show(last_event_message);
            return 1;
        }
        if (order[index] == MAP_PLACE_SPAWN) {
            return start_actor_conversation(game_world_actor_at(
                &game_state.world, current_map->name, game_state.player.x, game_state.player.y
            ));
        }

        return 1;
    }
    return 0;
}

static int should_trigger_place_on_step(const MapPlace *place)
{
    if (place == NULL) return 0;
    if (place->trigger_when == NULL || place->trigger_when[0] == '\0') return 1;
    if (strcmp(place->trigger_when, "enter") == 0) return 1;
    if (strcmp(place->trigger_when, "step") == 0) return 1;
    if (strcmp(place->trigger_when, "round") == 0) return 1;
    if (strcmp(place->trigger_when, "always") == 0) return 1;
    return 0;
}

static int process_step_events(int previous_x, int previous_y)
{
    const unsigned char order[] = {
        MAP_PLACE_MAPCHANGE,
        MAP_PLACE_REST,
        MAP_PLACE_SIGN,
        MAP_PLACE_SCRIPT,
        MAP_PLACE_KEY,
        MAP_PLACE_CONTAINER,
        MAP_PLACE_SPAWN,
    };

    for (unsigned int index = 0; index < sizeof(order) / sizeof(order[0]); ++index) {
        const MapPlace *place = place_at_player(order[index]);
        if (place == NULL) continue;

        if (order[index] == MAP_PLACE_MAPCHANGE) {
            return transition_at_player();
        }
        if (order[index] == MAP_PLACE_REST) {
            snprintf(game_state.player.spawn_map_id, sizeof(game_state.player.spawn_map_id), "%s", current_map->name);
            snprintf(game_state.player.spawn_place_id, sizeof(game_state.player.spawn_place_id), "%s", place->name);
            set_last_event_message("checkpoint set");
            return 1;
        }
        if (order[index] == MAP_PLACE_SIGN || order[index] == MAP_PLACE_SCRIPT) {
            if (!should_trigger_place_on_step(place)) continue;
            if (order[index] == MAP_PLACE_SIGN && position_is_in_place(place, previous_x, previous_y)) {
                continue;
            }
            if (!requirement_is_satisfied(place)) {
                set_last_event_message("blocked");
                return 1;
            }
            if (order[index] == MAP_PLACE_SIGN || !is_event_seen(current_map, place)) {
                mark_event_seen(current_map, place);
                set_named_state(&game_state.world.flags, event_phrase_id(place), 1);
                apply_requirement_effects(place);
            }
            if (order[index] == MAP_PLACE_SIGN) {
                set_sign_message(event_phrase_id(place));
            } else {
                set_last_event_message(lookup_event_message(event_phrase_id(place)));
            }
            return 1;
        }
        return 1;
    }
    return 0;
}

static void draw_map(void)
{
    screen_renderer_draw(
        current_background,
        current_map->width,
        current_map->height,
        hero_sprite,
        game_state.player.x,
        game_state.player.y
    );
    sign_dialog_draw();
}

int main(void)
{
    if (!nitroFSInit(NULL)) return show_boot_failure("NitroFS initialization");
    if (!game_resources_init(&game_resources, "nitro:/game_data.pack")) {
        return show_boot_failure("Original game data / zlib load");
    }
    if (!load_hero_sprite()) return show_boot_failure("Hero sprite / zlib load");
    const GameMap *home_map = find_map("home");
    if (home_map == NULL) return show_boot_failure("Home map registry");
    game_runtime_state_init(
        &game_state, "Hero", home_map->name, home_map->start_x, home_map->start_y
    );
    srand((unsigned int)time(NULL));
    if (!set_current_map(home_map, home_map->start_x, home_map->start_y)) {
        return show_boot_failure("Home map / zlib load");
    }

    screen_renderer_init();
    draw_map();

    while (true) {
        scanKeys();
        const u32 keys = keysDownRepeat();
        int next_x = game_state.player.x;
        int next_y = game_state.player.y;

        if (sign_dialog_handle_input(keys)) {
            if (!sign_dialog_is_active()) {
                if (conversation_session.active && (keys & KEY_A)) {
                    char message[sizeof(last_event_message)];
                    if (game_conversation_continue(
                            &conversation_session,
                            &game_resources,
                            &game_state.player,
                            &game_state.world,
                            message,
                            sizeof(message))) {
                        set_last_event_message(message);
                        sign_dialog_show(last_event_message);
                    } else {
                        game_conversation_end(&conversation_session);
                    }
                } else if (keys & KEY_B) {
                    game_conversation_end(&conversation_session);
                }
                draw_map();
            }
        } else if (keys & KEY_START) {
            const GameMap *spawn_map = find_map(game_state.player.spawn_map_id);
            const MapPlace *spawn = spawn_map != NULL
                ? find_place(spawn_map, game_state.player.spawn_place_id, MAP_PLACE_REST)
                : NULL;
            if (spawn != NULL && set_current_map(spawn_map, spawn->x, spawn->y)) {
                draw_map();
            }
        } else if (keys & KEY_A) {
            process_interaction();
            if (sign_dialog_is_active()) draw_map();
        } else {
            if (keys & KEY_LEFT) --next_x;
            else if (keys & KEY_RIGHT) ++next_x;
            else if (keys & KEY_UP) --next_y;
            else if (keys & KEY_DOWN) ++next_y;

            if (next_x != game_state.player.x || next_y != game_state.player.y) {
                if (next_x >= 0 && next_x < current_map->width
                        && next_y >= 0 && next_y < current_map->height) {
                    const int index = next_y * current_map->width + next_x;
                    GameActorState *actor = game_world_actor_at(
                        &game_state.world, current_map->name, next_x, next_y
                    );
                    if (actor != NULL) {
                        start_actor_conversation(actor);
                        if (sign_dialog_is_active()) draw_map();
                    } else if (current_map->walkable[index] && can_enter_key_area(next_x, next_y)) {
                        const int previous_x = game_state.player.x;
                        const int previous_y = game_state.player.y;
                        game_state.player.x = next_x;
                        game_state.player.y = next_y;
                        game_world_tick(&game_state.world, 1);
                        process_step_events(previous_x, previous_y);
                        draw_map();
                    } else if (sign_dialog_is_active()) {
                        draw_map();
                    }
                }
            }
        }

        swiWaitForVBlank();
    }
}